"""Which Rivals Scout this is. Publish update.cmd raises BUILD by one each time."""
BUILD = 6


def label():
    """What people see, e.g. 'v1.4' (major 1, build 4)."""
    return f'v1.{BUILD}'
# Goes up only when Python or the packages inside the installer change.
# Copies with an older RUNTIME need a fresh Setup instead of a small update.
RUNTIME = 1
UPDATES = 'https://raw.githubusercontent.com/rivals-scout-app/updates/main/updates/'
