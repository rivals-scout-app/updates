"""The match scout screen: ban picks, your team, the last scan and the enemy rows."""
from scout.ui.common import *  # noqa: F401,F403


class ScanViews:
    # ---- left column ------------------------------------------------------------
    def _draw_left(self, x, y, w, h):
        bottom = y + h
        y = self._draw_bans(x, y, w) + 16
        y = self._draw_team(x, y, w, bottom - y) + 16
        self._scan_in_bar = bottom - y < 90
        if not self._scan_in_bar:
            self._draw_scan(x, y, w)

    def _history_label(self):
        return self.season.get()

    def _draw_bans(self, x, y, w):
        b = self.board
        rows = self.advice_rows
        hidden = self._hidden_enemies()
        text_x = x + 134
        chip_rows = self._layout_chips(self._ban_chips(rows[0]), x + w - 30 - text_x) if rows else []
        top_h = 116 + 30 * (max(1, len(chip_rows)) - 1)
        alt_count = len(rows[1:3])
        note_h = 26 if hidden else 0
        if rows:
            height = 62 + top_h + alt_count * (12 + 82) + 20 + note_h
        else:
            height = 62 + 96 + 20 + note_h
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 34, 'Ban these', 20)
        label = self._history_label()
        pill_w = b.measure(label, 13, 'extra') + 34
        tag = 'history-pill'
        b.shape(x + w - 20 - pill_w, y + 22, pill_w, 26, 13, RAISED_BOTTOM, None, CHIP_LINE, tags=(tag,))
        b.text(x + w - 20 - pill_w + 12, y + 35, label, 13, 'extra', SOFT, tags=(tag,))
        b.canvas.create_polygon(b.z(x + w - 32), b.z(y + 33), b.z(x + w - 26), b.z(y + 33), b.z(x + w - 29), b.z(y + 37),
                                fill=SOFT, outline='', tags=(tag,))
        b.clickable(tag, lambda: self.show_history_menu())
        top = y + 62
        if not rows:
            b.shape(x + 20, top, w - 40, 96, 22, '#262731', '#1B1C22', RAISED_LINE)
            waiting = 'Looking up the enemy team…' if self.busy else 'Your bans show up here.'
            b.text(x + 40, top + 36, waiting, 18, fit=w - 80)
            b.text(x + 40, top + 66, 'They appear a few seconds after a scan.', 13, 'bold', MUTED, fit=w - 80)
        else:
            first = rows[0]
            tag = 'top-ban'
            b.shape(x + 20, top, w - 40, top_h, 24, '#221E16', '#16140F', GOLD_BOTTOM, 1,
                    glow=(GOLD_BOTTOM, 34), glow_size=12, tags=(tag,))
            b.avatar(x + 36, top + (top_h - 82) / 2, 82, '#2A2B33', '#1E1F26', GOLD_BOTTOM, 1.5,
                     picture=hero_picture(first['hero']), initials=initials(first['hero']), tags=(tag,))
            b.text(text_x, top + 24, 'TOP BAN', 11, color=GOLD, tags=(tag,))
            b.text(text_x, top + 50, first['hero'], 28, color=TEXT, tags=(tag,), fit=x + w - 30 - text_x)
            chip_y = top + 74
            for line in chip_rows:
                chip_x = text_x
                for chip, chip_w in line:
                    b.shape(chip_x, chip_y, chip_w, 24, 12, (255, 255, 255, 14), None, (255, 255, 255, 30), 1, tags=(tag,))
                    b.text(chip_x + 10, chip_y + 12, chip, 12, 'extra', SOFT, tags=(tag,))
                    chip_x += chip_w + 6
                chip_y += 30
            b.clickable(tag, self.show_ban_details)
            alt_y = top + top_h + 12
            for index, row in enumerate(rows[1:3]):
                tag = f'alt-ban-{index}'
                b.shape(x + 20, alt_y, w - 40, 82, 22, '#262731', '#1B1C22', RAISED_LINE, tags=(tag,))
                tint = tint_for(row['hero'])
                b.avatar(x + 32, alt_y + 17, 48, tint[0], tint[1], tint[2], 2, picture=hero_picture(row['hero']),
                         initials=initials(row['hero']), tags=(tag,))
                chips = self._ban_chips(row)
                trick = chips[0] == 'one-trick'
                if trick:
                    chips = chips[1:]
                name_room = w - 40 - 84 - (84 if trick else 0)
                b.text(x + 92, alt_y + 22, row['hero'], 16, tags=(tag,), fit=name_room)
                if trick:
                    name_w = min(name_room, b.measure(row['hero'], 16))
                    b.shape(x + 92 + name_w + 8, alt_y + 13, 72, 18, 9, CORAL_TOP, CORAL_BOTTOM, None, direction='right', tags=(tag,))
                    b.text(x + 92 + name_w + 16, alt_y + 22, 'ONE-TRICK', 11, color=CORAL_TEXT, tags=(tag,))
                half = (len(chips) + 1) // 2
                b.text(x + 92, alt_y + 44, ' · '.join(chips[:half]), 13, 'extra', '#B9BAC4', tags=(tag,), fit=w - 40 - 84)
                b.text(x + 92, alt_y + 63, ' · '.join(chips[half:]), 13, 'extra', '#B9BAC4', tags=(tag,), fit=w - 40 - 84)
                b.clickable(tag, self.show_ban_details)
                alt_y += 82 + 12
        if hidden:
            others = max(0, len(self.enemy_names()) - hidden)
            note = f'{hidden} enem{"y hides their" if hidden == 1 else "ies hide their"} name, so bans use the other {others}.'
            b.text(x + 20, y + height - 30, note, 12, 'extra', WARN_TEXT, fit=w - 40)
        return y + height

    def _layout_chips(self, chips, room):
        """Put the reason chips in rows that fit, instead of dropping the ones that don't."""
        lines, line, used = [], [], 0
        for chip in chips:
            chip_w = self.board.measure(chip, 12) + 20
            if line and used + chip_w > room:
                lines.append(line)
                line, used = [], 0
            line.append((chip, chip_w))
            used += chip_w + 6
        if line:
            lines.append(line)
        return lines

    def _ban_chips(self, row):
        best = max(row['evidence'], key=lambda e: e['matches'])
        chips = ['one-trick'] if row.get('one_trick') else []
        lorded = [e['player'] for e in row['evidence']
                  if ((self.enemy_extra.get(e['player']) or {}).get('proficiency') or {}).get(row['hero'], 0) >= 20]
        if lorded:
            chips.append(f"Lord ({short(lorded[0])})" if len(lorded) == 1 else f"{len(lorded)} enemies have Lord")
        meta = row.get('meta')
        if meta and (meta['ban'] >= 20 or meta['score'] >= 75):
            chips.append(f"{meta['ban']:.0f}% ban rate (Diamond+)")
        if len(row['evidence']) > 1:
            chips.append(f"{len(row['evidence'])} enemies play it")
        chips.append(f"{best['win']:g}% wins")
        chips.append(f"{best['matches']:g} games")
        if best.get('kda') is not None:
            chips.append(f"{best['kda']:.1f} KDA")
        if best.get('kd') not in (None, 'N/A'):
            chips.append(f"{best['kd']} K/D")
        return chips

    def _ban_line(self, row):
        return ' · '.join(self._ban_chips(row))

    def _draw_team(self, x, y, w, room=10000):
        b = self.board
        pills = []
        for name in self.ally_names:
            if is_hidden_name(name):
                pills.append(('Hidden player', '', None))
                continue
            result = self.ally_results.get(name) or next((r for key, r in self.ally_results.items() if key.casefold() == name.casefold()), None)
            hero = result['heroes'][0]['hero_name'] if result and result.get('heroes') else ''
            real = result.get('username', name) if result else name
            # Show the account's real name once it's found (the scan can misread it, e.g. a stray space).
            shown = short(result['username']) if result and result.get('username') else short(name)
            pills.append((shown, hero, None if is_unreadable_name(name) else real))
        # Lay the pills out in rows to know the card height (measured in the weight they're drawn in).
        def pill_width(name, hero):
            return b.measure(name, 14, 'extra') + (b.measure(' · ' + hero, 14, 'extra') if hero else 0) + 26
        lines, line, used = [], [], 0
        for name, hero, real in pills:
            pill_w = pill_width(name, hero)
            if line and used + pill_w > w - 40:
                lines.append(line); line, used = [], 0
            line.append((name, hero, pill_w, real)); used += pill_w + 8
        if line:
            lines.append(line)
        # Not enough room for every pill: keep the rows that fit and say how many more.
        fits = max(1, int((room - 20 - 32 - 12 - 14 - 18 - 12) // 38))
        if len(lines) > fits:
            hidden_count = sum(len(l) for l in lines[fits:])
            lines = lines[:fits]
            # Make room on the last row for the "+N more" pill so it never runs past the card.
            while True:
                more = f'+{hidden_count} more'
                more_w = pill_width(more, '')
                row_w = sum(p[2] + 8 for p in lines[-1])
                if row_w + more_w <= w - 40 or len(lines[-1]) <= 1:
                    break
                lines[-1].pop()
                hidden_count += 1
            lines[-1].append((more, '', more_w, None))
        note = "Heroes your team plays a lot won't be suggested as bans."
        picks = self._my_picks()
        if picks:
            note = 'Your picks: ' + ' · '.join(f"{hero} {win:.0f}%" for hero, win in picks)
        note_lines = 1 if b.measure(note, 13, 'bold') <= w - 40 or room < 260 else 2
        height = 20 + 32 + 12 + max(1, len(lines)) * 38 + 12 + note_lines * 18 + 14
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 36, 'Your team', 18)
        edit_w = b.measure('Edit picks', 13) + 30
        b.button(x + w - 20 - edit_w, y + 20, 'Edit picks', self.edit_team, 'raised', 32, 13, width=edit_w)
        row_y = y + 64
        if not lines:
            b.text(x + 20, row_y + 15, 'Scan a loading screen to fill in your team.', 14, 'bold', MUTED)
        for line in lines:
            px = x + 20
            for name, hero, pill_w, real in line:
                b.shape(px, row_y, pill_w, 30, 15, '#1B1C23', None, '#2F6B50')
                if real:
                    self._click_area(px, row_y, pill_w, 30, lambda real=real: self.open_player(real))
                b.text(px + 13, row_y + 15, name, 14, 'extra')
                if hero:
                    b.text(px + 13 + b.measure(name, 14, 'extra'), row_y + 15, ' · ' + hero, 14, 'extra', GREEN_SOFT)
                px += pill_w + 8
            row_y += 38
        if note_lines == 1:
            b.text(x + 20, y + height - 23, note, 13, 'bold', MUTED, fit=w - 40)
        else:
            b.text(x + 20, y + height - 14, note, 13, 'bold', MUTED, anchor='sw', width=w - 40)
        return y + height

    def _my_picks(self):
        """Your 3 strongest heroes this season that aren't about to be banned, nudged by the current meta."""
        heroes = (self.my_profile or {}).get('heroes') or []
        banned = {row['hero'].casefold() for row in self.advice_rows[:1]}
        scored = []
        for hero in heroes:
            games = hero.get('_games') or 0
            try:
                win = float(str(hero.get('win_pct', '')).rstrip('%'))
            except ValueError:
                continue
            if games < 3 or hero['hero_name'].casefold() in banned:
                continue
            shrunk = (games * win / 100 + 5) / (games + 10)
            meta = self.meta.get(hero['hero_name'].casefold())
            boost = 1 + (meta['win'] - 50) / 100 if meta else 1
            scored.append((shrunk * boost, hero['hero_name'], win))
        return [(name, win) for _, name, win in sorted(scored, reverse=True)[:3]]

    def _draw_scan(self, x, y, w):
        b = self.board
        b.shape(x, y, w, 94, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        thumb = None
        if self.scan_file and Path(self.scan_file).is_file():
            try:
                thumb = paint.rounded_picture(str(self.scan_file), b.z(116), b.z(66), b.z(14), RAISED_LINE)
            except (OSError, ValueError):
                thumb = None
        if thumb is not None:
            b.place_image(thumb, x + 14, y + 14, tags=('scan-thumb',))
            b.clickable('scan-thumb', self.open_scan_file)
            when = self.scan_time or ''
            view_w = b.measure('View', 13) + 30
            room = w - 144 - view_w - 26
            b.text(x + 144, y + 34, f'Scanned {when} · {self.scan_how}', 15, fit=room)
            b.text(x + 144, y + 60, Path(self.scan_file).name, 13, 'bold', MUTED, fit=room)
            b.button(x + w - 14 - view_w, y + 29, 'View', self.open_scan_file, 'raised', 36, 13, width=view_w)
        else:
            b.shape(x + 14, y + 14, 116, 66, 14, '#24252E', '#1A1B21', RAISED_LINE)
            b.text(x + 72, y + 47, 'no scan', 12, 'extra', '#B9BAC4', anchor='center')
            b.text(x + 144, y + 36, 'No scan yet', 15)
            b.text(x + 144, y + 60, 'The scanned loading screen shows here.', 13, 'bold', MUTED)

    # ---- enemy rows ---------------------------------------------------------------
    def _draw_enemies(self, x, y, w, h):
        b = self.board
        b.shape(x, y, w, h, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Enemy team', 20)
        names = self.enemy_names()[:6]
        kinds = [self._row_kind(name) for name in names]
        pills = []
        found = kinds.count('ok')
        if found:
            pills.append((f'{found} found', RAISED_BOTTOM, CHIP_LINE, TEXT))
        fixes = kinds.count('fix')
        if fixes:
            pills.append((f'{fixes} need{"s" if fixes == 1 else ""} a fix', '#2C2617', GOLD, GOLD))
        hidden = kinds.count('hidden')
        if hidden:
            pills.append((f'{hidden} hidden', '#1C1D23', '#3A3B46', SOFT))
        loading = kinds.count('loading')
        if loading and self.busy:
            pills.append((f'{loading} loading', RAISED_BOTTOM, CHIP_LINE, MUTED))
        px = x + w - 20
        for text, fill, line, ink in reversed(pills):
            pill_w = b.measure(text, 13, 'extra') + 24
            px -= pill_w
            b.shape(px, y + 19, pill_w, 26, 13, fill, None, line, 1)
            b.text(px + 12, y + 32, text, 13, 'extra', ink)
            px -= 8
        line_y = self._draw_intel(x + 18, y + 54, w - 36)
        area_top, area_bottom = line_y, y + h - 16
        slots = max(6, len(names))
        gap = 10 if (area_bottom - area_top - 50) / slots >= 84 else 6
        row_h = max(78, min(98, (area_bottom - area_top - gap * (slots - 1)) / slots))
        self._compact = row_h < 84
        row_y = area_top
        for name, kind in zip(names, kinds):
            if row_y + row_h > area_bottom + 1:
                break
            draw = {'ok': self._row_ok, 'fix': self._row_fix, 'hidden': self._row_hidden}.get(kind, self._row_loading)
            draw(name, x + 18, row_y, w - 36, row_h)
            row_y += row_h + gap

    def _threat_line(self):
        """One line about the enemy team: best rank, one-tricks, players who queue together, leavers."""
        names = self.enemy_names()[:6]
        parts = []
        ranked = [(self.enemy_extra[n].get('level') or 0, n) for n in names if (self.enemy_extra.get(n) or {}).get('level')]
        if ranked:
            level, who = max(ranked)
            parts.append(f"Top rank {self.enemy_extra[who]['rank']} ({short(who)})")
        tricks = sum(1 for n in names if any(is_one_trick(h) for h in (self.results_by_name.get(n) or {}).get('heroes', [])))
        if tricks:
            parts.append(f"{tricks} one-trick{'s' if tricks > 1 else ''}")
        lords = []
        for n in names:
            mastery = (self.enemy_extra.get(n) or {}).get('proficiency') or {}
            played = {h['hero_name'] for h in (self.results_by_name.get(n) or {}).get('heroes', [])[:3]}
            best = max(((lvl, hero) for hero, lvl in mastery.items() if lvl >= 20 and hero in played), default=None)
            if best:
                from scout.stats.extras import mastery_badge
                lords.append(f"{short(n)}'s {best[1]} ({mastery_badge(best[0])})")
        if lords:
            parts.append('Lord: ' + ', '.join(lords[:3]) + (f' +{len(lords) - 3}' if len(lords) > 3 else ''))
        for n in names:
            form = (self.enemy_extra.get(n) or {}).get('form')
            played = [h['hero_name'] for h in (self.results_by_name.get(n) or {}).get('heroes', [])[:3]]
            if form and form.get('top_games', 0) >= 4 and played and form['top'] not in played:
                parts.append(f"{short(n)} plays {form['top']} lately ({form['top_games']} of {form['games']})")
        for a, b_name, games in self.stacks[:2]:
            parts.append(f"{short(a)} + {short(b_name)} queue together ({games} games)")
        leavers = sum(1 for n in names if (self.enemy_extra.get(n) or {}).get('penalties'))
        if leavers:
            parts.append(f"{leavers} with recent leave penalties")
        return '  ·  '.join(parts)

    def _intel_items(self):
        """What matters about the enemy team, as (label, value, colour) tiles, most important first."""
        names = self.enemy_names()[:6]
        extra = lambda n: self.enemy_extra.get(n) or {}
        heroes = lambda n: (self.results_by_name.get(n) or {}).get('heroes', [])
        items = []
        ranked = [(extra(n).get('level') or 0, n) for n in names if extra(n).get('level')]
        if ranked:
            level, who = max(ranked)
            items.append(('TOP RANK', ('rank', level, short(who)), TEXT))
        from scout.stats.extras import form_tag, mastery_badge
        lords = []
        for n in names:
            mastery = extra(n).get('proficiency') or {}
            played = {h['hero_name'] for h in heroes(n)[:3]}
            best = max(((lvl, hero) for hero, lvl in mastery.items() if lvl >= 20 and hero in played), default=None)
            if best:
                lords.append((best[0], f"{best[1]} · {short(n)}"))
        if lords:
            lords.sort(reverse=True)
            champion = mastery_badge(lords[0][0]) == 'Champion'
            label = ('CHAMPION' if champion else 'LORD') + (f' +{len(lords) - 1} MORE' if len(lords) > 1 else '')
            items.append((label, ', '.join(t for _, t in lords), GOLD))
        tricks = [short(n) for n in names if any(is_one_trick(h) for h in heroes(n))]
        if tricks:
            items.append((f'ONE-TRICKS · {len(tricks)}' if len(tricks) > 1 else 'ONE-TRICK', ', '.join(tricks), '#F2A7AE'))
        for a, b_name, games in self.stacks[:2]:
            items.append(('DUO', f"{short(a)} + {short(b_name)}", '#93B8F0'))
        for n in names:
            form = extra(n).get('form')
            played = [h['hero_name'] for h in heroes(n)[:3]]
            if form and form.get('top_games', 0) >= 4 and played and form['top'] not in played:
                items.append(('SWITCHED', f"{short(n)} → {form['top']}", SOFT))
        leavers = [short(n) for n in names if extra(n).get('penalties')]
        if leavers:
            items.append(('LEAVES GAMES', ', '.join(leavers), SOFT))
        return items

    def _draw_intel(self, x, y, w):
        """A row of small labelled tiles about the enemy team, then the comp read. Returns the y below it."""
        b = self.board
        items = self._intel_items()
        comp = self._comp_line()
        if comp:
            items.insert(min(3, len(items)), ('LIKELY COMP', comp[0].replace('Likely comp: ', ''), SOFT))
        if not items:
            return y + 4
        tile_h, gap = 40, 6
        columns = 4 if w > 760 else 3
        tile_w = (w - gap * (columns - 1)) / columns
        items = items[:columns * 2]
        for index, (label, value, color) in enumerate(items):
            tx = x + (index % columns) * (tile_w + gap)
            ty = y + (index // columns) * (tile_h + gap)
            b.shape(tx, ty, tile_w, tile_h, 10, '#121318', None, CARD_LINE, 1)
            b.text(tx + 12, ty + 12, label, 9, 'extra', MUTED, fit=tile_w - 24)
            if isinstance(value, tuple):  # top rank: badge + rank, then who
                from scout.stats.tracker import RANKS
                _, level, who = value
                rank = RANKS[max(1, min(len(RANKS), int(level))) - 1]
                rank_w = 22 + b.measure(rank, 12, 'extra')
                self._rank_badge(tx + 12, ty + 27, level, tile_w - 24, size=15)
                b.text(tx + 12 + rank_w + 6, ty + 27, b.fit(who, 13, tile_w - 30 - rank_w, 'extra'), 13, 'extra', TEXT)
            else:
                b.text(tx + 12, ty + 27, b.fit(value, 13, tile_w - 24, 'extra'), 13, 'extra', color)
        y += (tile_h + gap) * ((len(items) + columns - 1) // columns) - gap + 10
        if comp and comp[1]:
            b.dot(x + 2, y + 4, 8, GOLD)
            b.text(x + 18, y + 8, comp[1], 13, 'extra', GOLD, fit=w - 20)
            y += 24
        return y + 2

    def _comp_line(self):
        """('Likely comp: 2 tank · 3 dps · 1 heal', tip) from what each enemy will probably pick, or None."""
        from scout.stats.extras import comp_read, likely_hero
        picks = []
        for n in self.enemy_names()[:6]:
            season = [h['hero_name'] for h in (self.results_by_name.get(n) or {}).get('heroes', [])]
            picks.append(likely_hero(season, (self.enemy_extra.get(n) or {}).get('form')))
        read = comp_read(picks)
        if not read:
            return None
        c = read['counts']
        return (f"Likely comp: {c['Vanguard']} tank · {c['Duelist']} dps · {c['Strategist']} heal", read['tip'])

    def _rank_badge(self, x, mid_y, level, room, size=18):
        """Small rank badge plus its name (e.g. a teal shield and "Platinum III"), centred on mid_y."""
        from scout.stats.tracker import RANKS
        name = RANKS[max(1, min(len(RANKS), int(level))) - 1]
        parts = name.rsplit(' ', 1)
        tier, division = (parts[0], {'III': 3, 'II': 2, 'I': 1}.get(parts[1], 0)) if len(parts) == 2 and parts[1] in ('I', 'II', 'III') else (name, 0)
        big = size + 8  # the emblem is detailed; a little larger than the text keeps it recognisable
        picture = paint.rank_picture(tier, self.board.z(big))
        if picture is not None:
            self.board.place_image(picture, x - 4, mid_y - big / 2)
        else:
            self.board.place_image(paint.rank_icon(tier, division, self.board.z(size)), x, mid_y - size / 2)
        self.board.text(x + size + 5, mid_y, name, 12, 'extra', paint.RANK_COLORS.get(tier, ('#B9BAC4',))[0], fit=room - size - 5)

    def _row_kind(self, name):
        if is_hidden_name(name):
            return 'hidden'
        if name in self.results_by_name:
            return 'ok'
        if name in self.errors_by_name or is_unreadable_name(name):
            return 'fix'
        return 'loading'

    def _avatar_for(self, name, x, y, size, hero=None, ring=None):
        tint = tint_for(name)
        self.board.avatar(x, y, size, tint[0], tint[1], ring or tint[2], 3, glow=(tint[1], 110),
                          picture=hero_picture(hero) if hero else None, initials=initials(name))

    def _row_ok(self, name, x, y, w, h):
        b = self.board
        result = self.results_by_name[name]
        heroes = result.get('heroes', [])
        trick = any(is_one_trick(hero) for hero in heroes)
        b.shape(x, y, w, h, 22, ROW_LEFT, ROW_RIGHT, '#6E3540' if trick else CHIP_LINE, 1.5, 'right')
        avatar = min(54, h - 20)
        from scout.stats.extras import form_tag
        extra = self.enemy_extra.get(name) or {}
        streak_tag = form_tag(extra.get('form'))
        ring = GOLD if streak_tag == 'HOT' else LOSS_SOFT if streak_tag == 'COLD' else None
        ay = y + (h - avatar) / 2 - (6 if (streak_tag or extra.get('tonight')) else 0)
        # Lord / Champion on one of their main heroes: show that hero, in the mastery frame.
        mastery = extra.get('proficiency') or {}
        best = max(((mastery.get(h['hero_name'], 0), h['hero_name']) for h in heroes[:3]), default=(0, None))
        shown_hero = best[1] if best[0] >= 20 else (heroes[0]['hero_name'] if heroes else None)
        self._avatar_for(name, x + 12, ay, avatar, shown_hero, ring=ring)
        b.mastery_frame(x + 12, ay, avatar, best[0])
        tonight = extra.get('tonight')
        if tonight or streak_tag:
            # Record pill under the picture: tonight's W-L (e.g. 1-5, 5-0), or the streak if they haven't played tonight.
            # Dark chip; its outline (and the picture's ring) is gold on a win streak, red on a losing streak.
            if tonight:
                parts = [(str(tonight['wins']), GREEN_SOFT), ('–', MUTED), (str(tonight['games'] - tonight['wins']), LOSS_SOFT)]
            else:
                streak = extra['form']['streak']
                parts = [(f'{abs(streak)}{"W" if streak > 0 else "L"} streak', GOLD if streak > 0 else LOSS_SOFT)]
            edge = GOLD if streak_tag == 'HOT' else LOSS if streak_tag == 'COLD' else '#33343E'
            gap = 3
            text_w = sum(b.measure(t, 12) for t, _ in parts) + gap * (len(parts) - 1)
            pill_w = max(40, text_w + 18)
            px, py = x + 12 + avatar / 2 - pill_w / 2, ay + avatar - 8
            b.shape(px, py, pill_w, 19, 9.5, '#15161B', None, edge, 1.5)
            tx = px + (pill_w - text_w) / 2
            for text, color in parts:
                b.text(tx, py + 9.5, text, 12, color=color)
                tx += b.measure(text, 12) + gap
        name_x, name_w = x + 12 + avatar + 12, 150 if w > 860 else 118
        display = short(result.get('username', name))
        tags = []
        if trick:
            tags.append(('ONE-TRICK', (CORAL_TOP, CORAL_BOTTOM), CORAL_TEXT))
        if any(name in pair[:2] for pair in self.stacks):
            tags.append(('DUO', ('#93B8F0', '#6F95D6'), DARK))
        if extra.get('penalties'):
            tags.append(('LEAVES', ('#3A3B46', '#2E2F38'), TEXT))
        note = result.get('note', '')
        sub = ''
        if note.startswith('Matched to '):
            scanned = note.split('(scanned as ', 1)[-1].split(')', 1)[0].replace(' after reading the name again', '')
            sub = f'read as {scanned}'
        elif 'PREVIOUS' in note:
            sub = 'last season'
        has_sub = bool(sub) and not self._compact
        rank_level = extra.get('level') or 0
        # Lay tags out in rows; a second row only when the row is tall enough.
        tag_rows, row, row_w = [], [], 0
        for tag in tags:
            tw = b.measure(tag[0], 11) + 16
            if row and row_w + tw > name_w + 6:
                tag_rows.append(row)
                row, row_w = [], 0
            row.append((tag, tw))
            row_w += tw + 6
        if row:
            tag_rows.append(row)
        tag_rows = tag_rows[:2 if (h >= 90 and not has_sub) else 1]
        lines = 1 + bool(rank_level) + len(tag_rows) + bool(has_sub)
        name_y = y + h / 2 - (lines - 1) * 10
        b.text(name_x, name_y, display, 18, fit=name_w)
        line_y = name_y + 21
        if rank_level:
            # Rank badge right under the name.
            self._rank_badge(name_x, line_y, rank_level, name_w)
            line_y += 20
        for index, tag_row in enumerate(tag_rows):
            tx = name_x
            for (text, (top, bottom), ink), tw in tag_row:
                if tx + tw > name_x + name_w + 6:
                    break
                b.shape(tx, line_y - 9, tw, 18, 9, top, bottom, None, direction='right')
                b.text(tx + 8, line_y, text, 11, color=ink)
                tx += tw + 6
            if index < len(tag_rows) - 1:
                line_y += 21
        if sub and (has_sub or not tags):
            sub_y = line_y + (19 if tags else 0)
            b.text(name_x, sub_y, sub, 12, 'extra', MUTED, fit=name_w)
        chips_x = name_x + name_w + 10
        chips_w = x + w - 12 - chips_x
        self._click_area(x, y, w, h, lambda real=result.get('username', name): self.open_player(real))
        if not heroes:
            b.text(chips_x, y + h / 2, 'No ranked matches recorded.', 14, 'bold', MUTED)
            return
        chip_w = (chips_w - 16) / 3
        mastery = (self.enemy_extra.get(name) or {}).get('proficiency') or {}
        for index, hero in enumerate(heroes[:3]):
            self._hero_chip(hero, chips_x + index * (chip_w + 8), y + 8, chip_w, h - 16, mastery.get(hero['hero_name']))

    def _click_area(self, x, y, w, h, command):
        """An invisible layer over (x, y, w, h) that runs `command` when clicked."""
        b = self.board
        tag = f'area{len(b.photos)}_{int(x)}_{int(y)}'
        b.place_image(Image.new('RGBA', (max(1, b.z(w)), max(1, b.z(h))), (0, 0, 0, 0)), x, y, tags=(tag,))
        b.clickable(tag, command)

    def _hero_chip(self, hero, x, y, w, h, mastery=None):
        from scout.stats.extras import mastery_badge
        b = self.board
        lord = mastery is not None and mastery >= 20
        b.shape(x, y, w, h, 16, CHIP_FILL, None, GOLD if lord else CHIP_LINE, 1.5 if lord else 1)
        compact = h < 58
        top = y + (14 if compact else 16)
        win = hero.get('win_pct', '')
        win_label_w = b.measure('win', 11, 'bold') if win else 0
        win_w = b.measure(win, 14) + win_label_w + 4
        b.text(x + 11, top, hero['hero_name'], 15, fit=w - 30 - win_w)
        if win:
            b.text(x + w - 11, top + 1, 'win', 11, 'bold', MUTED, anchor='e')
            b.text(x + w - 15 - win_label_w, top, win, 14, color=win_color(win), anchor='e')
        counts, kda = per_game(hero)
        games_line = f"{hero.get('matches_played', 0):g} games" if isinstance(hero.get('matches_played'), (int, float)) else f"{hero.get('matches_played', '')} games"
        badge = mastery_badge(mastery)
        if badge:
            games_line = f"{badge} · " + games_line
        if hero.get('kd') not in (None, 'N/A'):
            games_line += f" · {hero['kd']} K/D"
        if hero.get('recent_win_pct'):
            try:
                change = float(hero['recent_win_pct'].rstrip('%')) - float(str(win).rstrip('%'))
            except ValueError:
                change = 0
            if abs(change) >= 3:
                games_line += f'  {change:+.0f}% lately'
        if not compact:
            b.text(x + 11, top + 19, games_line, 12, 'bold', MUTED, fit=w - 22)
        bottom = y + h - (13 if compact else 15)
        if counts:
            label = f'{kda:.1f} KDA'
            kw = b.measure(label, 11) + 14
            room = w - 22 - kw - 6
            size = 12
            # "Avg K/D/A" label first so the three numbers aren't a mystery.
            tag = 'K/D/A '
            tag_w = b.measure(tag, 10, 'bold')
            room -= tag_w
            parts = [(f'{counts[0]:.1f}', GREEN_SOFT), (' / ', SOFT), (f'{counts[1]:.1f}', RED), (' / ', SOFT), (f'{counts[2]:.1f}', BLUE)]
            while size > 9 and sum(b.measure(text, size, 'extra') for text, _ in parts) > room:
                size -= 1
            if sum(b.measure(text, size, 'extra') for text, _ in parts) > room:
                parts = [(f'{counts[0]:.0f}', GREEN_SOFT), ('/', SOFT), (f'{counts[1]:.0f}', RED), ('/', SOFT), (f'{counts[2]:.0f}', BLUE)]
            b.text(x + 11, bottom, tag, 10, 'bold', MUTED)
            tx = x + 11 + tag_w
            for text, color in parts:
                b.text(tx, bottom, text, size, 'extra', color)
                tx += b.measure(text, size, 'extra')
            top_color, bottom_color = kda_colors(kda)
            b.shape(x + w - 9 - kw, bottom - 9, kw, 18, 9, '#1F2027', None, top_color, 1)
            b.text(x + w - 9 - kw + 7, bottom, label, 11, color=bottom_color)
        else:
            b.text(x + 11, bottom, f"{hero.get('kd', 'N/A')} K/D", 12, 'extra', SOFT)

    def _row_loading(self, name, x, y, w, h):
        b = self.board
        b.shape(x, y, w, h, 22, ROW_LEFT, ROW_RIGHT, CHIP_LINE, 1.5, 'right')
        avatar = min(54, h - 20)
        self._avatar_for(name, x + 12, y + (h - avatar) / 2, avatar)
        b.text(x + 12 + avatar + 12, y + h / 2, short(name), 18, fit=160)
        text = 'Looking up stats…' if self.busy else 'Not looked up yet'
        b.text(x + 12 + avatar + 184, y + h / 2, text, 14, 'bold', MUTED, anchor='w', width=x + w - 20 - (x + 12 + avatar + 184))

    def _row_hidden(self, name, x, y, w, h):
        b = self.board
        b.shape(x, y, w, h, 22, HIDDEN_LEFT, HIDDEN_RIGHT, '#2C2D36', 1.5, 'right')
        avatar = min(54, h - 20)
        b.avatar(x + 12, y + (h - avatar) / 2, avatar, '#2C2D36', '#1F2027', '#3A3B46', 3)
        b.text(x + 12 + avatar / 2, y + h / 2, '?', 22, color=SOFT, anchor='center')
        name_x = x + 12 + avatar + 12
        b.text(name_x, y + h / 2 - 10, 'Hidden player', 18, color=SOFT)
        b.shape(name_x, y + h / 2 + 4, 62, 18, 9, '#24252D', None, None)
        b.text(name_x + 8, y + h / 2 + 13, 'HIDDEN', 11, color=MUTED)
        note = 'Name hidden in game, so there are no stats. Not counted in the bans.'
        room = x + w - 20 - (name_x + 172)
        if b.measure(note, 14, 'bold') > room:
            note = 'Name hidden in game: no stats, not counted in the bans.'
        b.text(name_x + 172, y + h / 2, note, 14 if room > 220 else 12, 'bold', MUTED, anchor='w', width=room)

    def _row_fix(self, name, x, y, w, h):
        b = self.board
        b.shape(x, y, w, h, 22, WARN_LEFT, WARN_RIGHT, GOLD, 2, 'right', glow=(GOLD, 60), glow_size=8)
        avatar = min(54, h - 20)
        b.avatar(x + 12, y + (h - avatar) / 2, avatar, GOLD_TOP, GOLD_BOTTOM, '#F6E2B4', 3)
        b.text(x + 12 + avatar / 2, y + h / 2, '?', 24, color=DARK, anchor='center')
        text_x = x + 12 + avatar + 12
        unreadable = is_unreadable_name(name)
        title = "Couldn't read this name" if unreadable else "Couldn't find this one"
        b.text(text_x, y + h / 2 - 10, title, 16, color=GOLD)
        b.text(text_x, y + h / 2 + 12, 'Fix the name, press Enter', 12, 'bold', WARN_TEXT)
        px = text_x + 186
        picture_h = min(44, h - 24)
        path = self.name_images.get(name)
        right_needed = 330
        space = x + w - 12 - right_needed - px
        if path and Path(path).is_file() and space > 60:
            try:
                from PIL import Image
                with Image.open(path) as source:
                    ratio = source.width / max(1, source.height)
                pic_w = min(space - 34, picture_h * ratio)
                pic_h = pic_w / ratio
                image = paint.rounded_picture(path, b.z(pic_w), b.z(pic_h), b.z(10), RAISED_LINE)
                b.place_image(image, px, y + (h - pic_h) / 2)
                icon_arrow(b, px + pic_w + 17, y + h / 2, GOLD, ())
                px += pic_w + 34
            except (OSError, ValueError):
                pass
        elif not unreadable and space > 60:
            box_w = min(space - 34, b.measure(short(name), 16, 'extra') + 28)
            b.shape(px, y + (h - picture_h) / 2, box_w, picture_h, 14, RAISED_BOTTOM, None, RAISED_LINE)
            b.text(px + 14, y + h / 2, short(name), 16, 'extra', SOFT, fit=box_w - 28)
            icon_arrow(b, px + box_w + 17, y + h / 2, GOLD, ())
            px += box_w + 34
        look_w = b.measure('Look up', 15) + 32
        field_w = x + w - 12 - look_w - 8 - px
        field_h = min(44, h - 24)
        field_y = y + (h - field_h) / 2
        b.shape(px, field_y, field_w, field_h, 14, FIELD, None, GOLD, 2)
        entry = b.entry(('fix', name), px + 12, field_y + 3, field_w - 24, field_h - 6,
                        value='' if unreadable else short(name),
                        on_enter=lambda n=name: self._fix_from_row(n), size=16)
        b.button(x + w - 12 - look_w, field_y, 'Look up', lambda n=name: self._fix_from_row(n), 'gold', field_h, 15,
                 width=look_w, radius=14)
        error = self.errors_by_name.get(name, '')
        if error and 'No close name match' not in error and 'exactly that name' not in error and not unreadable:
            b.text(text_x, y + h - 8, error, 11, 'bold', WARN_TEXT, fit=w - 100)

    def _fix_from_row(self, name):
        entry = self.board.widgets.get(('fix', name))
        if entry is not None:
            self._fix_unread(name, typed(entry))
