"""Extra player data from RivalsData's public API: rank now, who they queue with,
match penalties, live match, per-hero detail, session and rank-goal maths.

Every call is read-only and best-effort: if RivalsData is down, the rest of
Scout keeps working and these parts are simply left out.
"""
import time

from scout.stats.tracker import (HERO_NAMES, StatsError, _num, get_recent_matches, hero_name_for, rank_name,
                                 rivalsdata_get, rivalsdata_post)

CURRENT_SEASON_KEY = '1001021'
HERO_IDS = {name.casefold(): hero_id for hero_id, name in HERO_NAMES.items() if len(hero_id) == 4}


PROFICIENCY_TIERS = ['Agent', 'Knight', 'Captain', 'Centurion', 'Lord', 'Count', 'Colonel', 'Warrior', 'Elite',
                     'Guardian', 'Champion']


def proficiency_tier(level):
    """In-game proficiency title for a level: a new title every 5 levels, Lord from 20 (marvelrivals.wiki.gg)."""
    return PROFICIENCY_TIERS[max(0, min(len(PROFICIENCY_TIERS) - 1, int(level) // 5))]


def mastery_badge(level):
    """'Champion' from level 50, 'Lord' from 20, otherwise nothing (lower titles aren't worth showing)."""
    level = int(level or 0)
    return 'Champion' if level >= 50 else 'Lord' if level >= 20 else ''


def _uid(uid):
    return int(uid) if str(uid).isdecimal() else None


def player_now(uid):
    """{'level', 'score', 'rank', 'battle'}: this season's rank and the match they're in now (or None)."""
    payload = _uid(uid)
    if payload is None:
        return {}
    try:
        data = rivalsdata_post('/player', {'uid': payload})
    except StatsError:
        return {}
    if not isinstance(data, dict):
        return {}
    seasons = data.get('rank_game_season') if isinstance(data.get('rank_game_season'), dict) else {}
    current = seasons.get(CURRENT_SEASON_KEY) if isinstance(seasons.get(CURRENT_SEASON_KEY), dict) else {}
    level = int(_num(current.get('level')))
    status = data.get('status') if isinstance(data.get('status'), dict) else {}
    battle = status.get('battle_id')
    return {'level': level, 'score': _num(current.get('rank_score')), 'rank': rank_name(level) if level else '',
            'games': int(_num(current.get('battle_count'))), 'wins': int(_num(current.get('win_count'))),
            'battle': str(battle) if battle else None}


def teammates(uid):
    """People they queue with most: [{'name', 'uid', 'games', 'wins'}]."""
    payload = _uid(uid)
    if payload is None:
        return []
    try:
        rows = rivalsdata_post('/player/teammates', {'uid': payload})
    except StatsError:
        return []
    mates = []
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, dict) and row.get('name'):
            mates.append({'name': str(row['name']), 'uid': str(row.get('teammate_uid') or ''),
                          'games': int(_num(row.get('games'))), 'wins': int(_num(row.get('wins')))})
    return sorted(mates, key=lambda m: -m['games'])


def match_penalties(uid, days=60):
    """How many match penalties (leaving or idling, not chat) they got in the last `days` days."""
    payload = _uid(uid)
    if payload is None:
        return 0
    try:
        data = rivalsdata_post('/player/punishments', {'uid': payload})
    except StatsError:
        return 0
    history = data.get('history') if isinstance(data, dict) else None
    since = time.time() - days * 86400
    return sum(1 for row in history or [] if isinstance(row, dict) and str(row.get('kind')) != 'chat'
               and _num(row.get('time')) >= since)


def find_stacks(enemies):
    """Enemies who queue together. `enemies` maps a name to that player's teammates list.
    Returns [(name, name, games together)] for pairs with 3 or more games."""
    pairs = {}
    names = {name.casefold(): name for name in enemies}
    for name, mates in enemies.items():
        for mate in mates or []:
            other = names.get(mate['name'].casefold())
            if other and other != name and mate['games'] >= 3:
                key = tuple(sorted((name, other), key=str.casefold))
                pairs[key] = max(pairs.get(key, 0), mate['games'])
    return sorted(((a, b, games) for (a, b), games in pairs.items()), key=lambda row: -row[2])


def session(matches, gap_hours=1.5, now=None):
    """Tonight's games: the newest run of matches with no break longer than `gap_hours`,
    if the newest one was within the last 6 hours."""
    now = time.time() if now is None else now
    games = sorted((m for m in matches or [] if m.get('when')), key=lambda m: -m['when'])
    if not games or now - games[0]['when'] > 6 * 3600:
        return None
    run = [games[0]]
    for game in games[1:]:
        if run[-1]['when'] - game['when'] > gap_hours * 3600:
            break
        run.append(game)
    wins = sum(1 for g in run if g['won'])
    points = sum(g['change'] for g in run if g.get('change') is not None)
    heroes = {}
    for game in run:
        if game.get('hero'):
            stat = heroes.setdefault(game['hero'], [0, 0])
            stat[0] += 1
            stat[1] += 1 if game['won'] else 0
    best = max(heroes.items(), key=lambda item: (item[1][1], item[1][0]))[0] if heroes else ''
    return {'games': len(run), 'wins': wins, 'points': points, 'best': best,
            'ranked': sum(1 for g in run if g.get('change') is not None), 'started': run[-1]['when']}


def score_for_level(level):
    """Ranked points where a division starts (Bronze III = 3000, each division 100 more)."""
    return 3000 + (int(level) - 1) * 100


def level_for_score(score):
    """The division a ranked score sits in (1 = Bronze III), the inverse of score_for_level."""
    return max(1, int((float(score) - 3000) // 100) + 1)


def rank_change(game):
    """('up' or 'down', rank before, rank after) if this ranked game crossed into another division."""
    from scout.stats.tracker import rank_name
    score, change = game.get('score'), game.get('change')
    if score is None or not change:
        return None
    before, after = level_for_score(score - change), level_for_score(score)
    if before == after:
        return None
    return ('up' if after > before else 'down', rank_name(before), rank_name(after))


def rank_goal(score, target_level, recent):
    """How far a rank target is: points to go and wins needed at their recent average gain."""
    if not score or not target_level:
        return None
    to_go = score_for_level(target_level) - score
    gains = [g['change'] for g in recent or [] if g.get('change') and g['change'] > 0]
    average = sum(gains) / len(gains) if gains else 30
    return {'to_go': to_go, 'wins': max(0, -(-to_go // average)) if to_go > 0 else 0, 'per_win': average,
            'target': rank_name(target_level)}


def hero_detail(uid, hero_name):
    """Their competitive numbers on one hero this season, next to everyone's average on it."""
    hero_id = HERO_IDS.get(hero_name.casefold())
    payload = _uid(uid)
    if hero_id is None or payload is None:
        raise StatsError("RivalsData has no detail for that hero.")
    rows = rivalsdata_post('/player/stats/heroes', {'uid': payload})
    mine = next((r for r in rows or [] if isinstance(r, dict) and str(r.get('hero_id')) == hero_id), None)
    comp = mine.get('competitive') if isinstance(mine, dict) else None
    quick = mine.get('quickplay') if isinstance(mine, dict) else None
    try:
        average = rivalsdata_get(f'/stats/heroes/{hero_id}').get('hero') or {}
    except (StatsError, AttributeError):
        average = {}

    def side(block):
        if not isinstance(block, dict):
            return None
        per_10 = block.get('per_10') if isinstance(block.get('per_10'), dict) else {}
        return {'games': int(_num(block.get('games'))), 'win': _num(block.get('winrate')), 'kda': _num(block.get('kda')),
                'accuracy': _num(block.get('accuracy'), None), 'mvps': int(_num(block.get('mvps'))),
                'svps': int(_num(block.get('svps'))),
                'per_10': {key: _num(per_10.get(key), None) for key in
                           ('damage', 'healing', 'damage_blocked', 'kills', 'deaths', 'assists', 'finals', 'solo_kills')}}

    everyone = {'win': _num(average.get('winrate_no_mirror'), None), 'pick': _num(average.get('pick_rate'), None),
                'ban': _num(average.get('ban_rate'), None),
                'per_10': {'damage': _num(average.get('dmg_per_10'), None), 'healing': _num(average.get('healing_per_10'), None),
                           'damage_blocked': _num(average.get('blocked_per_10'), None),
                           'kills': _num(average.get('kills_per_10'), None), 'deaths': _num(average.get('deaths_per_10'), None),
                           'assists': _num(average.get('assists_per_10'), None), 'finals': _num(average.get('finals_per_10'), None)}}
    return {'hero': hero_name_for(hero_id) or hero_name, 'competitive': side(comp), 'quickplay': side(quick), 'everyone': everyone}


def favorite_status(favorites):
    """Each favorite's newest game: {uid: match or None}. One request per favorite."""
    latest = {}
    for fav in favorites or []:
        games = get_recent_matches(fav.get('uid'))
        latest[fav.get('uid')] = games[0] if games else None
    return latest


RANK_ICON_URL = 'https://rivalsdata.com/assets/ranks/{}.webp'


def fetch_rank_icons():
    """Download the rank emblems RivalsData shows on its site into data/cache/ranks (once; small webp files).
    Anything that isn't a small, valid picture is thrown away."""
    import io
    import requests
    from PIL import Image
    from scout import paths
    from scout.ui.paint import RANK_SLUGS
    folder = paths.CACHE / 'ranks'
    folder.mkdir(parents=True, exist_ok=True)
    saved = 0
    for slug in RANK_SLUGS.values():
        target = folder / f'{slug}.webp'
        if target.is_file():
            continue
        try:
            response = requests.get(RANK_ICON_URL.format(slug), timeout=(5, 15), allow_redirects=False)
        except requests.RequestException:
            continue
        body = response.content
        if response.status_code != 200 or not response.headers.get('content-type', '').startswith('image/') or len(body) > 200_000:
            continue
        try:
            with Image.open(io.BytesIO(body)) as image:
                image.verify()
        except Exception:
            continue
        target.write_bytes(body)
        saved += 1
    return saved


# ---- today's insights ------------------------------------------------------------------
STAT_KEYS = ('damage', 'healing', 'blocked', 'kills', 'deaths', 'assists')


def season_baseline(uid):
    """Their usual numbers per 10 minutes this season (all heroes, ranked and quick play together).
    Per 10 minutes, not per game: RivalsData's per-game figures don't line up with its match records, but its
    per-10-minute ones do, and it also keeps short and long games comparable."""
    payload = _uid(uid)
    if payload is None:
        return {}
    try:
        rows = rivalsdata_post('/player/stats/heroes', {'uid': payload})
    except StatsError:
        return {}
    totals = {key: 0.0 for key in STAT_KEYS}
    games = hits = hit_games = 0
    for row in rows if isinstance(rows, list) else []:
        for mode in ('competitive', 'quickplay'):
            block = row.get(mode) if isinstance(row, dict) else None
            per_game = block.get('per_10') if isinstance(block, dict) else None
            if not isinstance(per_game, dict):
                continue
            count = _num(block.get('games'))
            games += count
            for key, field in zip(STAT_KEYS, ('damage', 'healing', 'damage_blocked', 'kills', 'deaths', 'assists')):
                totals[key] += _num(per_game.get(field)) * count
            if block.get('accuracy') is not None:
                hits += _num(block.get('accuracy')) * count
                hit_games += count
    if not games:
        return {}
    base = {key: value / games for key, value in totals.items()}
    base['kda'] = (base['kills'] + base['assists']) / max(base['deaths'], .1)
    base['accuracy'] = hits / hit_games if hit_games else None
    base['games'] = int(games)
    return base


def _my_line(body, uid):
    """Their row in one match (from RivalsData's /match), plus how it compares with the other 11."""
    players = []
    for team in (body.get('teams') if isinstance(body, dict) else None) or []:
        for row in team.get('players') or [] if isinstance(team, dict) else []:
            if isinstance(row, dict):
                players.append(row)
    me = next((p for p in players if str(p.get('player_uid')) == str(uid)), None)
    if me is None:
        return None
    line = {key: _num(me.get(field)) for key, field in zip(STAT_KEYS, ('damage', 'healing', 'blocked', 'kills', 'deaths', 'assists'))}
    line['accuracy'] = _num(me.get('accuracy'), None)
    line['finals'] = _num(me.get('final_hits'))
    others = [p for p in players if p is not me]
    line['damage_rank'] = 1 + sum(1 for p in others if _num(p.get('damage')) > line['damage'])
    line['lobby_damage'] = sum(_num(p.get('damage')) for p in others) / len(others) if others else None
    line['seconds'] = _num(body.get('duration_seconds'))
    return line


def todays_insights(uid, matches=None, now=None, limit=15):
    """How tonight went, next to their usual season numbers. None if they haven't played in the last few hours."""
    matches = get_recent_matches(uid) if matches is None else matches
    run = session(matches, now=now)
    if not run:
        return None
    games = sorted((m for m in matches if m.get('when') and m['when'] >= run['started']), key=lambda m: m['when'])[-limit:]
    for game in games:
        try:
            game['line'] = _my_line(rivalsdata_post('/match', {'match_id': game['id']}), uid)
        except StatsError:
            game['line'] = None
    base = season_baseline(uid)
    lines = [g['line'] for g in games if g.get('line')]
    today = {}
    minutes = sum(l['seconds'] for l in lines) / 60
    if lines and minutes:
        for key in STAT_KEYS:
            today[key] = sum(l[key] for l in lines) / minutes * 10   # per 10 minutes, like the season numbers
        today['kda'] = (today['kills'] + today['assists']) / max(today['deaths'], .1)
        accuracy = [l['accuracy'] for l in lines if l['accuracy'] is not None]
        today['accuracy'] = sum(accuracy) / len(accuracy) if accuracy else None
        today['finals'] = sum(l['finals'] for l in lines) / len(lines)
        today['top_damage'] = sum(1 for l in lines if l['damage_rank'] == 1)
        today['seconds'] = sum(l['seconds'] for l in lines)
    placements = [g['placement'] for g in games if g.get('placement')]
    # Streaks (oldest to newest).
    longest = current = 0
    for game in games:
        current = current + 1 if game['won'] else 0
        longest = max(longest, current)
    last = games[-1]['won']
    tail = 0
    for game in reversed(games):
        if game['won'] != last:
            break
        tail += 1
    ranked = [g for g in games if g.get('change') is not None]
    heroes = {}
    for game in games:
        stat = heroes.setdefault(game['hero'] or 'Unknown', {'games': 0, 'wins': 0, 'k': 0, 'd': 0, 'a': 0, 'damage': 0, 'with_line': 0})
        stat['games'] += 1
        stat['wins'] += 1 if game['won'] else 0
        stat['k'] += game['kills']
        stat['d'] += game['deaths']
        stat['a'] += game['assists']
        if game.get('line'):
            stat['damage'] += game['line']['damage']
            stat['with_line'] += 1
    hero_rows = sorted(({'hero': name, **s, 'kda': (s['k'] + s['a']) / max(s['d'], 1),
                         'avg_damage': s['damage'] / s['with_line'] if s['with_line'] else None} for name, s in heroes.items()),
                       key=lambda r: (-r['games'], -r['wins']))

    def score(game):
        # Lobby place counts most, then KDA (capped so one 22/1 stomp doesn't beat an MVP carry), then MVP.
        kda = (game['kills'] + game['assists']) / max(game['deaths'], 1)
        return -(game.get('placement') or 6) * 2 + min(kda, 10) + (3 if game['mvp'] else 0) + (1 if game['won'] else 0)

    best = max(games, key=score)
    worst = min(games, key=score)
    result = {'games': games, 'record': (run['wins'], run['games'] - run['wins']), 'points': run['points'],
              'ranked': len(ranked), 'today': today, 'base': base, 'heroes': hero_rows, 'best': best, 'worst': worst,
              'placement': sum(placements) / len(placements) if placements else None,
              'mvps': sum(1 for g in games if g['mvp']), 'svps': sum(1 for g in games if g['svp']),
              'longest_win_streak': longest, 'streak': (tail, last)}
    if ranked:
        result['rank_from'] = ranked[0]['score'] - ranked[0]['change'] if ranked[0].get('score') is not None else None
        result['rank_to'] = ranked[-1].get('score')
    result['takeaways'] = takeaways(result)
    return result


def _change(today, base, key):
    if not base or base.get(key) in (None, 0) or today.get(key) is None:
        return None
    return (today[key] - base[key]) / base[key] * 100


def takeaways(insight):
    """Plain-language notes about tonight: (text, 'good' | 'bad' | 'info')."""
    notes = []
    today, base = insight['today'], insight['base']
    wins, losses = insight['record']
    damage = _change(today, base, 'damage')
    if damage is not None and abs(damage) >= 10:
        notes.append((f"Your damage is {abs(damage):.0f}% {'above' if damage > 0 else 'below'} your season average "
                      f"({today['damage'] / 1000:.1f}k per 10 min vs {base['damage'] / 1000:.1f}k).", 'good' if damage > 0 else 'bad'))
    deaths = _change(today, base, 'deaths')
    if deaths is not None and abs(deaths) >= 15:
        notes.append((f"You're dying {abs(deaths):.0f}% {'more' if deaths > 0 else 'less'} than usual "
                      f"({today['deaths']:.1f} per 10 min vs {base['deaths']:.1f}).", 'bad' if deaths > 0 else 'good'))
    kda = _change(today, base, 'kda')
    if kda is not None and abs(kda) >= 15 and not notes:
        notes.append((f"KDA {today['kda']:.1f} tonight vs {base['kda']:.1f} usually.", 'good' if kda > 0 else 'bad'))
    if insight['placement'] is not None and insight['placement'] <= 3:
        notes.append((f"You averaged #{insight['placement']:.1f} in your lobbies. That's carrying.", 'good'))
    elif insight['placement'] is not None and insight['placement'] >= 8:
        notes.append((f"You averaged #{insight['placement']:.1f} of 12 in your lobbies.", 'bad'))
    for hero in insight['heroes']:
        if hero['games'] >= 3 and hero['wins'] / hero['games'] >= .7:
            notes.append((f"{hero['hero']} is working: {hero['wins']}-{hero['games'] - hero['wins']} tonight with a "
                          f"{hero['kda']:.1f} KDA.", 'good'))
            break
    for hero in insight['heroes']:
        if hero['games'] >= 2 and hero['wins'] == 0:
            notes.append((f"{hero['hero']} went 0-{hero['games']}. Maybe swap off it for now.", 'bad'))
            break
    if insight['mvps'] >= 3:
        notes.append((f"{insight['mvps']} MVPs tonight.", 'good'))
    count, won = insight['streak']
    if not won and count >= 3:
        notes.append((f"You've lost the last {count}. A short break might help.", 'bad'))
    elif won and count >= 3:
        notes.append((f"On a {count}-game win streak.", 'good'))
    if insight['ranked'] and insight['points']:
        notes.append((f"{'+' if insight['points'] > 0 else ''}{insight['points']:.0f} ranked points over "
                      f"{insight['ranked']} ranked games.", 'good' if insight['points'] > 0 else 'bad'))
    return notes[:6]


# ---- enemy recent form and team comp ---------------------------------------------------------
def recent_form(matches, count=10):
    """How someone's last `count` games went: record, current streak, what they've been playing.

    streak is +n for n wins in a row, -n for n losses in a row (newest game first)."""
    games = sorted((m for m in matches or [] if m.get('when')), key=lambda m: -m['when'])[:count]
    if not games:
        return None
    streak = 0
    for game in games:
        if streak >= 0 and game['won']:
            streak += 1
        elif streak <= 0 and not game['won']:
            streak -= 1
        else:
            break
    heroes = {}
    for game in games:
        if game.get('hero'):
            heroes[game['hero']] = heroes.get(game['hero'], 0) + 1
    top = max(heroes.items(), key=lambda item: item[1]) if heroes else ('', 0)
    points = sum(g['change'] for g in games if g.get('change') is not None)
    return {'games': len(games), 'wins': sum(1 for g in games if g['won']), 'streak': streak,
            'heroes': heroes, 'top': top[0], 'top_games': top[1], 'points': points}


def form_tag(form):
    """'HOT' on 3+ wins in a row, 'COLD' on 3+ losses in a row, else ''."""
    if not form:
        return ''
    return 'HOT' if form['streak'] >= 3 else 'COLD' if form['streak'] <= -3 else ''


def likely_hero(season_heroes, form):
    """The hero someone will most likely pick: what they've played lately if it's clear, else their season main."""
    if form and form.get('top') and form.get('top_games', 0) >= 4:
        return form['top']
    return season_heroes[0] if season_heroes else ''


COMP_TIPS = (
    (lambda c: c['Strategist'] == 0, 'No healers: take fights early, they can\'t sustain.'),
    (lambda c: c['Strategist'] == 1, 'Only one healer: dive them first.'),
    (lambda c: c['Vanguard'] == 0, 'No tank: push in, they have nothing to hide behind.'),
    (lambda c: c['Strategist'] >= 3, 'Healer-heavy: focus one target together to break the healing.'),
    (lambda c: c['Vanguard'] >= 3, 'Tank-heavy: bring steady damage and expect long fights.'),
    (lambda c: c['Duelist'] >= 4, 'Damage-heavy: play near cover and stay close to your healers.'),
)


def comp_read(heroes):
    """Role counts for a list of likely enemy picks plus one plain tip. None if under 4 roles are known."""
    from scout.stats.advisor import role_for
    counts = {'Vanguard': 0, 'Duelist': 0, 'Strategist': 0}
    for hero in heroes:
        role = role_for(hero) if hero else ''
        if role in counts:
            counts[role] += 1
    if sum(counts.values()) < 4:
        return None
    tip = next((text for test, text in COMP_TIPS if test(counts)), '')
    return {'counts': counts, 'tip': tip}


def tilt_note(matches):
    """A short nudge after 3+ losses in a row, else ''."""
    form = recent_form(matches, 6)
    if form and form['streak'] <= -3:
        return f"{-form['streak']} losses in a row. A short break usually helps."
    return ''


# ---- match medals and grades ------------------------------------------------------------------
MEDALS = (
    ('damage', 'DMG', 'Most damage in the match', max),
    ('heal', 'HEAL', 'Most healing in the match', max),
    ('blocked', 'BLOCK', 'Most damage blocked in the match', max),
    ('kills', 'KILLS', 'Most kills in the match', max),
    ('assists', 'ASSISTS', 'Most assists in the match', max),
    ('deaths', 'SURVIVOR', 'Fewest deaths in the match', min),
)
GRADES = ((1.5, 'SS'), (0.9, 'S'), (0.3, 'A'), (-0.3, 'B'), (-0.9, 'C'))  # how far above the lobby, in spreads


def _key(player):
    return player.get('uid') or player.get('name')


def match_grades(players):
    """Scout's own rating for each player in one match, next to the rest of that lobby.

    Returns {player key: {'grade': 'SS'..'F', 'score': float, 'medals': [(short, why), ...]}}.
    The score mixes each player's main job (damage, healing or blocking, whichever they did most of
    compared to the lobby), plus kills, assists, staying alive and the win. It's not the game's own rating.
    """
    if not players:
        return {}
    def top(field):
        return max(1.0, max(float(p.get(field) or 0) for p in players))
    tops = {f: top(f) for f in ('damage', 'heal', 'blocked', 'kills', 'assists', 'deaths')}
    impacts = {}
    for p in players:
        # Each role's main job, measured against the best in the lobby at that job.
        jobs = sorted((float(p.get(f) or 0) / tops[f] for f in ('damage', 'heal', 'blocked')), reverse=True)
        impact = jobs[0] + 0.3 * jobs[1]
        impact += 0.5 * float(p.get('kills') or 0) / tops['kills'] + 0.3 * float(p.get('assists') or 0) / tops['assists']
        impact -= 0.4 * float(p.get('deaths') or 0) / tops['deaths']
        impact += 0.15 if p.get('won') else 0
        impacts[_key(p)] = impact
    values = list(impacts.values())
    average = sum(values) / len(values)
    spread = max(0.05, (sum((v - average) ** 2 for v in values) / len(values)) ** 0.5)
    result = {}
    for p in players:
        z = (impacts[_key(p)] - average) / spread
        grade = next((label for limit, label in GRADES if z >= limit), 'F')
        result[_key(p)] = {'grade': grade, 'score': round(z, 2), 'medals': []}
    for field, short_name, why, pick in MEDALS:
        values = [float(p.get(field) or 0) for p in players]
        if field != 'deaths' and not any(values):
            continue
        best = pick(values)
        for p, value in zip(players, values):
            if value == best:
                result[_key(p)]['medals'].append((short_name, why))
    return result
