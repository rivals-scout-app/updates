"""Spot the competitive loading screen cheaply, so Scout can scan it by itself.

The check runs on a 320x180 copy of the screen and only looks at three fixed
spots that every competitive loading screen has:
  - the bright blue team word (ATTACK/DEFEND) at the top left,
  - the orange team word at the bottom right,
  - the big blue map name in the middle.
It takes a few milliseconds. The full name scan only runs after it matches.
"""
import ctypes
import numpy as np

SIZE = (320, 180)
# (x0, x1, y0, y1) as fractions of the screen.
TOP_LEFT_WORD = (.135, .25, .105, .17)
BOTTOM_RIGHT_WORD = (.76, .865, .81, .87)
MAP_NAME = (.38, .62, .38, .56)


def _region(array, box):
    x0, x1, y0, y1 = box
    h, w = array.shape[:2]
    return array[int(y0 * h):int(y1 * h), int(x0 * w):int(x1 * w)]


def color_fractions(hsv):
    """Share of word-like pixels in each spot (hsv: OpenCV HSV, uint8).

    A word pixel has the right hue and is clearly brighter than the middle of
    its own spot, so different brightness or gamma settings still match.
    """
    out = {}
    for name, box in (('top_left', TOP_LEFT_WORD), ('bottom_right', BOTTOM_RIGHT_WORD), ('map', MAP_NAME)):
        region = _region(hsv, box).astype(int)
        h, s, v = region[..., 0], region[..., 1], region[..., 2]
        bright = v > np.median(v) + 35
        out[name + '_blue'] = float((bright & (h >= 100) & (h <= 135) & (s > 60)).mean())
        out[name + '_orange'] = float((bright & ((h <= 22) | (h >= 172)) & (s > 90)).mean())
    return out


def looks_like_loading_screen(bgr):
    """bgr: full screenshot as an OpenCV BGR array."""
    import cv2
    small = cv2.resize(bgr, SIZE, interpolation=cv2.INTER_AREA)
    f = color_fractions(cv2.cvtColor(small, cv2.COLOR_BGR2HSV))
    # Words are letters, not solid fills: a real word covers part of its box.
    return (.10 <= f['top_left_blue'] <= .6 and f['top_left_orange'] < .03
            and .10 <= f['bottom_right_orange'] <= .6 and f['bottom_right_blue'] < .03
            and .05 <= f['map_blue'] <= .6 and f['map_orange'] < .03)


def scout_is_admin():
    """True if Scout itself runs as administrator, False if not, None if unknown. Only looks at Scout."""
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except (AttributeError, OSError):
        return None


def foreground_window():
    """(title, window class, pid) of the active window, or ('', '', 0) if unknown.

    Only window details are read (title and class name). Scout never opens the
    game's process, so nothing touches the game itself.
    """
    try:
        user = ctypes.windll.user32
        window = user.GetForegroundWindow()
        length = user.GetWindowTextLengthW(window)
        buffer = ctypes.create_unicode_buffer(length + 1)
        user.GetWindowTextW(window, buffer, length + 1)
        title = buffer.value
        pid = ctypes.c_ulong()
        user.GetWindowThreadProcessId(window, ctypes.byref(pid))
    except (AttributeError, OSError):
        return '', '', 0
    kind = ''
    try:
        buffer = ctypes.create_unicode_buffer(256)
        if user.GetClassNameW(window, buffer, 256):
            kind = buffer.value
    except (AttributeError, OSError):
        pass
    return title, kind, pid.value


def is_game(title, kind):
    """Marvel Rivals: its window is titled "Marvel Rivals" and is an Unreal Engine window.
    A browser tab titled "Marvel Rivals Tracker" is not the game."""
    title, kind = title.casefold().strip(), kind.casefold()
    if 'scout' in title or not ('marvel' in title and 'rivals' in title):
        return False
    return kind == 'unrealwindow' or title == 'marvel rivals' or not kind


def game_in_front():
    title, program, _ = foreground_window()
    return is_game(title, program)


def near_miss(parts):
    """Two of the three loading-screen signs present: worth saving for tuning."""
    signs = [parts['top_left_blue'] >= .08, parts['bottom_right_orange'] >= .08, parts['map_blue'] >= .04]
    return sum(signs) >= 2


class LoadingScreenWatcher:
    """Decides when to scan: `needed` matching checks in a row, then quiet until
    the loading screen has been gone for `rearm_after` checks in a row.

    feed(matched) returns True exactly once per loading screen.
    """
    def __init__(self, needed=2, rearm_after=1):
        self.needed = needed
        self.rearm_after = rearm_after
        self.hits = 0
        self.misses = 0
        self.armed = True

    def feed(self, matched):
        if not matched:
            self.hits = 0
            self.misses += 1
            if self.misses >= self.rearm_after:
                self.armed = True  # loading screen gone: ready for the next match
            return False
        self.misses = 0
        self.hits += 1
        if self.armed and self.hits >= self.needed:
            self.armed = False
            return True
        return False
