"""Small signed updates for installed copies of Rivals Scout.

The publisher's PC signs every update with a private key that never leaves
it. An installed Scout downloads latest.json and its signature from the
updates folder of github.com/rivals-scout-app/updates, checks the signature
with the public key built into it, checks the zip's SHA-256, and only then
replaces its own code. Anything that fails a check is thrown away.
"""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path, PurePosixPath

import requests

from scout import paths, version
from scout.update import ed25519

PUBLIC_KEY_FILE = Path(__file__).with_name('public_key.txt')
ALLOWED = ('src/', 'assets/', 'models/', 'START-HERE.md')
MAX_ZIP = 60 * 1024 * 1024


class UpdateError(Exception):
    pass


def public_key():
    try:
        return bytes.fromhex(PUBLIC_KEY_FILE.read_text(encoding='ascii').strip())
    except (OSError, ValueError):
        return None


def enabled():
    """Only installed copies update themselves (not the folder you build from)."""
    return (paths.ROOT / 'runtime').is_dir() and public_key() is not None


def _get(url, limit):
    response = requests.get(url, timeout=(5, 30), stream=True)
    if response.status_code == 404:
        return None
    if response.status_code != 200:
        raise UpdateError(f'Update server answered {response.status_code}.')
    data = bytearray()
    for chunk in response.iter_content(65536):
        data += chunk
        if len(data) > limit:
            raise UpdateError('Update is larger than expected.')
    return bytes(data)


def check():
    """The newest signed update if it's newer than this copy, else None."""
    key = public_key()
    if key is None:
        return None
    manifest = _get(version.UPDATES + 'latest.json', 64 * 1024)
    signature = _get(version.UPDATES + 'latest.json.sig', 1024)
    if manifest is None or signature is None:
        return None
    try:
        signature = bytes.fromhex(signature.decode('ascii').strip())
    except ValueError:
        raise UpdateError('The update signature is damaged.') from None
    if not ed25519.verify(key, manifest, signature):
        raise UpdateError('The update is not signed by the Rivals Scout publisher, so it was ignored.')
    info = json.loads(manifest.decode('utf-8'))
    if int(info.get('build', 0)) <= version.BUILD:
        return None
    return info


def needs_setup(info):
    return int(info.get('runtime', 1)) > version.RUNTIME


def _safe_name(name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name:
        return False
    return any(name == allowed or (allowed.endswith('/') and name.startswith(allowed)) for allowed in ALLOWED)


def install(info, progress=None):
    """Download, check and unpack the update over this copy. Old code is kept in data/cache/previous."""
    name = str(info.get('zip', ''))
    if not name or '/' in name or '\\' in name or not name.endswith('.zip'):
        raise UpdateError('The update list is damaged.')
    if progress:
        progress('Downloading the update…')
    data = _get(version.UPDATES + name, MAX_ZIP)
    if data is None:
        raise UpdateError('The update file is missing on the server.')
    if hashlib.sha256(data).hexdigest() != str(info.get('sha256', '')).lower():
        raise UpdateError('The downloaded update does not match its signed fingerprint, so it was not installed.')
    staging = paths.CACHE / 'update'
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True)
    archive = staging / name
    archive.write_bytes(data)
    if progress:
        progress('Checking the update…')
    with zipfile.ZipFile(archive) as bundle:
        members = [m for m in bundle.infolist() if not m.is_dir()]
        if not members or not any(m.filename.startswith('src/scout/') for m in members):
            raise UpdateError('The update has no Scout code in it.')
        for member in members:
            if not _safe_name(member.filename):
                raise UpdateError(f'The update has an unexpected file ({member.filename}), so it was not installed.')
        unpacked = staging / 'files'
        bundle.extractall(unpacked)
    if progress:
        progress('Installing the update…')
    previous = paths.CACHE / 'previous'
    shutil.rmtree(previous, ignore_errors=True)
    if (paths.ROOT / 'src').is_dir():
        shutil.copytree(paths.ROOT / 'src', previous / 'src', ignore=shutil.ignore_patterns('__pycache__'))
    # Replace the code folder so removed files go too; assets and models are added to.
    shutil.rmtree(paths.ROOT / 'src', ignore_errors=True)
    for source in unpacked.rglob('*'):
        if source.is_file():
            target = paths.ROOT / source.relative_to(unpacked)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    shutil.rmtree(staging, ignore_errors=True)
    return info.get('build')


def restart():
    """Open Scout again a moment after this copy closes."""
    import subprocess
    exe = paths.ROOT / 'Rivals Scout.exe'
    subprocess.Popen(['cmd', '/c', f'timeout /t 2 /nobreak >nul & start "" "{exe}"'],
                     cwd=str(paths.ROOT), creationflags=0x08000000)  # no console window
