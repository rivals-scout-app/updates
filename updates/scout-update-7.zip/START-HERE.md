# Rivals Scout

Reads the enemy team off the competitive loading screen, pulls their most-played ranked heroes from RivalsTracker (plus match lobbies and hero proficiency from RivalsData), and suggests who to ban. No sign-up or API key. Stats need internet.

## Your stats

Search yourself and press **This is me**. The start screen then shows tonight's record and points, a rank goal, and your favorites (press Add favorite on anyone's page). While the game is in front, Scout also checks every 30 seconds whether you're in a match and, if RivalsData shows it, fills both teams in without a scan.

## Start

- Double-click **Rivals Scout.exe**, or run **Install Rivals Scout.cmd** once for Desktop and Start menu shortcuts.
- Leave it open (it can be minimized) and queue a competitive match.

## Scanning

- **Auto-scan** (switch in the top bar, on by default): while Marvel Rivals is the active window, Scout checks the screen twice a second. When the loading screen shows up it scans once, then waits for the next match.
- **Scan now · F9** works any time. If F9 is taken, Scout uses Ctrl+Shift+F9 and shows that in the bottom corner.
- The **•••** menu has: open a screenshot, edit names, Mini bans, the sample screenshot, the history range and clear.
- The **search bar** looks up one player by exact name. Their heroes open in a small window; your bans don't change.

If scans come out black, switch the game to borderless or windowed.

## Reading the screen

- **Ban these**: the top ban in coral with why (how many enemies play it, win rate, KDA), then two more. Click a ban for the full reasons. The pill at the top right picks how much history to use.
- **Enemy team**: one row per player with their top 3 heroes: win rate, games, kills / deaths / assists per game and KDA (green 4+, yellow 2.5+, red below).
  - **ONE-TRICK**: a hero that makes up half or more of that player's games (20+ games).
  - **▲ / ▼** after games: this season's win rate is 3+ points above or below their longer history.
  - **read as …**: the scan misread a letter and Scout found the right player.
  - **Hidden player**: they hide their name in game, so there's nothing to look up. Bans use the rest.
  - **Couldn't find this one** (yellow): shows the name as it looked on the loading screen next to a box. Fix the name and press Enter.
- **Your team**: your teammates with their most-played hero. Heroes your team plays a lot count lower as bans. **Edit picks** adds planned picks and existing bans.
- **Mini bans** (••• menu): a small always-on-top window with the top 3 bans.

## Good to know

- If a scanned name finds nobody, Scout reads the name picture again 16 different ways and looks those up too. It only takes a player whose name matches a reading letter for letter (allowing look-alikes like 1/l/i), and if readings point at different players it picks nobody.
- Names you type are looked up exactly as written.
- Found players are remembered in `data\player-ids.json`, so repeat lookups are faster.

## Installing it (for you or a friend)

Run **Build installer.cmd** and pick **1** (for you) or **2** (for a friend). After a few minutes you get one file, `dist\Rivals Scout Setup.exe`, with Python, the scanner and the text reader inside.

- Double-click it and press **Install**. Scout goes in your user folder (no admin needed), the Start menu and, if you want, the Desktop.
- Running a newer Setup later updates Scout and keeps settings and remembered players.
- To remove it: Windows Settings > Apps > Rivals Scout > Uninstall.
- Your copy brings your settings and remembered players along. A friend's copy starts fresh and shows an unverified-ban-risk notice each time it opens.

## Sending updates to friends

Copies installed with Setup check for updates when they open (and every few hours) and show **Update ready** in the top bar.

- Run **Publish update.cmd**, type a line about what changed, press Enter. It raises the build number, packs the code (about 1 MB), signs it and pushes it to github.com/rivals-scout-app/updates. The first time, Git asks you to log in to GitHub.
- Updates are signed with a key kept in `%APPDATA%\Rivals Scout\update-signing-key.txt`. Scout refuses anything not signed with it, so nobody else can push code to your friends even with access to the GitHub page. Don't share that file; if it's lost, friends need a new Setup to keep getting updates.
- Changes to Python or its packages still need a new Setup (Build installer.cmd).

## What's in this folder

- `Rivals Scout.exe`: starts the app. `Install Rivals Scout.cmd`: adds shortcuts for this folder. `Build installer.cmd`: makes the one-file Setup. `Publish update.cmd`: sends a signed update to installed copies.
- `src\scout\`: the app. `app.py` runs it; `reading\` scans the screen and reads names; `stats\` looks players up and picks bans; `ui\` draws the windows; `system\` is the F9 key.
- `assets\`: icon, hero pictures, the font and a sample screenshot. `models\`: the name finder. `tools\`: the text reader and the installer builder.
- `data\`: made by Scout: settings, remembered players, the last 30 scans and `scout.log`. Delete it to start fresh.
- `tests\`: automated checks. `dev\`: extras for changing Scout (old command-line version, model training).
