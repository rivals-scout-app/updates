"""Starts Rivals Scout. Rivals Scout.exe runs this file; the app itself is in scout/."""
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def report_crash():
    """If Scout can't even start, say why instead of closing silently."""
    details = traceback.format_exc()
    target = Path(__file__).resolve().parent.parent / 'data' / 'startup-error.txt'
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(details, encoding='utf-8')
    except OSError:
        pass
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, 'Rivals Scout could not start.\n\n' + details[-1500:] +
                                         f'\n\nSaved to {target}', 'Rivals Scout', 0x10)
    except Exception:
        pass


if __name__ == '__main__':
    try:
        from scout.app import launch
        launch()
    except Exception:
        report_crash()
        raise
