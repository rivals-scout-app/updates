"""Where Rivals Scout keeps things.

The program folder holds the code (src), pictures and fonts (assets), the
name finder (models) and the text reader (tools). Everything Scout writes
while running goes in data/: settings, remembered players, scans and the log.
"""
import os
import shutil
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[2]   # the folder that holds src/


def _find_root(start):
    for folder in [start, *start.parents]:
        if (folder / 'models' / 'best.pt').is_file() or (folder / 'models' / 'best.onnx').is_file():
            return folder
    return start


ROOT = _find_root(APP_DIR)
DATA = Path(os.environ['SCOUT_DATA']) if os.environ.get('SCOUT_DATA') else ROOT / 'data'  # tests use a temp folder
CACHE = DATA / 'cache'          # temp files for the libraries Scout uses
SCANS = DATA / 'scans'          # the last 30 captured loading screens
NAMES = DATA / 'names'          # the name pictures from the last scan
LOG = DATA / 'scout.log'
SETTINGS = DATA / 'settings.json'
MEMORY = DATA / 'player-ids.json'
LAST_CAPTURE = DATA / 'last-capture.png'
MODEL = ROOT / 'models' / 'best.pt'            # the original name finder (needs PyTorch)
MODEL_ONNX = ROOT / 'models' / 'best.onnx'     # the same finder, converted to run without PyTorch
TESSERACT = ROOT / 'tools' / 'tesseract' / 'tesseract.exe'
SHARED_FLAG = ROOT / 'shared-edition.json'


def asset(*parts):
    """A file from assets/, looking beside the code first, then in the main folder."""
    for base in (APP_DIR, ROOT):
        path = base.joinpath('assets', *parts)
        if path.exists():
            return path
    return ROOT.joinpath('assets', *parts)


def prepare():
    """Make data/ and bring over files from the old layout (copied, never moved)."""
    for folder in (DATA, CACHE, SCANS, NAMES):
        folder.mkdir(parents=True, exist_ok=True)
    old = {ROOT / 'settings.json': SETTINGS, ROOT / 'player-ids.json': MEMORY,
           ROOT / 'tmp' / 'players.png': LAST_CAPTURE}
    for source, target in old.items():
        if source.is_file() and not target.exists():
            try:
                shutil.copy2(source, target)
            except OSError:
                pass
