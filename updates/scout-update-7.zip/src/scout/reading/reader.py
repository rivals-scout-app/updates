import os
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import cv2
import numpy as np
import pytesseract

from scout import paths
_MODEL = None


def _limit_tesseract_threads():
    """Run each Tesseract process on one thread, with no console window, without limiting the detector.

    Setting OMP_THREAD_LIMIT for the whole app also capped PyTorch, which
    printed "OMP: Warning #96" and ran detection on a single thread. The
    limit now goes only to the Tesseract processes.
    """
    module = pytesseract.pytesseract
    original = getattr(module, 'subprocess_args', None)
    if original is None or getattr(original, '_scout_limited', False):
        return
    def subprocess_args(*args, **kwargs):
        options = original(*args, **kwargs)
        env = dict(options.get('env') or os.environ)
        env['OMP_THREAD_LIMIT'] = '1'
        options['env'] = env
        if os.name == 'nt':
            # Never open a console window for the text reader (it would flash a command prompt
            # for every name read). Hiding the window alone isn't always enough.
            options['creationflags'] = options.get('creationflags', 0) | 0x08000000  # CREATE_NO_WINDOW
        return options
    subprocess_args._scout_limited = True
    module.subprocess_args = subprocess_args


_limit_tesseract_threads()

def reconcile_digits(primary, alternate):
    """Accept only visually corroborated 1/I/l substitutions, never new names."""
    primary = ' '.join(primary.split())
    alternate = ' '.join(alternate.split())
    if not primary or '1' not in alternate:
        return primary
    # Raw-line OCR can add punctuation from the crop edges. Match the entire
    # original name within it; all non-ambiguous characters must remain exact.
    matches = []
    for start in range(max(0, len(alternate) - len(primary) + 1)):
        candidate = alternate[start:start + len(primary)]
        if all(a == b or (a in 'iIl1' and b in 'iIl1')
               for a, b in zip(primary, candidate)):
            matches.append(candidate)
    if len(matches) != 1:
        return primary
    return ''.join('1' if a in 'iIl' and b == '1' else a
                   for a, b in zip(primary, matches[0]))


HIDDEN = '\x00hidden'
# Name text is bright; the divider before it is dimmer and should not be read.
TEXT_THRESHOLD = 140


def looks_masked(gray):
    """True for names shown as *****1: four or more small marks in the top half."""
    ink = np.asarray(gray) > 140
    if np.count_nonzero(ink.any(axis=1)) < 6:
        return False
    cols = ink.any(axis=0)
    marks = []
    start = None
    for x in range(len(cols) + 1):
        on = x < len(cols) and cols[x]
        if on and start is None:
            start = x
        if not on and start is not None:
            rows = np.flatnonzero(ink[:, start:x].any(axis=1))
            marks.append((rows[0], rows[-1] + 1))
            start = None
    # Measure the text line from the first marks only: an icon after the
    # name is taller than the text and would make every letter look "high".
    first = marks[:6]
    top = min(m[0] for m in first)
    height = max(m[1] for m in first) - top
    if height < 6:
        return False
    # The stars are the start of the name, so the run has to begin at the
    # first or second mark.
    run = best = 0
    for index, (glyph_top, glyph_bottom) in enumerate(marks):
        high = (glyph_top - top) <= .15 * height and (glyph_bottom - top) <= .6 * height
        run = run + 1 if high else 0
        if run and index - run + 1 <= 1:
            best = max(best, run)
    return best >= 4


MASK_BANDS = ((.22, .82), (.18, .85), (.26, .80), (.15, .75), (.1, .7), (.28, .88))


def name_is_masked(gray):
    """Check a few row bands, since the box can sit a little high or low on the bar."""
    height = gray.shape[0]
    return any(looks_masked(gray[int(height * top):int(height * bottom)]) for top, bottom in MASK_BANDS)


# How Tesseract tends to read ***** in the game font.
STAR_TEXT = re.compile(r'[HKEXRDT#*\[\]]{5,6}[0-9A-Z\]]?')
LEADING_JUNK = '\\|/!‘’\'"“”`~-,:;'
TRAILING_JUNK = '\\|/!‘’\'"“”`~-,:;°*'


def name_words(data, height, scale, border, colour=None):
    """Keep the words of the name; drop the icon or title that follows it.

    Tesseract reads the icon after a name as a short extra "word". It always
    starts after a wider gap than any space inside a name (about 0.4 of the
    bar height versus about 0.3), so trailing words after a wide gap go.
    Icons sit closer sometimes ("dindead aS"), but they are colourful while
    name text is plain, so a trailing word much more colourful than the
    first word goes too. A very wide gap means a card title, whatever its size.
    """
    words = []
    for index, text in enumerate(data['text']):
        text = text.strip()
        if not text:
            continue
        left = (data['left'][index] - border) / scale
        words.append([text, left, left + data['width'][index] / scale])
    if colour is not None and words:
        first = colour(words[0][1], min(words[0][2], words[0][1] + 2 * height))
    for index in range(1, len(words)):
        gap = words[index][1] - words[index - 1][2]
        width = words[index][2] - words[index][1]
        if (gap >= .38 * height and width <= 1.7 * height) or gap >= .8 * height or (
                colour is not None and colour(words[index][1], words[index][2]) - first > .2):
            # Everything from here on is the icon or the card title.
            del words[index:]
            break
    return words


def ink_colour(crop):
    """Share of bright pixels that are strongly coloured, per x range."""
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    height = crop.shape[0]
    band = slice(int(height * .2), int(height * .8))
    bright = hsv[band, :, 2] > 140
    coloured = bright & (hsv[band, :, 1] > 90)

    def share(left, right):
        left, right = max(0, int(left)), min(crop.shape[1], int(right + .5))
        total = int(bright[:, left:right].sum())
        return coloured[:, left:right].sum() / total if total else 0.0
    return share


def clean_name(text):
    words = text.split()
    # Drop leading/trailing "words" with no letters or digits (icon specks).
    while words and not any(ch.isalnum() for ch in words[-1]):
        words.pop()
    # An icon read as text usually carries symbols a name can't have ("»aak").
    while len(words) > 1 and any(not (ch.isalnum() or ch in '._-') for ch in words[-1]):
        words.pop()
    while words and not any(ch.isalnum() for ch in words[0]):
        words.pop(0)
    text = ' '.join(words).lstrip(LEADING_JUNK).rstrip(TRAILING_JUNK)
    return text.strip()


def read_name(crop, trimmed=False, box_width=None):
    height, width = crop.shape[:2]
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    # Check for the hidden-name stars only where the name box was, so a
    # starry icon next to a name doesn't count.
    if name_is_masked(gray[:, :box_width or width]):
        return HIDDEN
    big = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    binary = cv2.threshold(big, TEXT_THRESHOLD, 255, cv2.THRESH_BINARY_INV)[1]
    # Card borders show up as long solid lines above or below the name and
    # stop Tesseract from reading anything. Letters never fill a whole row.
    solid = (binary == 0).mean(axis=1) > .8
    edge = np.zeros_like(solid)
    edge[:int(len(edge) * .3)] = True
    edge[int(len(edge) * .75):] = True
    binary[solid & edge] = 255
    binary = cv2.copyMakeBorder(binary, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
    data = pytesseract.image_to_data(binary, config='--oem 3 --psm 7 -l eng',
                                     output_type=pytesseract.Output.DICT)
    colour = ink_colour(crop)
    words = name_words(data, height, 3, 12, colour)
    if not words:
        # Second try, only when nothing was read: keep just the text rows.
        retry = cv2.threshold(big, TEXT_THRESHOLD, 255, cv2.THRESH_BINARY_INV)[1]
        retry[:int(retry.shape[0] * .18)] = 255
        retry[int(retry.shape[0] * .85):] = 255
        retry[(retry == 0).mean(axis=1) > .45] = 255
        retry = cv2.copyMakeBorder(retry, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
        data = pytesseract.image_to_data(retry, config='--oem 3 --psm 7 -l eng',
                                         output_type=pytesseract.Output.DICT)
        words = name_words(data, height, 3, 12, colour)
    if not words:
        return ''
    read = [(data['left'][i] - 12) / 3 for i, t in enumerate(data['text']) if t.strip()]
    if not trimmed and len(read) > len(words):
        # Something after the name was dropped (icon, title). Read again
        # without it: next to an icon the last letter is often misread.
        cut = int((words[-1][2] + read[len(words)]) / 2)
        if cut > words[-1][2] + 1:
            again = read_name(crop[:, :cut], trimmed=True)
            if again and again != HIDDEN:
                return again
    text = clean_name(' '.join(word[0] for word in words))
    if STAR_TEXT.fullmatch(text):
        return HIDDEN  # stars that the image check missed, read as letters
    end = min(width, int(words[-1][2]) + 4)
    if any(letter in text for letter in 'iIl'):
        # The condensed game font loses the cap/foot of 1 in normal line OCR.
        # A tighter single-word pass preserves those features. Only agree on
        # digit substitutions; never search unrelated usernames as alternatives.
        tight = crop[int(height * .12):int(height * .72), min(3, end - 1):end]
        if tight.size:
            tight = cv2.cvtColor(tight, cv2.COLOR_BGR2GRAY)
            tight = cv2.resize(tight, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
            tight = cv2.threshold(tight, TEXT_THRESHOLD, 255, cv2.THRESH_BINARY_INV)[1]
            tight = cv2.copyMakeBorder(tight, 15, 15, 15, 15, cv2.BORDER_CONSTANT, value=255)
            alternate = pytesseract.image_to_string(tight, config='--oem 3 --psm 8 -l eng -c load_system_dawg=0 -c load_freq_dawg=0')
            text = reconcile_digits(text, alternate)
    return text

# Loading screen layout (any 16:9 size): each team has six name bars, one
# bar pitch apart, and the bars slant left as they go down.
ROW_PITCH = 83.4 / 720          # of screen height
FIRST_ROW = {'left': 215 / 720, 'right': 131 / 720}   # name centre, row 1
SLANT = 20.4 / 83.4             # x moves left this much per pixel down


def missing_rows(rows, width, height):
    """Boxes for name bars the detector missed, placed from the layout.

    The detector sometimes skips a bar (a whole player vanished from a scan).
    The bars sit at fixed places, so a missed one is a found one shifted by
    whole rows. Only fills when the found boxes line up with the layout.
    """
    added = []
    pitch = ROW_PITCH * height
    for side in ('left', 'right'):
        found, odd = {}, False
        for row_side, (x1, y1, x2, y2), _ in rows:
            if row_side != side:
                continue
            centre = (y1 + y2) / 2
            spot = (centre / height - FIRST_ROW[side]) / ROW_PITCH
            index = round(spot)
            if abs(spot - index) > .3 or not 0 <= index < 6:
                odd = True  # not the layout we know; don't guess
                break
            found.setdefault(index, (x1, y1, x2, y2))
        if odd or not 2 <= len(found) < 6:
            continue
        for index in range(6):
            if index in found:
                continue
            near = min(found, key=lambda k: abs(k - index))
            x1, y1, x2, y2 = found[near]
            dy = (index - near) * pitch
            dx = -dy * SLANT
            # Wide enough for a long name; the masked check uses the first
            # part only (see get_roster).
            added.append((side, (x1 + dx, y1 + dy, x1 + dx + .085 * width, y2 + dy), True))
    return added


# Ways to read a name again when the first reading found nobody. Each one
# sees the letters a little differently (thicker, thinner, bigger, with or
# without the English word list), so one of them usually gets the hard
# letters right: 1 vs i vs l, J vs I, Z vs l, _ vs .
REREAD_PASSES = [(scale, threshold, words)
                 for scale in (3, 4)
                 for threshold in (120, 140, 165, 'otsu')
                 for words in (True, False)]


def _read_pass(crop, scale, threshold, words):
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    big = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    if threshold == 'otsu':
        binary = cv2.threshold(big, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    else:
        binary = cv2.threshold(big, threshold, 255, cv2.THRESH_BINARY_INV)[1]
    binary = cv2.copyMakeBorder(binary, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
    config = '--oem 3 --psm 7 -l eng'
    if not words:
        config += ' -c load_system_dawg=0 -c load_freq_dawg=0'
    data = pytesseract.image_to_data(binary, config=config, output_type=pytesseract.Output.DICT)
    kept = name_words(data, crop.shape[0], scale, 12, ink_colour(crop))
    text = clean_name(' '.join(word[0] for word in kept))
    return '' if STAR_TEXT.fullmatch(text) else text


def alternate_reads(path, first=''):
    """Other readings of a saved name image, most common first.

    Used only after the first reading found no player: the app searches these
    too and keeps a player only if a reading matches them letter for letter
    (allowing look-alike letters), so a re-read can't pick a stranger.
    """
    crop = cv2.imread(str(path))
    if crop is None or not crop.size:
        return []
    pytesseract.pytesseract.tesseract_cmd = os.environ.get(
        'TESSERACT_CMD', str(paths.TESSERACT))
    counts = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        for text in pool.map(lambda item: _read_pass(crop, *item), REREAD_PASSES):
            if text and len(text) >= 3 and text != first:
                counts[text] = counts.get(text, 0) + 1
    return sorted(counts, key=lambda text: -counts[text])


def load_model():
    """The name finder: the small converted copy if it's there, else the original (needs PyTorch)."""
    if paths.MODEL_ONNX.is_file():
        from scout.reading.detector import OnnxDetector
        return OnnxDetector(paths.MODEL_ONNX)
    os.environ['YOLO_OFFLINE'] = '1'  # no update checks or usage reports
    from ultralytics import YOLO, settings
    settings.update({'sync': False})
    return YOLO(str(paths.MODEL))


def get_roster(file_path):
    global _MODEL
    image = cv2.imread(str(file_path))
    if image is None:
        raise ValueError('Could not read the screenshot.')
    if _MODEL is None:
        _MODEL = load_model()
    result = _MODEL(image, verbose=False)[0]
    pytesseract.pytesseract.tesseract_cmd = os.environ.get(
        'TESSERACT_CMD', str(paths.TESSERACT))
    teams = {'left': [], 'right': []}
    height, width = image.shape[:2]
    crops = []
    kept = {'left': [], 'right': []}
    # Highest-confidence boxes first, so a duplicate box on the same name bar
    # (often with part of the icon) is dropped instead of taking a slot.
    def confidence(box):
        try:
            return float(box.conf[0])
        except (AttributeError, IndexError, TypeError):
            return 0.0
    chosen = []
    for box in sorted(result.boxes, key=confidence, reverse=True):
        class_id = int(box.cls[0])
        if class_id not in (0, 1):
            continue
        side = 'left' if class_id == 0 else 'right'
        _, top, _, bottom = map(float, box.xyxy[0])
        if any(min(bottom, b) - max(top, t) > .5 * min(bottom - top, b - t) for t, b in kept[side]):
            continue
        kept[side].append((top, bottom))
        chosen.append(box)
    # A box much thinner than the others is decoration (card frame trim), not a name bar.
    # Dropping it lets missing_rows put that slot where the bar really is.
    heights = sorted(float(b.xyxy[0][3]) - float(b.xyxy[0][1]) for b in chosen)
    if len(heights) >= 4:
        typical = heights[len(heights) // 2]
        chosen = [b for b in chosen if float(b.xyxy[0][3]) - float(b.xyxy[0][1]) >= .7 * typical]
    rows = []
    for box in chosen:
        side = 'left' if int(box.cls[0]) == 0 else 'right'
        rows.append((side, tuple(map(float, box.xyxy[0])), False))
    rows += missing_rows(rows, width, height)
    for side, (x1, y1, x2, y2), placed in sorted(rows, key=lambda row: row[1][1]):
        box_width = (4 if placed else 1e9) * (y2 - y1)
        box_width = int(min(box_width, x2 - x1))
        # Boxes often stop a letter or two early ("Imnoutan" for Imnoutanut).
        # Reading a little further is safe: the icon or title that follows
        # is dropped by name_words.
        x2 += 1.5 * (y2 - y1)
        x1, x2 = max(0, int(x1)), min(width, int(x2))
        y1, y2 = max(0, int(y1)), min(height, int(y2))
        if x2 <= x1 or y2 <= y1:
            continue
        crops.append((side, image[y1:y2, x1:x2], box_width))
    # Preserve detector order while reading both teams concurrently. No extra
    # network lookups are created by the secondary OCR pass.
    images = {}
    folder = paths.NAMES
    with ThreadPoolExecutor(max_workers=4) as pool:
      hidden = {'left': 0, 'right': 0}
      unreadable = {'left': 0, 'right': 0}
      names = pool.map(lambda item: read_name(item[1], box_width=item[2]), crops)
      for (side, crop, _), name in zip(crops, names):
        if name == HIDDEN:
            hidden[side] += 1
            name = f'Hidden player {hidden[side]}'
        elif not name:
            # Keep the slot so a missing player is visible, not silently dropped.
            unreadable[side] += 1
            name = f'Unreadable name {unreadable[side]}'
        if name and any(name.casefold().startswith(n.casefold() + ' ') for n in teams[side]):
            continue  # same name with icon junk on the end
        if name and name.casefold() not in {n.casefold() for n in teams[side]} and len(teams[side]) < 6:
            teams[side].append(name)
            # Keep the scanned name image so the card can show what was read.
            try:
                folder.mkdir(parents=True, exist_ok=True)
                path = folder / f'{side}{len(teams[side])}.png'
                if cv2.imwrite(str(path), crop):
                    images[name] = str(path)
            except Exception:
                pass
    if images:
        teams['images'] = images
    return teams


def get_players(file_path):
    # Compatibility for the command-line tool: enemy names on the right.
    return get_roster(file_path)['right']
