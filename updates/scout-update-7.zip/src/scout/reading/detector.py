"""Finds the name bars on a loading screen.

The name finder was trained with Ultralytics YOLO. The app runs a converted
copy of it (models/best.onnx) with onnxruntime, or OpenCV if onnxruntime isn't
there, so it doesn't need PyTorch (over a gigabyte). The steps here copy what
Ultralytics does: same resize and padding, same confidence and overlap rules,
so the boxes come out the same. tools/check_detector.py proves that on real
screenshots before an installer is built.
"""
import json
import os
from types import SimpleNamespace

import cv2
import numpy as np

CONFIDENCE = 0.25   # Ultralytics default
OVERLAP = 0.7       # Ultralytics default IoU for removing duplicate boxes
MAX_BOXES = 300
PAD_COLOR = 114
DEFAULT_INPUT = (384, 640)  # height, width: a 16:9 screen scaled to 640 wide, padded to a multiple of 32


def letterbox(image, size):
    """Scale to fit `size` (h, w) keeping the shape, pad the rest with grey, centred."""
    height, width = image.shape[:2]
    target_h, target_w = size
    gain = min(target_h / height, target_w / width)
    new_w, new_h = int(round(width * gain)), int(round(height * gain))
    pad_w, pad_h = (target_w - new_w) / 2, (target_h - new_h) / 2
    if (width, height) != (new_w, new_h):
        image = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(pad_h - 0.1)), int(round(pad_h + 0.1))
    left, right = int(round(pad_w - 0.1)), int(round(pad_w + 0.1))
    return cv2.copyMakeBorder(image, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(PAD_COLOR,) * 3)


def to_blob(image):
    """BGR picture -> 1x3xHxW float RGB in 0..1."""
    rgb = image[:, :, ::-1].transpose(2, 0, 1)
    return np.ascontiguousarray(rgb, dtype=np.float32)[None] / 255.0


def nms(boxes, scores, threshold):
    """Keep the best box, drop others that overlap it more than `threshold`, repeat."""
    order = scores.argsort()[::-1]
    keep = []
    areas = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
    while order.size:
        best = order[0]
        keep.append(best)
        rest = order[1:]
        x1 = np.maximum(boxes[best, 0], boxes[rest, 0])
        y1 = np.maximum(boxes[best, 1], boxes[rest, 1])
        x2 = np.minimum(boxes[best, 2], boxes[rest, 2])
        y2 = np.minimum(boxes[best, 3], boxes[rest, 3])
        overlap = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
        iou = overlap / (areas[best] + areas[rest] - overlap + 1e-9)
        order = rest[iou <= threshold]
    return np.array(keep, dtype=int)


def decode(output, image_shape, input_shape, confidence=CONFIDENCE, overlap=OVERLAP):
    """Model output (1, 4 + classes, N) -> rows of [x1, y1, x2, y2, score, class] on the original picture."""
    predictions = np.asarray(output)[0].T          # N x (4 + classes)
    scores_all = predictions[:, 4:]
    classes = scores_all.argmax(1)
    scores = scores_all[np.arange(len(classes)), classes]
    keep = scores > confidence
    predictions, classes, scores = predictions[keep], classes[keep], scores[keep]
    if not len(scores):
        return np.zeros((0, 6), dtype=np.float32)
    cx, cy, w, h = predictions[:, 0], predictions[:, 1], predictions[:, 2], predictions[:, 3]
    boxes = np.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], 1)
    # Each class is checked for duplicates separately (shift classes apart, like Ultralytics).
    shifted = boxes + classes[:, None] * 7680.0
    kept = nms(shifted, scores, overlap)[:MAX_BOXES]
    boxes, scores, classes = boxes[kept], scores[kept], classes[kept]
    # Undo the resize and padding.
    gain = min(input_shape[0] / image_shape[0], input_shape[1] / image_shape[1])
    pad_x = round((input_shape[1] - image_shape[1] * gain) / 2 - 0.1)
    pad_y = round((input_shape[0] - image_shape[0] * gain) / 2 - 0.1)
    boxes[:, [0, 2]] -= pad_x
    boxes[:, [1, 3]] -= pad_y
    boxes /= gain
    boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, image_shape[1])
    boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, image_shape[0])
    return np.concatenate([boxes, scores[:, None], classes[:, None]], 1).astype(np.float32)


def as_boxes(rows):
    """Shape the rows like Ultralytics results, so the rest of the reader doesn't care which one ran."""
    boxes = [SimpleNamespace(xyxy=np.array([row[:4]]), conf=np.array([row[4]]), cls=np.array([row[5]]))
             for row in rows]
    return [SimpleNamespace(boxes=boxes)]


class OnnxDetector:
    def __init__(self, path):
        self.path = str(path)
        self.input_shape = DEFAULT_INPUT
        engine = None
        try:
            with open(self.path + '.json', encoding='utf-8') as file:
                info = json.load(file)
            self.input_shape = tuple(info['input'])
            engine = info.get('engine')  # the one tools/check_detector.py proved matches
        except (OSError, ValueError, KeyError):
            pass
        engine = os.environ.get('SCOUT_DETECTOR', engine)
        self.session = None
        self.net = None
        if engine != 'opencv':
            try:
                import onnxruntime
                self.session = onnxruntime.InferenceSession(self.path, providers=['CPUExecutionProvider'])
                self.input_name = self.session.get_inputs()[0].name
            except ImportError:
                if engine == 'onnxruntime':
                    raise
        if self.session is None:
            self.net = cv2.dnn.readNetFromONNX(self.path)

    @property
    def engine(self):
        return 'onnxruntime' if self.session is not None else 'opencv'

    def raw(self, image):
        blob = to_blob(letterbox(image, self.input_shape))
        if self.session is not None:
            return self.session.run(None, {self.input_name: blob})[0]
        self.net.setInput(blob)
        return self.net.forward()

    def __call__(self, image, verbose=False):
        return as_boxes(decode(self.raw(image), image.shape[:2], self.input_shape))
