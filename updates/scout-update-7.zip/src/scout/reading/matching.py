"""Matching a scanned name to the right player in search results.

The loading-screen font and OCR mix up some characters (0/O, 1/l/I, q/g,
y/v, J/I, l/t) and add or drop dots and spaces. Everything here compares the
scanned text with names the provider actually returned; nothing invents names.
"""
import re
import unicodedata
from difflib import SequenceMatcher

# Characters the game font and OCR commonly swap. Used only to compare a
# scanned name with names the provider actually returned.
CONFUSABLE = str.maketrans({'0': 'o', '1': 'l', 'i': 'l', '|': 'l', '!': 'l', '5': 's', '$': 's', 'q': 'g', 'y': 'v', 'j': 'l', 't': 'l'})


def name_skeleton(name):
    text = unicodedata.normalize('NFKD', str(name)).encode('ascii', 'ignore').decode()
    text = text.casefold().translate(CONFUSABLE).replace('rn', 'm').replace('vv', 'w')
    # A dot and an underscore are easy to confuse; a leading one is often dropped.
    return ''.join(ch if ch.isalnum() else '_' for ch in text if ch.isalnum() or ch in '._').lstrip('_')


def name_similarity(a, b):
    return SequenceMatcher(None, name_skeleton(a), name_skeleton(b)).ratio()


def pick_match(scanned, rows, fuzzy=True):
    """Try the scanned name, then the same name without a short icon-junk last word."""
    words = ' '.join(scanned.split()).split(' ')
    row = _pick_match(scanned, rows, fuzzy)
    if row is not None or not fuzzy:
        return row
    # Only after the full name found nothing: drop a short last "word" that
    # may be part of the icon.
    if len(words) > 1 and len(words[-1]) <= 3:
        return _pick_match(' '.join(words[:-1]), rows, fuzzy)
    return None


def _pick_match(scanned, rows, fuzzy=True):
    """Return the one search row that is clearly the scanned player, or None.

    Order of trust: exact name, then the same name after allowing for common
    OCR swaps (0/O, 1/l/I, a dropped dot), then a single close spelling that
    clearly beats every other result. Ties never pick a player.
    """
    rows = [row for row in rows if isinstance(row, dict) and str(row.get('name', '')).strip()]
    exact = [row for row in rows if str(row['name']).strip().casefold() == scanned.casefold()]
    if exact:
        return exact[0] if len(exact) == 1 else None
    target = name_skeleton(scanned)
    if len(target) < 3:
        return None
    same = [row for row in rows if name_skeleton(row['name']) == target]
    if same:
        return same[0] if len(same) == 1 else None
    if not fuzzy:
        return None
    # Close spelling: only one character added, dropped or changed after the
    # usual misreads, in a name long enough that one character is a small part
    # of it. A general "looks similar" score picked wrong players on real
    # matches (MishMoon77 -> MsMoon777), so it is not used.
    if len(target) < 6:
        return None
    close = [row for row in rows if edit_distance(name_skeleton(row['name']), target) <= 1]
    return close[0] if len(close) == 1 else None


def edit_distance(a, b, limit=2):
    """Levenshtein distance, stopping early once it exceeds `limit`."""
    if abs(len(a) - len(b)) > limit:
        return limit + 1
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + (ca != cb)))
        if min(current) > limit:
            return limit + 1
        previous = current
    return previous[-1]


def is_strict_match(scanned, real):
    """Exact, or the same name once the usual misreads are allowed for."""
    return scanned.strip().casefold() == real.strip().casefold() or name_skeleton(scanned) == name_skeleton(real)


def is_unreadable_name(name):
    return bool(re.fullmatch(r'Unreadable name \d+', name.strip()))


def is_hidden_name(name):
    name = name.strip()
    return bool(re.fullmatch(r'Hidden player \d+|\*{3,}\w?', name)
                or re.fullmatch(r'[HKEXRDT#*\[\]]{5,6}[0-9A-Z\]]?', name))


def search_queries(name):
    """The scanned name, then up to five looser searches for misread names."""
    name = ' '.join(name.split())
    queries = [name]
    # A stray dot or tick before or after a name is usually icon edge, not part of the name.
    trimmed = name.strip('.,\'`-_ ')
    words = trimmed.split(' ')
    if len(words) > 1 and len(words[-1]) <= 3:
        # A short last "word" is often part of the icon after the name.
        trimmed = ' '.join(words[:-1])
    if trimmed and trimmed != name:
        queries.append(trimmed)
    # The game font's I, l, i and J look alike at the start of a name
    # ("Imgalarzad" for Jmgalarzad, "jhateincels" for ihateincels).
    base = trimmed or name
    swap = {'I': 'J', 'l': 'J', '|': 'J', 'i': 'j', 'j': 'i', 'J': 'I'}
    if len(base) >= 4 and base[0] in swap:
        queries.append(swap[base[0]] + base[1:])
    # The game font makes 1 look like l or i; try the digit spelling too.
    digits = (trimmed or name).translate(str.maketrans({'l': '1', 'i': '1', 'I': '1', '|': '1'}))
    if digits != (trimmed or name) and len(digits) >= 4:
        queries.append(digits)
    # A capital I at the start of a word often reads as a lowercase l ("lronTeeth").
    capital = re.sub(r'(?:^|(?<=[^A-Za-z]))l(?=[a-z])', 'I', trimmed or name)
    if capital != (trimmed or name):
        queries.append(capital)
    # g and q look alike in the game font ("Agua" for Aqua), and so do
    # a capital I and a lowercase l between capitals ("ZenixlQ" for ZenixIQ).
    base = trimmed or name
    swapped = base.translate(str.maketrans({'g': 'q', 'q': 'g'}))
    if swapped != base:
        queries.append(swapped)
    capitals = re.sub(r'(?<=[A-Z0-9])l|l(?=[A-Z0-9])', 'I', base)
    if capitals != base:
        queries.append(capitals)
    # The scanner sometimes adds a space inside a name ("Oru Maito").
    if ' ' in (trimmed or name):
        queries.append((trimmed or name).replace(' ', ''))
    # The provider search behaves like a prefix search. A misread letter late
    # in the name still lets a shorter prefix return the real player.
    core = capital if capital != (trimmed or name) else (trimmed or name)
    if len(core) >= 6:
        cut = max(4, len(core) * 2 // 5)
        for index, ch in enumerate(core[:cut]):
            if index >= 3 and ch in '0O1lIi|5SgqyvjJt':
                cut = index
                break
        queries.append(core[:cut])
    return queries[:8]


ACCENTS = {'A': 'ÁÄ', 'E': 'ÉË', 'I': 'ÍÏ', 'O': 'ÓÖ', 'U': 'ÚÜ', 'N': 'Ñ',
           'a': 'áä', 'e': 'éë', 'i': 'íï', 'o': 'óö', 'u': 'úü', 'n': 'ñ'}


def accent_queries(name, limit=8):
    """Spellings with accents put back, for names the reader saw without them.

    The text reader drops accents (it reads TRÚTHNÚKE as TRUTHNUKE), and the
    name search may need them. Each try puts one accent on every copy of one
    letter, which is how these names are usually styled. Matches are still
    checked against the real names that come back.
    """
    name = ' '.join(name.split()).strip('.,\'`-_ ')
    tries = []
    for letter in dict.fromkeys(ch for ch in name if ch in ACCENTS and ch not in 'Nn'):
        for accented in ACCENTS[letter][:1]:
            tries.append(name.replace(letter, accented))
    for letter in dict.fromkeys(ch for ch in name if ch in 'Nn'):
        tries.append(name.replace(letter, ACCENTS[letter]))
    # Every vowel accented at once, and the other accent mark on each vowel.
    tries.append(''.join(ACCENTS[ch][0] if ch in ACCENTS and ch not in 'Nn' else ch for ch in name))
    for letter in dict.fromkeys(ch for ch in name if ch in ACCENTS and ch not in 'Nn'):
        tries.append(name.replace(letter, ACCENTS[letter][1]))
    return [t for t in dict.fromkeys(tries) if t != name][:limit]


def plain(name):
    """The name without accents, for comparing a typed name with the real one."""
    return unicodedata.normalize('NFKD', str(name)).encode('ascii', 'ignore').decode().strip().casefold()
