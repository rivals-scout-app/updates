"""Rivals Scout: the window and what it does.

Scanning the loading screen, looking players up and picking bans happen here,
on background threads that report back through self.queue. How things look
is in scout/ui.
"""
import ctypes
import json
import logging
import os
import queue
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, CancelledError
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

from scout import paths

paths.prepare()
for key, folder in [('YOLO_CONFIG_DIR', 'ultralytics'), ('MPLCONFIGDIR', 'matplotlib')]:
    os.environ.setdefault(key, str(paths.CACHE / folder))
os.environ['TEMP'] = os.environ['TMP'] = str(paths.CACHE)
os.environ.setdefault('TESSERACT_CMD', str(paths.TESSERACT))

from scout.reading import screen as autoscan
from scout.stats.advisor import recommend
from scout.stats.tracker import Player, StatsError, season_label, is_hidden_name, is_unreadable_name
from scout.ui import theme
from scout.ui.dialogs import Dialogs
from scout.ui.theme import BG
from scout.ui.views import MatchViews
from scout.ui.common import HISTORY_CHOICES

SHARED_EDITION = paths.SHARED_FLAG.is_file()
TITLE = 'Rivals Scout - Shared' if SHARED_EDITION else 'Rivals Scout'
SHARED_NOTICE = (
    'Low ban risk, but not zero.\n\n'
    "Scout never opens, changes or reads the game's files or memory. It only takes screenshots and looks up "
    'public stats, like a stats website, so the ban risk should be low.\n\n'
    "It isn't zero: Scout is an unofficial app, not made or approved by NetEase. Using lobby stats for bans may "
    "still break the game's rules, and nobody has confirmed it's safe for every account.\n\n"
    'Continue only if you accept that. You can also review stats with the game closed.'
)
RANGES = ('career', 'recent2', 'recent3', 'recent6')


def accept_shared_notice(root):
    """The shared notice, shown once if Setup did not already show it."""
    return messagebox.askokcancel('Rivals Scout - low ban risk, not zero', SHARED_NOTICE,
                                  parent=root, icon='warning', default='cancel')


def ui_scale(root):
    """1.0 at 100% Windows scaling; shrunk if the screen is too small for the window."""
    try:
        scale = root.winfo_fpixels('1i') / 96
    except tk.TclError:
        scale = 1.0
    fit = min(root.winfo_screenwidth() * .94 / 1260, root.winfo_screenheight() * .9 / 800)
    return max(.7, min(scale, fit if fit > 0 else scale, 3))


class ScoutApp(MatchViews, Dialogs):
    def __init__(self, root, hotkey=True):
        self.root = root
        self.root.title(TITLE)
        self.root.configure(bg=BG)
        self.ui_scale = ui_scale(root)
        s = self.ui_scale
        width = min(int(1440 * s), int(root.winfo_screenwidth() * .94))
        height = min(int(900 * s), int(root.winfo_screenheight() * .9))
        self.root.geometry(f'{width}x{height}')
        self.planned_size = (width, height)
        self.root.minsize(int(1200 * s), int(760 * s) if root.winfo_screenheight() > 860 * s else int(640 * s))
        try:
            # default= also gives the icon to Mini bans and other pop-up windows.
            self.root.iconbitmap(default=str(paths.asset('scout.ico')))
        except tk.TclError:
            pass
        self.queue = queue.Queue()
        self.closed = threading.Event()
        self.busy = False
        self.results_by_name = {}     # enemy name -> stats shown in their row
        self.errors_by_name = {}      # enemy name -> why no stats
        self.advisor_results = {}
        self.ally_results = {}
        self.ally_names = []
        self.advice_rows = []
        self.scanned_roster = None
        self.team_picks = []
        self.excluded_bans = []
        self.ban_priority = 'Any role'
        self.name_images = {}
        self.image_path = None
        self.scan_file = None
        self.scan_how = ''
        self.scan_time = ''
        self.mini = None
        self.search_view = None        # a searched player's card shown over the window
        self.pending_auto_stats = False
        self.auto_capture = False      # the current capture came from auto-scan
        self.scanned_names = set()     # names the scanner read; anything else was typed
        self.capture_hotkey = None
        self.hotkey_name = 'F9'
        self.status_is_problem = False
        self.settings = self._load_settings()
        scope = self.settings['stats_scope'] if self.settings['stats_scope'] in RANGES else self.settings.get('season', 21)
        if scope not in HISTORY_CHOICES:
            scope = 'recent6'  # game scans now use recent seasons only; all time lives on player pages
        self.season = tk.StringVar(value=season_label(scope))
        self.enemy_side = tk.StringVar(value='Right')
        self.fallback = tk.BooleanVar(value=self.settings.get('fallback_previous_season', True))
        self.status = tk.StringVar(value='Press F9 on the loading screen, or let auto-scan do it.')
        self.hotkey_hint = tk.StringVar(value='')
        self.auto_scan = tk.BooleanVar(value=bool(self.settings.get('auto_scan', True)))
        self.auto_on = self.auto_scan.get()  # plain copy the background thread can read safely
        self._style_dialogs()
        self._build_names_window()
        self._build()
        # Our own title bar (minimize / maximize / close drawn in the top bar) instead of the white Windows one.
        self.frameless = False
        if hotkey and not self.settings.get('windows_title_bar', False):
            from scout.system import window
            self.frameless = window.make_frameless(self.root)
        if self.frameless:
            self._bind_frame()
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.root.report_callback_exception = self._callback_error
        self.root.bind('<Control-o>', lambda event: self.open_image())
        self.root.bind_all('<Control-v>', self._on_paste, add='+')
        self.root.bind_all('<Control-V>', self._on_paste, add='+')
        self.root.bind('<Escape>', lambda event: self.close_search())
        self.root.after(80, self._drain)
        if hotkey:
            self.root.after(600, self._ask_for_admin)
            from scout.system.hotkey import CaptureHotkey  # Windows only
            self.capture_hotkey = CaptureHotkey(self.queue)
            self.capture_hotkey.start()
            threading.Thread(target=self._auto_scan_loop, daemon=True).start()
        if paths.LAST_CAPTURE.exists():
            self.image_path = paths.LAST_CAPTURE
        self.update_info = None
        self.meta = {}                 # hero name (lower case) -> this season's tier row
        self.enemy_extra = {}          # scanned name -> rank now, queue mates, penalties
        self.stacks = []               # (name, name, games together)
        self.my_profile = None         # the "me" player's heroes, for "your picks" and comparing
        self.my_session = None
        self.my_now = {}
        self.my_matches = []
        self.favorite_games = {}
        self.last_battle = None
        self.setup_state = {}
        self.refresh_me_soon = False
        if hotkey:
            threading.Thread(target=self._background_loop, daemon=True).start()
        from scout.update import updater
        if updater.enabled():
            threading.Thread(target=self._update_loop, daemon=True).start()
        self.request_render()

    # ---- updates ------------------------------------------------------------------
    def _update_loop(self):
        """Look for a signed update shortly after opening, then every 6 hours."""
        from scout.update import updater
        wait = 5
        while not self.closed.wait(wait):
            wait = 6 * 3600
            try:
                info = updater.check()
            except Exception as error:  # offline, GitHub down, bad signature: try again later
                logging.info('Update check: %s', error)
                continue
            if info:
                self.queue.put(('update_available', info))

    def _on_update_available(self, info):
        self.update_info = info
        self.request_render()

    def install_update(self):
        from scout.update import updater
        info = self.update_info
        if not info or self.busy:
            return
        if updater.needs_setup(info):
            messagebox.showinfo(TITLE, 'This update changes the parts Scout runs on, so it needs the new Setup file. '
                                       'Ask for the latest "Rivals Scout Setup.exe".', parent=self.root)
            return
        notes = info.get('notes') or 'Fixes and improvements.'
        if not messagebox.askyesno(TITLE, f"Install update {info.get('build')}?\n\n{notes}\n\nScout restarts when it's done.", parent=self.root):
            return
        self._set_busy(True, 'Updating Scout…')

        def work():
            try:
                updater.install(info, progress=lambda text: self.queue.put(('status', text)))
                self.queue.put(('update_done', None))
            except Exception as error:
                logging.exception('Update failed')
                self.queue.put(('update_failed', str(error)))
        threading.Thread(target=work, daemon=True).start()

    def _on_update_done(self, value):
        from scout.update import updater
        self.status.set('Updated. Restarting…')
        updater.restart()
        self.root.after(300, self.close)

    def _on_update_failed(self, value):
        self._set_busy(False)
        self.status_is_problem = True
        self.status.set('Update not installed: ' + value)

    # ---- settings --------------------------------------------------------------
    def _load_settings(self):
        defaults = {'season': 21, 'fallback_previous_season': True, 'stats_scope': 'recent6'}
        try:
            value = json.loads(paths.SETTINGS.read_text(encoding='utf-8'))
            if isinstance(value, dict):
                defaults.update(value)
        except (OSError, ValueError):
            pass
        if defaults.get('season') not in (20, 21):
            defaults['season'] = 21
        return defaults

    def _save_settings(self, *_):
        self.settings['stats_scope'] = next((scope for scope in RANGES if self.season.get() == season_label(scope)), 'season')
        if self.settings['stats_scope'] == 'season':
            self.settings['season'] = 21 if self.season.get() == season_label(21) else 20
        self.settings['fallback_previous_season'] = bool(self.fallback.get())
        try:
            paths.SETTINGS.write_text(json.dumps(self.settings, indent=2) + '\n', encoding='utf-8')
        except OSError:
            self.status.set('Settings could not be saved. They still apply until Scout closes.')

    def _history_changed(self):
        self._save_settings()
        self.request_render()
        if self.enemy_names() and not self.busy:
            self.fetch_stats()

    def _player_scope(self):
        """Seasons for player pages (yours too): 'career' for all time, a tuple of season IDs, or a recent range."""
        picked = self.settings.get('player_seasons')
        if picked == 'career':
            return 'career'
        if isinstance(picked, list) and picked:
            return tuple(int(v) for v in picked)
        return 'recent6'

    def set_player_seasons(self, picked, reload_profile=None):
        """Save the seasons player pages use (a list of season IDs, or 'career') and reload the open page."""
        from scout.stats.tracker import CAREER_SEASONS
        if picked != 'career':
            picked = sorted({int(v) for v in picked}, reverse=True)
            if set(picked) == set(CAREER_SEASONS):
                picked = 'career'
        self.settings['player_seasons'] = picked
        self._save_settings()
        if reload_profile:
            self.reload_player(reload_profile)

    def _scope(self):
        """The history range picked for game scans, as the stats code names it."""
        return next((scope for scope in RANGES if self.season.get() == season_label(scope)),
                    21 if self.season.get() == season_label(21) else 20)

    # ---- names and results -------------------------------------------------------
    def _set_names(self, names):
        for index, entry in enumerate(self.entries):
            entry.configure(state='normal')
            entry.delete(0, 'end')
            if index < len(names):
                entry.insert(0, names[index])

    def clear_names(self):
        if self.busy:
            return
        self.pending_auto_stats = False
        self.name_images = {}
        self.scanned_names = set()
        self.ally_names = []
        self.scanned_roster = None
        self.team_picks = []
        self.excluded_bans = []
        self._set_names([])
        self._clear_results()
        self.status.set('Cleared. Ready for the next match.')

    def _clear_results(self):
        self.enemy_extra = {}
        self.stacks = []
        self.results_by_name.clear()
        self.errors_by_name.clear()
        self.advisor_results.clear()
        self.ally_results.clear()
        self.update_advice()

    def _show_result(self, result):
        name = result['username']
        self.results_by_name[name] = result
        self.errors_by_name.pop(name, None)
        self.advisor_results[name] = result
        self.update_advice()

    def _show_player_error(self, name, error):
        self.errors_by_name[name] = error
        self.request_render()

    def _fix_unread(self, slot, text):
        """A name typed into a row's fix box replaces that slot and looks the team up again."""
        text = text.strip()
        if not text or self.busy:
            return
        for entry in self.entries:
            if entry.get().strip() == slot:
                entry.configure(state='normal')
                entry.delete(0, 'end')
                entry.insert(0, text)
                break
        self.fetch_stats()

    def _set_busy(self, busy, message=None):
        self.busy = busy
        for entry in self.entries:
            entry.configure(state='disabled' if busy else 'normal')
        if message:
            self.status.set(message)
        self.status_is_problem = False
        self.request_render()

    # ---- screenshots ------------------------------------------------------------------
    def _show_scan_source(self, path, how):
        """Remember which screenshot the results came from, shown in the scan card."""
        self.scan_file = Path(path)
        self.scan_how = how
        self.scan_time = time.strftime('%I:%M %p').lstrip('0')
        self.request_render()

    def open_scan_file(self):
        if self.scan_file is None or not Path(self.scan_file).exists():
            self.status.set('No scanned screenshot to open yet.')
            return
        self.show_screenshot(self.scan_file)

    def open_image(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(parent=self.root, title='Open a loading-screen screenshot',
                                          filetypes=[('Images', '*.png *.jpg *.jpeg *.bmp *.webp'), ('All files', '*.*')])
        if path:
            self.image_path = Path(path)
            self.scan_image('opened file')

    def _on_paste(self, event):
        # In the search box or a name box, Ctrl+V pastes text as usual; a copied picture is scanned.
        if isinstance(event.widget, (tk.Entry,)) and not self._clipboard_has_picture():
            return None
        if self.paste_image():
            return 'break'
        return None

    @staticmethod
    def _clipboard_picture():
        """The picture on the clipboard: a copied image, or a copied image file. None if there isn't one."""
        try:
            from PIL import Image, ImageGrab
            content = ImageGrab.grabclipboard()
        except Exception:
            return None
        if isinstance(content, Image.Image):
            return content
        if isinstance(content, list):
            for name in content:
                if str(name).lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.webp')):
                    try:
                        with Image.open(name) as picture:
                            return picture.copy()
                    except OSError:
                        continue
        return None

    def _clipboard_has_picture(self):
        return self._clipboard_picture() is not None

    def paste_image(self):
        """Scan a picture copied to the clipboard (Ctrl+V). True if there was one."""
        if self.busy:
            return False
        picture = self._clipboard_picture()
        if picture is None:
            self.status.set('Nothing to paste. Copy a loading-screen picture first (or press Win+Shift+S).')
            return False
        path = paths.SCANS / time.strftime('paste-%Y-%m-%d_%H-%M-%S.png')
        picture.convert('RGB').save(str(path))
        for old in sorted(paths.SCANS.glob('paste-*.png'))[:-30]:
            old.unlink(missing_ok=True)  # keep the 30 newest
        self.image_path = path
        self.scan_image('pasted picture')
        return True

    def scan_image(self, how='opened file'):
        if self.busy:
            return
        if self.image_path is None:
            self.status.set('Open a screenshot or capture the loading screen first.')
            return
        self._clear_results()
        self._set_busy(True, 'Reading names… the first scan takes a little longer.')
        self._show_scan_source(self.image_path, how)
        threading.Thread(target=self._scan_worker, args=(self.image_path,), daemon=True).start()

    def _scan_worker(self, path):
        try:
            from scout.reading import reader
            self.queue.put(('scan_roster', reader.get_roster(path)))
        except Exception:
            logging.exception('Name scan failed')
            self.queue.put(('error', 'Could not read names. Try a clear competitive loading-screen screenshot.'))
        finally:
            self.queue.put(('finish', None))

    def capture(self, delay_ms=500, auto=False):
        if self.busy:
            return
        self.auto_capture = auto
        if auto:
            # The game is in front already; stay out of its way.
            self._set_busy(True, 'Loading screen spotted. Reading names…')
        else:
            self._set_busy(True, 'Capturing in 3 seconds… switch to the loading screen now.')
            self._minimize()
        self.root.after(delay_ms, lambda: threading.Thread(target=self._capture_worker, daemon=True).start())

    def _capture_worker(self):
        try:
            from PIL import ImageGrab
            from scout.reading import reader
            path = paths.SCANS / time.strftime('scan-%Y-%m-%d_%H-%M-%S.png')
            shot = autoscan.grab_screen()  # the monitor the game is on (the main screen if it isn't showing)
            shot.save(str(path))
            shot.save(str(paths.LAST_CAPTURE))  # last capture, reused when Scout opens
            for old in sorted(paths.SCANS.glob('scan-*.png'))[:-30]:
                old.unlink(missing_ok=True)  # keep the 30 newest
            self.queue.put(('captured', path))
            self.queue.put(('scan_roster', reader.get_roster(path)))
        except Exception:
            logging.exception('Capture failed')
            self.queue.put(('error', 'Screen capture failed. You can still open a saved screenshot.'))
        finally:
            self.queue.put(('finish', None))

    def _ask_for_admin(self):
        """Ask Windows for administrator rights once the window is up; on Yes, the new copy takes over."""
        try:
            owner = int(self.root.wm_frame(), 16)
        except (tk.TclError, ValueError):
            owner = None
        if elevate(owner):
            logging.info('Restarting with administrator rights')
            self.close()

    def _minimize(self):
        """Get out of the way of the screenshot. Our own title bar needs a special minimize (Tk refuses otherwise)."""
        try:
            if getattr(self, 'frameless', False):
                from scout.system import window
                window.minimize(self.root)
            else:
                self.root.iconify()
        except tk.TclError:
            logging.exception('Could not minimize before capturing')

    def toggle_title_bar(self):
        self.settings['windows_title_bar'] = not self.settings.get('windows_title_bar', False)
        self._save_settings()
        self.status.set('The Windows title bar comes back next time Scout opens.' if self.settings['windows_title_bar']
                        else "Scout's own title bar comes back next time it opens.")

    def toggle_admin(self):
        self.settings['run_as_admin'] = not self.settings.get('run_as_admin', True)
        self._save_settings()
        self.status.set('Scout will ask for administrator rights next time it opens, so F9 works in the game.'
                        if self.settings['run_as_admin'] else 'Scout will open without administrator rights next time. '
                        'F9 may not work while the game is in front; auto-scan still does.')

    # ---- auto-scan ------------------------------------------------------------------
    def toggle_auto_scan(self):
        self.auto_scan.set(not self.auto_scan.get())
        self.auto_on = self.auto_scan.get()
        self.settings['auto_scan'] = bool(self.auto_scan.get())
        self._save_settings()
        self.status.set('Auto-scan is on. Scout scans the loading screen by itself while the game is in front.'
                        if self.auto_scan.get() else 'Auto-scan is off. Press F9 on the loading screen to scan.')
        self.request_render()

    def _auto_scan_loop(self):
        """Background check, twice a second, while the game is showing (active, or visible on a monitor)."""
        # One match is enough: a scan that finds fewer than 8 names is thrown away.
        watcher = autoscan.LoadingScreenWatcher(needed=1, rearm_after=6)  # 6 checks = 3 seconds
        last_window = None
        last_report = 0.0
        saved = 0
        views = 0
        warned_admin = False
        while not self.closed.wait(0.5):
            try:
                if not self.auto_on or self.busy:
                    continue
                title, program, pid = autoscan.foreground_window()
                in_front = autoscan.is_game(title, program)
                # Also watch when the game is showing but another window is active
                # (e.g. Scout or Discord on a second monitor during the loading screen).
                game = autoscan.game_window()
                showing = in_front or game is not None
                if (title, program) != last_window:
                    # Logged once per window change, so the log shows what auto-scan saw.
                    extra = ''
                    if in_front:
                        scout_admin = autoscan.scout_is_admin()
                        extra = f' · Scout admin={scout_admin}'
                        if scout_admin is False and not warned_admin:
                            warned_admin = True
                            self.queue.put(('status', 'Scout is not running as administrator, so F9 may not work in the game. '
                                                      'Auto-scan still works. Turn on "Open as administrator" in the ••• menu for F9.'))
                    logging.info('Auto-scan: active window %r (%s) -> %s%s', title[:60], program or 'unknown program',
                                 'game, watching' if in_front else
                                 'not the game, but the game is showing, watching' if showing else 'not the game', extra)
                    last_window = (title, program)
                if not showing:
                    continue
                import numpy as np
                import cv2
                frame = np.asarray(autoscan.grab_screen(game).convert('RGB'))[:, :, ::-1]
                matched = autoscan.looks_like_loading_screen(frame)
                small = cv2.resize(frame, autoscan.SIZE, interpolation=cv2.INTER_AREA)
                parts = autoscan.color_fractions(cv2.cvtColor(small, cv2.COLOR_BGR2HSV))
                close = autoscan.near_miss(parts)
                # Saved views and near misses are only kept while the game is the active window, so a
                # copy of some other window on the game's monitor is never written to disk.
                if in_front and (time.monotonic() - last_report > 15 or matched or close):
                    views = views % 10 + 1
                    # A small copy of exactly what auto-scan saw, to compare with the real screen.
                    cv2.imwrite(str(paths.CACHE / f'autoscan-view-{views}.png'),
                                cv2.resize(frame, (640, 360), interpolation=cv2.INTER_AREA))
                    logging.info('Auto-scan: view %s, screen %sx%s, mean brightness %.0f, match=%s, %s', views,
                                 frame.shape[1], frame.shape[0], float(frame.mean()), matched,
                                 ' '.join(f'{k}={v:.2f}' for k, v in parts.items()))
                    last_report = time.monotonic()
                if in_front and close and not matched and saved < 5:
                    # Keep a few near misses so detection can be tuned on real screens.
                    saved += 1
                    cv2.imwrite(str(paths.CACHE / f'autoscan-near-miss-{saved}.png'), frame)
                if watcher.feed(matched):
                    logging.info('Auto-scan: loading screen detected')
                    self.queue.put(('auto_scan', None))
            except Exception:
                logging.exception('Auto-scan check failed; still watching')
                self.closed.wait(5)

    # ---- one-player search ------------------------------------------------------------
    def search_player(self):
        name = ' '.join(self.search_text_value().split())
        if not name:
            self.status.set('Type a player name in the search bar first.')
            return
        self.status.set(f'Searching {name}…')
        self.search_view = ('loading', name)
        self.page_scroll = 0
        self.request_render()
        threading.Thread(target=self._search_worker, args=(name, self._player_scope()), daemon=True).start()

    def _search_worker(self, name, scope):
        try:
            # Typed, so exact name only: what you type is who you get.
            progress = lambda message: self.queue.put(('status', 'Loading ' + message))
            profile = Player(name, typed=True).get_profile(scope, progress=progress, cancelled=self.closed.is_set)
            self.queue.put(('search_result', profile))
        except StatsError as error:
            self.queue.put(('search_error', (name, str(error))))
        except Exception as error:  # network trouble and the like
            logging.exception('Player search failed')
            self.queue.put(('search_error', (name, f'Search failed: {error}')))

    # ---- one match from a searched player's page -------------------------------------
    def open_match(self, profile, match):
        """Show everyone who was in one of the searched player's recent matches."""
        view = {'profile': profile, 'match': match, 'state': 'loading', 'scroll': getattr(self, 'page_scroll', 0),
                'back': self.search_view}
        self.search_view = ('match', view)
        self.page_scroll = 0
        self.status.set('Loading that match…')
        self.request_render()
        threading.Thread(target=self._match_worker, args=(view,), daemon=True).start()

    def open_live_match(self, profile):
        """The lobby of the match this player is in right now."""
        self.open_match(profile, {'id': profile.get('live_battle'), 'live': True, 'hero': '', 'won': None})

    def _match_worker(self, view):
        from scout.stats.tracker import get_match, get_live_match
        match = view['match']
        try:
            if match.get('live'):
                result = get_live_match(match.get('id'), view['profile'].get('uid'))
            else:
                result = get_match(match.get('id'))
            self.queue.put(('match_result', (view, result)))
        except StatsError as error:
            self.queue.put(('match_error', (view, str(error))))
        except Exception as error:
            logging.exception('Match lookup failed')
            self.queue.put(('match_error', (view, f'Could not load the match: {error}')))

    def _on_match_result(self, value):
        view, data = value
        view.update(state='ready', data=data)
        if self.search_view and self.search_view[1] is view:
            self.status.set('Click anyone to see their stats.')
            self.request_render()

    def _on_match_error(self, value):
        view, error = value
        view.update(state='error', error=error)
        if self.search_view and self.search_view[1] is view:
            self.status.set(error)
            self.request_render()

    def back_to_profile(self):
        if self.search_view and self.search_view[0] == 'match':
            view = self.search_view[1]
            back = view.get('back')
            self.search_view = back if back and back[0] in ('profile', 'insights') else ('profile', view['profile'])
            self.page_scroll = view.get('scroll', 0)
            self.request_render()

    def open_player(self, name, uid=None):
        """Open someone's page straight from a match (by their ID, so the name can't mix them up)."""
        self.status.set(f'Searching {name}…')
        self.search_view = ('loading', name)
        self.page_scroll = 0
        self.request_render()
        threading.Thread(target=self._open_player_worker, args=(name, uid, self._player_scope()), daemon=True).start()

    def _open_player_worker(self, name, uid, scope):
        try:
            player = Player(name, typed=True)
            if uid and str(uid).isdecimal():
                player.uid, player.matched_name = str(uid), name
            progress = lambda message: self.queue.put(('status', 'Loading ' + message))
            self.queue.put(('search_result', player.get_profile(scope, progress=progress, cancelled=self.closed.is_set)))
        except StatsError as error:
            self.queue.put(('search_error', (name, str(error))))
        except Exception as error:
            logging.exception('Player search failed')
            self.queue.put(('search_error', (name, f'Search failed: {error}')))

    def reload_player(self, profile):
        """Load a player's page again, skipping the few minutes Scout keeps stats to save requests."""
        from scout.stats import tracker
        tracker.CAREER_CACHE.clear()
        self.open_player(profile.get('username', ''), profile.get('uid'))

    def open_meta(self, rank='diamond_plus'):
        """The hero tier list for a rank range (RivalsData)."""
        view = {'state': 'loading', 'rank': rank}
        self.search_view = ('meta', view)
        self.page_scroll = 0
        self.status.set('Loading the hero meta…')
        self.request_render()
        threading.Thread(target=self._meta_worker, args=(view,), daemon=True).start()

    def _meta_worker(self, view):
        from scout.stats.tracker import get_tierlist
        try:
            self.queue.put(('meta_result', (view, get_tierlist(view['rank']))))
        except StatsError as error:
            self.queue.put(('meta_error', (view, str(error))))
        except Exception as error:
            logging.exception('Meta lookup failed')
            self.queue.put(('meta_error', (view, f'Could not load the meta: {error}')))

    def _on_meta_result(self, value):
        view, data = value
        view.update(state='ready', data=data)
        if self.search_view and self.search_view[1] is view:
            self.status.set('Hero meta loaded.')
            self.request_render()

    def _on_meta_error(self, value):
        view, error = value
        view.update(state='error', error=error)
        if self.search_view and self.search_view[1] is view:
            self.status.set(error)
            self.request_render()

    def uninstall_script(self):
        """The installed copy's uninstaller, or None (the development folder has none)."""
        program = paths.ROOT / 'Uninstall Rivals Scout.exe'
        return program if program.is_file() else None

    def uninstall(self):
        """Remove Scout (after asking): closes Scout, then the uninstaller deletes the app, its shortcuts and saved data."""
        script = self.uninstall_script()
        if script is None:
            messagebox.showinfo('Uninstall Rivals Scout',
                                'This copy is the development folder, not an installed copy, so there is nothing to uninstall. '
                                'Delete the folder yourself if you no longer need it.', parent=self.root)
            return
        if not messagebox.askyesno('Uninstall Rivals Scout',
                                   'Remove Rivals Scout from this PC?\n\nThis deletes the app, its Desktop and Start menu '
                                   'shortcuts, and its saved data (settings, favorites, scans). Your game and your account '
                                   'are not touched.', icon='warning', default='no', parent=self.root):
            return
        import subprocess
        subprocess.Popen([str(script), '/uninstall', '/y'], cwd=os.environ.get('TEMP') or None)
        self.close()

    def open_tracker_gg(self, profile):
        """Open the player's tracker.gg page in the normal web browser (tracker.gg has no API for Marvel Rivals)."""
        import webbrowser
        from urllib.parse import quote
        name = str(profile.get('username') or '').strip()
        if name:
            webbrowser.open('https://tracker.gg/marvel-rivals/profile/ign/' + quote(name, safe='') + '/overview')

    def set_match_key(self):
        """Ask for a MarvelRivalsAPI key (free at marvelrivalsapi.com). Kept in data/settings.json only."""
        from tkinter import simpledialog
        key = simpledialog.askstring('MarvelRivalsAPI key',
                                     'Paste your free key from marvelrivalsapi.com (Dashboard → API key).\n'
                                     'It stays on this PC and is only sent to marvelrivalsapi.com.\n'
                                     'Leave it empty to remove it.',
                                     initialvalue=self.settings.get('match_api_key', ''), show='•', parent=self.root)
        if key is None:
            return
        key = key.strip()
        if key and not re.fullmatch(r'[A-Za-z0-9._-]{8,200}', key):
            self.status.set("That doesn't look like a key. Copy it again from marvelrivalsapi.com.")
            return
        if key:
            self.settings['match_api_key'] = key
        else:
            self.settings.pop('match_api_key', None)
        self._save_settings()
        self.status.set('Key saved. Match details will use it.' if key else 'Key removed.')

    # ---- team lookups ------------------------------------------------------------------
    def fetch_stats(self):
        if self.busy:
            return
        names = list(dict.fromkeys(self.enemy_names()))
        if not names:
            self.status.set('Scan a loading screen or type an enemy name first.')
            return
        self._clear_results()
        self._set_busy(True, f'Looking up {len(names)} player{"s" if len(names) != 1 else ""}…')
        season = self._scope()
        fallback = bool(self.fallback.get())
        threading.Thread(target=self._stats_worker, args=(names, season, fallback, None, list(self.ally_names)), daemon=True).start()

    @staticmethod
    def _readings(path, name):
        """Other readings of a scanned name image, made only if they're needed."""
        if not path:
            return None

        def read():
            from scout.reading import reader
            return reader.alternate_reads(path, name)
        return read

    def _stats_worker(self, names, season, fallback, identities=None, ally_names=None):
        found = set()
        failed = set()
        recent = {}
        completed_career = set()
        stopped = threading.Event()
        scanned = set(self.scanned_names)
        # Typed names are looked up exactly as written; only scanned names get misread fixes.
        images = dict(self.name_images)
        players = {name: Player((identities or {}).get(name, {}).get('uid', name), typed=name not in scanned,
                                readings=self._readings(images.get(name), name) if name in scanned else None) for name in names}

        def add_recent_form(result, preview):
            # Compare this season with the longer range for the same hero.
            if not preview:
                return
            latest = {hero['hero_name']: hero for hero in preview.get('heroes', [])}
            for hero in result.get('heroes', []):
                now = latest.get(hero['hero_name'])
                if now and now.get('_games', 0) >= 5 and hero.get('_games', 0) > now.get('_games', 0):
                    hero['recent_win_pct'] = now['win_pct']
                    hero['recent_matches'] = now['_games']

        def lookup(name, scope):
            if stopped.is_set() or self.closed.is_set():
                raise CancelledError()
            options = {}
            if scope in RANGES:
                options = {'progress': lambda message: self.queue.put(('status', 'Adding older seasons • ' + message)),
                           'cancelled': lambda: stopped.is_set() or self.closed.is_set()}
            result = dict(players[name].get_best_heroes(season=scope, fallback_previous=fallback, **options))
            uid = getattr(players[name], 'uid', None)
            if uid and scope == scopes[0] and name not in self.enemy_extra:
                threading.Thread(target=self._enemy_extras_worker, args=(name, uid), daemon=True).start()
            identity = (identities or {}).get(name)
            if identity:
                result['username'] = identity['name'] + ' · UID ' + identity['uid']
            matched = getattr(players[name], 'matched_name', None)
            if isinstance(matched, str) and matched and matched != name and not identity:
                how = ' after reading the name again' if getattr(players[name], 'reread', False) else ''
                result['note'] = f'Matched to {matched} (scanned as {name}{how}). ' + result.get('note', '')
                self.queue.put(('name_fix', (name, matched)))
            return result
        try:
            # Recent records appear first; bounded parallel work enriches the same rows.
            progressive = season in ('career', 'recent6')
            scopes = [21, season] if progressive else [season]
            with ThreadPoolExecutor(max_workers=3) as pool:
                for scope in scopes:
                    if stopped.is_set() or self.closed.is_set():
                        break
                    self.queue.put(('status', 'Loading this season first…' if progressive and scope == 21 else 'Adding older seasons…'))
                    futures = {pool.submit(lookup, name, scope): name for name in names
                               if name not in failed and not (scope != 21 and name in recent and recent[name].get('limited_history'))}
                    for future in as_completed(futures):
                        name = futures[future]
                        if stopped.is_set() or self.closed.is_set():
                            for pending in futures:
                                pending.cancel()
                            break
                        try:
                            result = future.result()
                            if progressive and scope == 21:
                                if not result.get('limited_history'):
                                    result['note'] = 'Recent-season preview • older seasons loading. ' + result['note']
                                recent[name] = result
                            elif progressive:
                                completed_career.add(name)
                                add_recent_form(result, recent.get(name))
                                if not result.get('heroes') and (recent.get(name) or {}).get('heroes'):
                                    # The longer range came back empty: keep this season's heroes on screen
                                    # instead of wiping them out.
                                    logging.info('Older seasons came back empty for %s; keeping this season', name)
                                    result = dict(recent[name])
                                    result['note'] = ('This season only: older seasons came back empty. '
                                                      + str(result.get('note', '')).replace(
                                                          'Recent-season preview • older seasons loading. ', ''))
                            if result['heroes']:
                                found.add(name)
                            self.queue.put(('result', result))
                        except CancelledError:
                            pass
                        except StatsError as error:
                            logging.warning('Stats lookup failed: %s', error)
                            failed.add(name)
                            if name in recent:
                                retained = dict(recent[name])
                                retained['note'] = 'Recent-season stats retained. Older history unavailable: ' + str(error)
                                self.queue.put(('result', retained))
                            else:
                                self.queue.put(('player_error', (name, str(error))))
                            if error.stop_batch:
                                stopped.set()
                                self.queue.put(('status', 'The stats site is unavailable. Remaining lookups stopped.'))
                                for pending in futures:
                                    pending.cancel()
                                break
                        except Exception:
                            stopped.set()
                            for pending in futures:
                                pending.cancel()
                            raise
                    if scope == scopes[0] and ally_names and not stopped.is_set():
                        self.queue.put(('status', "Checking your team's favorite heroes…"))

                        def ally_lookup(name):
                            if stopped.is_set() or self.closed.is_set():
                                raise CancelledError()
                            return dict(Player(name, typed=name not in scanned,
                                               readings=self._readings(images.get(name), name) if name in scanned else None)
                                        .get_best_heroes(season=21, fallback_previous=False))
                        ally_futures = {pool.submit(ally_lookup, name): name for name in dict.fromkeys(ally_names)}
                        for future in as_completed(ally_futures):
                            if stopped.is_set() or self.closed.is_set():
                                for pending in ally_futures:
                                    pending.cancel()
                                break
                            try:
                                result = future.result()
                                result['scanned_as'] = ally_futures[future]
                                self.queue.put(('ally_result', result))
                            except CancelledError:
                                pass
                            except StatsError as error:
                                self.queue.put(('ally_error', (ally_futures[future], str(error))))
                                if error.stop_batch:
                                    stopped.set()
                                    for pending in ally_futures:
                                        pending.cancel()
                                    break
            if stopped.is_set() and not self.closed.is_set():
                for name, result in recent.items():
                    if name not in completed_career and name not in failed and not result.get('limited_history'):
                        retained = dict(result)
                        retained['note'] = 'Recent-season preview retained. Older history stopped before completion.'
                        self.queue.put(('result', retained))
            if not stopped.is_set() and not self.closed.is_set():
                self.queue.put(('status', f'{len(found)} of {len(names)} enemies have hero records. Ready for the next match.'))
        except Exception:
            logging.exception('Stats lookup failed')
            self.queue.put(('error', 'The lookup could not be finished. Try again in a bit.'))
        finally:
            self.queue.put(('finish', None))

    def update_advice(self):
        self.advice_rows = recommend(self.advisor_results.values(), self.team_picks, self.excluded_bans,
                                     self.ban_priority, self.ally_results.values(), getattr(self, 'meta', {}))
        self.request_render()

    # ---- background: meta, "me", favorites, live lobby -----------------------------------
    def me(self):
        me = self.settings.get('me')
        return me if isinstance(me, dict) and str(me.get('uid', '')).isdecimal() else None

    def _background_loop(self):
        """Slow background refreshes: hero meta hourly, your session and favorites every few minutes,
        and (while the game is in front) a check every 30 seconds for the match you're in."""
        from scout.stats import extras, tracker
        last_meta = last_me = last_live = -1e9
        while not self.closed.wait(1):
            now = time.monotonic()
            try:
                if now - last_meta > 3600:
                    if last_meta < 0 and extras.fetch_rank_icons():
                        self.queue.put(('status', 'Rank icons downloaded.'))
                    last_meta = now
                    tier = tracker.get_tierlist('diamond_plus')
                    self.queue.put(('meta_loaded', {row['hero'].casefold(): row for row in tier['heroes']}))
                me = self.me()
                if self.refresh_me_soon:
                    self.refresh_me_soon = False
                    last_me = -1e9
                if now - last_me > 180:
                    last_me = now
                    if me:
                        games = tracker.get_recent_matches(me['uid'])
                        self.queue.put(('me_loaded', {'matches': games, 'now': extras.player_now(me['uid']),
                                                      'session': extras.session(games)}))
                        if self.my_profile is None:
                            heroes = Player(me['uid'], typed=True).get_best_heroes(season=21, fallback_previous=False, limit=None)
                            self.queue.put(('my_heroes', heroes.get('heroes', [])))
                    favorites = self.settings.get('favorites') or []
                    if favorites:
                        self.queue.put(('favorites_loaded', extras.favorite_status(favorites)))
                if me and self.settings.get('live_lobby', True) and now - last_live > 30 and not self.busy:
                    last_live = now
                    if autoscan.game_in_front():
                        battle = extras.player_now(me['uid']).get('battle')
                        if battle and battle != self.last_battle:
                            lobby = tracker.get_live_match(battle, me['uid'])
                            self.queue.put(('live_lobby', (battle, lobby)))
            except StatsError as error:
                logging.info('Background refresh skipped: %s', error)
            except Exception:
                logging.exception('Background refresh failed')

    def _on_meta_loaded(self, value):
        self.meta = value
        self.update_advice()

    def _on_me_loaded(self, value):
        self.my_matches, self.my_now, self.my_session = value['matches'], value['now'], value['session']
        self.request_render()

    def _on_my_heroes(self, heroes):
        self.my_profile = {'heroes': heroes}
        self.request_render()

    def _on_favorites_loaded(self, value):
        self.favorite_games = value
        self.request_render()

    def _on_live_lobby(self, value):
        """The match you're in, straight from RivalsData: fill both teams and look the enemies up."""
        battle, lobby = value
        me = self.me()
        if not me or self.busy:
            return
        mine = next((p['team'] for p in lobby['players'] if p['uid'] == str(me['uid'])), None)
        if mine is None:
            return
        self.last_battle = battle
        enemies = [p['name'] for p in lobby['players'] if p['team'] != mine]
        allies = [p['name'] for p in lobby['players'] if p['team'] == mine and p['uid'] != str(me['uid'])]
        if sorted(enemies) == sorted(self.enemy_names()):
            return
        logging.info('Live lobby from RivalsData: %s vs %s', allies, enemies)
        self.scanned_names = set()   # exact names from the game: look them up exactly
        self.ally_names = allies
        self._set_names(enemies)
        self.status.set('Lobby loaded from RivalsData (you are in a match). Looking up the enemies…')
        self.fetch_stats()

    def _enemy_extras_worker(self, name, uid):
        from scout.stats import extras
        info = extras.player_now(uid)
        info['mates'] = extras.teammates(uid)
        info['penalties'] = extras.match_penalties(uid)
        from scout.stats.tracker import get_proficiency
        info['proficiency'] = {row['hero']: row['level'] for row in get_proficiency(uid)}
        from scout.stats.tracker import get_recent_matches
        recent = get_recent_matches(uid)
        info['form'] = extras.recent_form(recent)
        info['tonight'] = extras.session(recent)
        info['uid'] = str(uid)
        self.queue.put(('enemy_extra', (name, info)))

    def _on_enemy_extra(self, value):
        from scout.stats import extras
        name, info = value
        self.enemy_extra[name] = info
        current = {n for n in self.enemy_names()}
        self.stacks = extras.find_stacks({n: i.get('mates') for n, i in self.enemy_extra.items() if n in current})
        self.request_render()

    # ---- first-run setup: which account is yours -----------------------------------------
    def needs_setup(self):
        return not self.me() and not self.settings.get('setup_skipped')

    def setup_use_uid(self, uid):
        uid = ''.join(ch for ch in str(uid) if ch.isdigit())
        if not 5 <= len(uid) <= 12:
            self.setup_state = {'state': 'error', 'message': 'A UID is only numbers, like 100000000. Check it and try again.'}
            self.request_render()
            return
        self.setup_state = {'state': 'checking', 'message': 'Checking that UID…'}
        self.request_render()

        def work():
            from scout.stats import extras
            from scout.stats.tracker import rivalsdata_post
            try:
                data = rivalsdata_post('/player', {'uid': int(uid)})
                name = data.get('name') if isinstance(data, dict) else None
                if not name:
                    raise StatsError('No player with that UID.')
                self.queue.put(('setup_results', [{'name': str(name), 'uid': uid, 'level': data.get('level')}]))
            except StatsError as error:
                self.queue.put(('setup_failed', f"Couldn't find that UID: {error}"))
            except Exception:
                logging.exception('Setup UID check failed')
                self.queue.put(('setup_failed', "Couldn't check that UID right now. Try again in a bit."))
        threading.Thread(target=work, daemon=True).start()

    def setup_search(self, name):
        name = ' '.join(str(name).split())
        if not name:
            return
        self.setup_state = {'state': 'checking', 'message': f'Searching for {name}…'}
        self.request_render()

        def work():
            from scout.stats.tracker import rivalsdata_post
            try:
                rows = rivalsdata_post('/players/search', {'name': name})
                found = []
                for row in rows if isinstance(rows, list) else []:
                    uid = str(row.get('aid', '')).rsplit('_', 1)[-1] if isinstance(row, dict) else ''
                    if uid.isdecimal() and row.get('name'):
                        found.append({'name': str(row['name']), 'uid': uid})
                exact = [r for r in found if r['name'].casefold() == name.casefold()]
                results = (exact + [r for r in found if r not in exact])[:8]
                if not results:
                    raise StatsError('nobody with that name')
                self.queue.put(('setup_results', results))
            except StatsError:
                self.queue.put(('setup_failed', f"No player called {name}. Check the spelling, or use your UID."))
            except Exception:
                logging.exception('Setup search failed')
                self.queue.put(('setup_failed', "Couldn't search right now. Try again in a bit."))
        threading.Thread(target=work, daemon=True).start()

    def _on_setup_results(self, results):
        self.setup_state = {'state': 'results', 'results': results}
        self.request_render()

    def _on_setup_failed(self, message):
        self.setup_state = {'state': 'error', 'message': message}
        self.request_render()

    def setup_pick(self, player):
        self.settings['me'] = {'uid': player['uid'], 'name': player['name']}
        self.settings.pop('setup_skipped', None)
        self._save_settings()
        self.setup_state = {}
        self.my_profile = None
        self.status.set(f"All set, {player['name']}. Your games, rank goal and picks will show up in a moment.")
        self.refresh_me_soon = True
        self.request_render()

    def setup_skip(self):
        self.settings['setup_skipped'] = True
        self._save_settings()
        self.status.set('Skipped. You can set it up any time from the ••• menu.')
        self.request_render()

    def reopen_setup(self):
        self.settings.pop('setup_skipped', None)
        self.settings.pop('me', None)
        self.setup_state = {}
        self._save_settings()
        self.close_search() if self.search_view else None
        self.request_render()

    # ---- "me", favorites, comparing, hero detail ---------------------------------------
    def set_me(self, profile):
        uid = str(profile.get('uid') or '')
        if not uid.isdecimal():
            return
        if (self.me() or {}).get('uid') == uid:
            self.settings.pop('me', None)
            self.status.set("Scout no longer knows which player is you.")
        else:
            self.settings['me'] = {'uid': uid, 'name': profile.get('username', '')}
            self.status.set(f"Got it: you are {profile.get('username', uid)}. Your session, rank goal and picks will show up.")
        self.my_profile = None
        self.my_session = None
        self._save_settings()
        self.request_render()

    def toggle_favorite(self, profile):
        uid = str(profile.get('uid') or '')
        if not uid.isdecimal():
            return
        favorites = [f for f in self.settings.get('favorites') or [] if isinstance(f, dict)]
        if any(f.get('uid') == uid for f in favorites):
            favorites = [f for f in favorites if f.get('uid') != uid]
            self.status.set(f"Removed {profile.get('username')} from favorites.")
        else:
            favorites = (favorites + [{'uid': uid, 'name': profile.get('username', '')}])[-8:]
            self.status.set(f"Added {profile.get('username')} to favorites. They show on the start screen.")
        self.settings['favorites'] = favorites
        self._save_settings()
        self.request_render()

    def set_rank_goal(self, level):
        self.settings['rank_goal'] = int(level)
        self._save_settings()
        self.request_render()

    def open_compare(self, profile):
        me = self.me()
        if not me:
            return
        view = {'state': 'loading', 'other': profile}
        self.search_view = ('compare', view)
        self.page_scroll = 0
        self.status.set('Loading your stats to compare…')
        self.request_render()

        def work():
            try:
                player = Player(me['name'] or me['uid'], typed=True)
                player.uid, player.matched_name = me['uid'], me['name'] or me['uid']
                mine = player.get_profile(self._player_scope())
                self.queue.put(('compare_ready', (view, mine)))
            except Exception as error:
                logging.exception('Compare failed')
                self.queue.put(('compare_ready', (view, error)))
        threading.Thread(target=work, daemon=True).start()

    def _on_compare_ready(self, value):
        view, mine = value
        if isinstance(mine, Exception):
            view.update(state='error', error=str(mine))
        else:
            view.update(state='ready', mine=mine)
        if self.search_view and self.search_view[1] is view:
            self.request_render()

    def open_insights(self):
        """How tonight went: your games next to your usual numbers, with plain-language takeaways."""
        me = self.me()
        if not me:
            self.reopen_setup()
            return
        view = {'state': 'loading', 'name': me.get('name') or me['uid']}
        self.search_view = ('insights', view)
        self.page_scroll = 0
        self.status.set("Working out today's insights…")
        self.request_render()

        def work():
            from scout.stats import extras
            try:
                result = extras.todays_insights(me['uid'])
                self.queue.put(('insights_ready', (view, result if result else StatsError('No games in the last few hours yet.'))))
            except Exception as error:
                logging.exception('Insights failed')
                self.queue.put(('insights_ready', (view, error)))
        threading.Thread(target=work, daemon=True).start()

    def _on_insights_ready(self, value):
        view, result = value
        if isinstance(result, Exception):
            view.update(state='error', error=str(result))
        else:
            view.update(state='ready', data=result)
        if self.search_view and self.search_view[1] is view:
            self.status.set("Today's insights ready." if view['state'] == 'ready' else view['error'])
            self.request_render()

    def open_hero(self, profile, hero_name):
        view = {'state': 'loading', 'profile': profile, 'hero': hero_name, 'scroll': getattr(self, 'page_scroll', 0)}
        self.search_view = ('hero', view)
        self.page_scroll = 0
        self.request_render()

        def work():
            from scout.stats import extras
            try:
                self.queue.put(('hero_ready', (view, extras.hero_detail(profile.get('uid'), hero_name))))
            except Exception as error:
                self.queue.put(('hero_ready', (view, error)))
        threading.Thread(target=work, daemon=True).start()

    def _on_hero_ready(self, value):
        view, detail = value
        if isinstance(detail, Exception):
            view.update(state='error', error=str(detail))
        else:
            view.update(state='ready', detail=detail)
        if self.search_view and self.search_view[1] is view:
            self.request_render()

    def _apply_scanned_roster(self, value):
        self.scanned_roster = value
        side = self.enemy_side.get().casefold()
        enemies = value.get(side, [])[:6]
        self.ally_names = value.get('left' if side == 'right' else 'right', [])[:6]
        self.name_images = dict(value.get('images', {}))
        self.scanned_names = set(value.get('left', [])) | set(value.get('right', []))
        self._set_names(enemies)
        self.update_advice()
        self.pending_auto_stats = bool(enemies)
        hidden_enemies = sum(is_hidden_name(name) for name in enemies)
        hidden_allies = sum(is_hidden_name(name) for name in self.ally_names)
        unreadable = sum(is_unreadable_name(name) for name in enemies)
        notes = []
        if hidden_enemies:
            notes.append(f'{hidden_enemies} hidden enem{"y" if hidden_enemies == 1 else "ies"}')
        if hidden_allies:
            notes.append(f'{hidden_allies} hidden teammate{"s" if hidden_allies > 1 else ""}')
        if unreadable:
            notes.append(f'{unreadable} name{"s" if unreadable > 1 else ""} not read')
        extra = (' • ' + ', '.join(notes)) if notes else ''
        self.status.set(f'Scanned {len(enemies)} enemies and {len(self.ally_names)} teammates{extra}. Loading stats…')

    def _swap_scan_sides(self, *_):
        if self.busy or not self.scanned_roster:
            return
        value = self.scanned_roster
        self._clear_results()
        self._apply_scanned_roster(value)
        self.pending_auto_stats = False
        self.fetch_stats()

    # ---- messages from background threads ------------------------------------------------
    def _drain(self):
        """Apply worker messages on the Tk thread: ('kind', value) -> self._on_kind(value)."""
        if self.closed.is_set():
            return
        try:
            while True:
                kind, value = self.queue.get_nowait()
                handler = getattr(self, '_on_' + kind, None)
                if handler is not None:
                    handler(value)
        except queue.Empty:
            pass
        self.root.after(80, self._drain)

    def _on_auto_scan(self, value):
        if not self.busy and self.auto_scan.get():
            # Give the names a moment to finish appearing, then scan once.
            self.capture(delay_ms=900, auto=True)

    def _on_captured(self, value):
        self.image_path = value
        self._show_scan_source(value, 'auto-scan' if self.auto_capture else 'capture')
        if not self.auto_capture:
            self.root.deiconify()
        self._clear_results()
        self.status.set('Screenshot taken. Reading names…')

    def _on_scan_roster(self, value):
        logging.info('Scan read: left %s | right %s', value.get('left', []), value.get('right', []))
        count = len(value.get('left', [])) + len(value.get('right', []))
        if self.auto_capture and count < 8:
            # Not really a loading screen (or names not shown yet): ignore it quietly.
            logging.info('Auto-scan: only %s names found, ignored', count)
            self.status.set('Auto-scan skipped a screen without a full team list. Press F9 if names are showing.')
            return
        self._apply_scanned_roster(value)

    def _on_ally_result(self, value):
        self.ally_results[value.get('scanned_as', value['username'])] = value
        self.update_advice()

    def _on_ally_error(self, value):
        self.ally_results[value[0]] = {'username': value[0], 'heroes': [], 'note': value[1]}
        self.update_advice()

    def _on_names(self, value):
        self._set_names(value)
        self.pending_auto_stats = bool(value)
        self.status.set(f'Found {len(value)} names. Loading stats…' if value else
                        'No enemy names found. Use the competitive loading screen with names showing.')

    def _on_result(self, value):
        self._show_result(value)

    def _on_player_error(self, value):
        self._show_player_error(*value)

    def _on_name_fix(self, value):
        scanned, matched = value
        if scanned in self.name_images:
            self.name_images.setdefault(matched, self.name_images[scanned])
        for entry in self.entries:
            if entry.get().strip() == scanned:
                state = str(entry.cget('state'))
                entry.configure(state='normal')
                entry.delete(0, 'end')
                entry.insert(0, matched)
                entry.configure(state=state)
                break
        self.request_render()

    def _on_status(self, value):
        self.status.set(value)

    def _on_error(self, value):
        self.root.deiconify()
        self.status_is_problem = True
        self.status.set(value)

    def _on_finish(self, value):
        problem = self.status_is_problem
        self._set_busy(False)
        self.status_is_problem = problem
        self.auto_capture = False
        if self.pending_auto_stats:
            self.pending_auto_stats = False
            self.fetch_stats()

    def _on_hotkey(self, value):
        logging.info('Capture shortcut received; busy=%s', self.busy)
        if not self.busy:
            self.capture()
        else:
            self.status.set('Capture shortcut received. Wait for the current lookup to finish, then press it again.')

    def _on_hotkey_status(self, value):
        logging.info(value)
        if not self.busy and 'could not' in value:
            self.status.set(value)

    def _on_hotkey_binding(self, value):
        self.hotkey_name = value
        self.hotkey_hint.set(f'{value} works while minimized')
        self.request_render()

    def _callback_error(self, exception, value, traceback):
        logging.error('Interface error', exc_info=(exception, value, traceback))
        self._set_busy(False, 'Something went wrong on screen. Details are in data/scout.log.')
        self.status_is_problem = True

    def close(self):
        self.closed.set()
        if self.capture_hotkey is not None:
            self.capture_hotkey.close()
        for callback in self.root.tk.splitlist(self.root.tk.call('after', 'info')):
            try:
                self.root.tk.call('after', 'cancel', callback)
            except tk.TclError:
                pass
        self.root.destroy()


APP_ID = 'RivalsScout.Desktop'


def elevate(owner=None):
    """Start a copy with administrator rights (Windows asks first). True if that copy is starting.

    Marvel Rivals runs as administrator, and Windows hides F9 from programs that
    don't, so Scout asks for the same rights unless that's turned off in the menu.
    It asks from the open window, so the Windows prompt shows in front instead
    of hiding in the taskbar. Saying No just keeps this copy running.
    """
    if not sys.platform.startswith('win') or '--no-elevate' in sys.argv:
        return False
    try:
        if ctypes.windll.shell32.IsUserAnAdmin():
            return False
        settings = json.loads(paths.SETTINGS.read_text(encoding='utf-8')) if paths.SETTINGS.exists() else {}
        if not settings.get('run_as_admin', True):
            return False
        import subprocess
        from ctypes import wintypes
        execute = ctypes.windll.shell32.ShellExecuteW
        execute.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR,
                            wintypes.LPCWSTR, ctypes.c_int]
        execute.restype = ctypes.c_void_p
        arguments = subprocess.list2cmdline([os.path.abspath(sys.argv[0]), '--no-elevate'])
        result = execute(owner, 'runas', sys.executable, arguments, str(paths.ROOT), 1)
        return (result or 0) > 32   # 32 or less: they said No, so carry on without admin
    except Exception:
        logging.exception('Could not ask for administrator rights')
        return False


def _freeze_recorder(root, log_file):
    """If the window stops responding for 8 seconds, write where the app is stuck into scout.log.
    Runs outside Python's lock, so it still works when the app is completely frozen."""
    import faulthandler

    def tick():
        try:
            faulthandler.dump_traceback_later(8, repeat=False, file=log_file, exit=False)
        except (OSError, ValueError, RuntimeError):
            return
        root.after(1000, tick)
    tick()


def launch():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except (AttributeError, OSError):
        pass
    try:
        # Own taskbar entry with the Scout icon instead of the Python one.
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except (AttributeError, OSError):
        pass
    log_file = open(paths.LOG, 'a', encoding='utf-8', buffering=1)
    sys.stdout = sys.stderr = log_file
    logging.basicConfig(stream=log_file, level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    try:
        theme.load_fonts()
        root = tk.Tk()
        _freeze_recorder(root, log_file)
        accepted = paths.DATA / 'notice-accepted.json'
        if SHARED_EDITION and not accepted.exists():
            # Normally accepted once in Setup; copies shared another way see it here once instead.
            root.withdraw()
            if not accept_shared_notice(root):
                root.destroy()
                return
            try:
                accepted.parent.mkdir(parents=True, exist_ok=True)
                accepted.write_text('{"accepted_in_app": true}', encoding='utf-8')
            except OSError:
                pass
            root.deiconify()
        ScoutApp(root)
        root.mainloop()
    except Exception:
        logging.exception('Desktop app could not start')
        try:
            ctypes.windll.user32.MessageBoxW(None, 'The app could not start. Details were saved to data/scout.log.', TITLE, 0x10)
        except AttributeError:
            raise
