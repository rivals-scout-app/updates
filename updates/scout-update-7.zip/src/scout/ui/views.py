"""Draws the Rivals Scout windows from the app's current state.

ScoutApp mixes this in. Each screen lives in its own module; this class just puts them together.
Nothing here looks players up or scans; it only reads state the app keeps.
"""
from scout.ui.chrome import ChromeViews
from scout.ui.common import *  # noqa: F401,F403  (helpers some callers import from here)
from scout.ui.detail_pages import DetailPageViews
from scout.ui.home import HomeViews
from scout.ui.me_page import MePageViews
from scout.ui.player_page import PlayerPageViews
from scout.ui.scan import ScanViews


class MatchViews(ChromeViews, HomeViews, ScanViews, PlayerPageViews, DetailPageViews, MePageViews):
    # ---- text on screen (used by the tests) -------------------------------------------
    def visible_text(self):
        """All text on screen in the main window, Mini bans and the search window (used by the tests)."""
        texts = [text for text in self.board.texts]
        texts.append(self.status.get())
        for widget in self.board.widgets.values():
            if widget.winfo_exists():
                texts.append(typed(widget))
        if self.mini is not None and self.mini.winfo_exists():
            texts.extend(self.mini_board.texts)
        return ' '.join(texts)
