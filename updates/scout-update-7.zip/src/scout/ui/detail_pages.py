"""Pages opened from a player page or the rail: compare, one hero, today's insights, hero meta, one match."""
from scout.ui.common import *  # noqa: F401,F403


class DetailPageViews:
    # ---- compare with me -------------------------------------------------------------
    @staticmethod
    def _summary(profile):
        over = profile.get('overview') or {}
        games, wins = over.get('games', 0), over.get('wins', 0)
        kills, deaths, assists = over.get('kills', 0), over.get('deaths', 0), over.get('assists', 0)
        ranks = profile.get('ranks') or []
        form = [g for g in profile.get('form') or [] if g.get('when')][:20]
        return {
            'Rank': (rank_name(ranks[0]['level']) if ranks else '-') or '-',
            'Points': f"{ranks[0]['score']:,.0f}" if ranks else '-',
            'Season record': f'{wins}W {games - wins}L' if games else '-',
            'Win rate': f'{wins / games * 100:.0f}%' if games else '-',
            'KDA': f'{(kills + assists) / max(deaths, 1):.1f}' if games else '-',
            'K/D/A per game': f'{kills / games:.1f} / {deaths / games:.1f} / {assists / games:.1f}' if games else '-',
            'Last 20 games': f"{sum(1 for g in form if g['won'])}W {sum(1 for g in form if not g['won'])}L" if form else '-',
            'Most played': ', '.join(h['hero_name'] for h in (profile.get('heroes') or [])[:3]) or '-',
            'Top proficiency': ', '.join(f"{p['hero']} {p['level']}" for p in (profile.get('proficiency') or [])[:2]) or '-',
        }

    def _compare_content(self, value, x, y, w):
        b = self.board
        start = y
        mine, other = self._summary(value['mine']), self._summary(value['other'])
        rows = list(mine)
        height = 90 + len(rows) * 44 + 16
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        col = (w - 260) / 2
        b.text(x + 240 + col / 2, y + 44, short(value['mine'].get('username', 'You')) + ' (you)', 20, color=GOLD, anchor='center', fit=col - 20)
        b.text(x + 240 + col * 1.5, y + 44, short(value['other'].get('username', '')), 20, anchor='center', fit=col - 20)
        ry = y + 84
        for index, label in enumerate(rows):
            if index % 2 == 0:
                b.shape(x + 12, ry, w - 24, 40, 14, (20, 22, 43, 110), None, None)
            b.text(x + 28, ry + 20, label, 14, 'extra', MUTED)
            b.text(x + 240 + col / 2, ry + 20, mine[label], 15, 'extra', TEXT, anchor='center', fit=col - 20)
            b.text(x + 240 + col * 1.5, ry + 20, other[label], 15, 'extra', TEXT, anchor='center', fit=col - 20)
            ry += 44
        return height + 8

    # ---- one hero ----------------------------------------------------------------------
    def _hero_content(self, value, x, y, w):
        b = self.board
        start = y
        detail, profile = value['detail'], value['profile']
        comp, everyone = detail['competitive'], detail['everyone']
        b.shape(x, y, w, 120, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, 1.5, shadow=True, glow=(GLOW_PURPLE, 90), glow_size=8)
        tint = tint_for(detail['hero'])
        b.avatar(x + 24, y + 18, 84, tint[0], tint[1], tint[2], 3, picture=hero_picture(detail['hero']), initials=initials(detail['hero']))
        b.text(x + 126, y + 48, f"{'You' if self._is_me(profile) else short(profile['username'])} on {detail['hero']}", 26, fit=w * .55)
        facts = []
        if comp:
            facts = [f"{comp['games']} ranked games this season", f"{comp['win']:.0f}% wins", f"{comp['kda']:.1f} KDA",
                     f"{comp['mvps']} MVP · {comp['svps']} SVP"]
            if comp.get('accuracy') is not None:
                facts.append(f"{comp['accuracy']:.0f}% accuracy")
        else:
            facts = ['No ranked games on this hero this season']
        b.text(x + 126, y + 84, '  ·  '.join(facts), 14, 'bold', SOFT, fit=w - 150)
        y += 120 + 18
        if not comp:
            return y - start
        labels = [('damage', 'Damage'), ('healing', 'Healing'), ('damage_blocked', 'Blocked'), ('kills', 'Kills'),
                  ('deaths', 'Deaths'), ('assists', 'Assists'), ('finals', 'Final hits')]
        rows = [(key, label) for key, label in labels if comp['per_10'].get(key) is not None]
        who = 'You' if self._is_me(profile) else short(profile['username'])
        row_h = 64
        height = 104 + len(rows) * row_h + 10
        b.shape(x, y, w, height, 22, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 22, y + 32, 'Per 10 minutes vs the average player', 19)
        if everyone.get('win') is not None:
            b.text(x + w - 22, y + 33, f"Average on this hero: {everyone['win']:.0f}% wins · {everyone['pick'] or 0:.1f}% pick · "
                   f"{everyone['ban'] or 0:.1f}% ban", 12, 'bold', SOFT, anchor='e')
        # Legend
        lx = x + 22
        for label, colors in ((who, (GOLD_TOP, GOLD_BOTTOM)), ('Average player', ('#A9B6CC', '#7C8AA3'))):
            b.shape(lx, y + 56, 22, 10, 5, colors[0], colors[1], None, direction='right')
            b.text(lx + 30, y + 61, label, 13, 'extra', TEXT)
            lx += 30 + b.measure(label, 13, 'extra') + 26
        ry = y + 86
        bar_x = x + 170
        bar_w = w - 170 - 260
        for key, label in rows:
            mine, avg = comp['per_10'][key], everyone['per_10'].get(key)
            top = max(mine, avg or 0) or 1
            b.shape(x + 12, ry, w - 24, row_h - 8, 12, ROW_LEFT, ROW_RIGHT, CHIP_LINE, 1, 'right')
            b.text(x + 28, ry + (row_h - 8) / 2, label, 15, 'extra', TEXT)
            b.shape(bar_x, ry + 12, max(6, bar_w * mine / top), 12, 6, GOLD_TOP, GOLD_BOTTOM, None, direction='right')
            b.text(bar_x + max(6, bar_w * mine / top) + 10, ry + 18, short_number(mine), 13, 'extra', GOLD)
            if avg is not None:
                b.shape(bar_x, ry + 32, max(6, bar_w * avg / top), 10, 5, '#A9B6CC', '#7C8AA3', None, direction='right')
                b.text(bar_x + max(6, bar_w * avg / top) + 10, ry + 37, short_number(avg), 12, 'extra', '#C3CCDC')
                lower_is_better = key == 'deaths'
                diff = (mine - avg) / avg * 100 if avg else 0
                better = diff <= 0 if lower_is_better else diff >= 0
                text = f"{'+' if diff > 0 else ''}{diff:.0f}%"
                note = ('fewer' if diff < 0 else 'more') if lower_is_better else ('above avg' if diff >= 0 else 'below avg')
                pw = 74
                px = x + w - 24 - 150
                b.shape(px, ry + 12, pw, 32, 10, '#15241D' if better else '#261519', None, GREEN_DEEP if better else LOSS, 1)
                b.text(px + pw / 2, ry + 28, text, 15, color=GREEN_SOFT if better else LOSS_SOFT, anchor='center')
                b.text(px + pw + 12, ry + 28, note, 12, 'bold', SOFT)
            ry += row_h
        b.text(x + 22, y + height - 14, f"{'Your' if who == 'You' else who + chr(39) + 's'} ranked games this season next to "
               "everyone playing this hero (RivalsData). For deaths, lower is better.", 12, 'bold', SOFT, fit=w - 44)
        return y + height - start + 8

    # ---- today's insights ----------------------------------------------------------------
    def _insights_content(self, value, x, y, w):
        b = self.board
        start = y
        data = value['data']
        wins, losses = data['record']
        games = data['games']
        # Header
        b.shape(x, y, w, 132, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, 1.5, shadow=True, glow=(GLOW_PURPLE, 110), glow_size=10)
        b.text(x + 24, y + 38, f"Today's insights · {short(value['name'])}", 26)
        first = games[0]['when'] if games else 0
        played = data['today'].get('seconds') or 0
        b.text(x + 24, y + 72, f"{len(games)} games since {time.strftime('%I:%M %p', time.localtime(first)).lstrip('0')}"
               + (f"  ·  {hours(played)} played" if played else ''), 14, 'bold', MUTED)
        tiles = [('Record', f'{wins}W {losses}L', win_color(f'{wins / max(1, wins + losses) * 100}%')),
                 ('Win rate', f'{wins / max(1, wins + losses) * 100:.0f}%', win_color(f'{wins / max(1, wins + losses) * 100}%'))]
        if data['ranked']:
            tiles.append(('Ranked points', f"{'+' if data['points'] > 0 else ''}{data['points']:.0f}",
                          GREEN_SOFT if data['points'] > 0 else RED if data['points'] < 0 else SOFT))
        if data.get('placement'):
            tiles.append(('Avg lobby place', f"#{data['placement']:.1f}", GREEN_SOFT if data['placement'] <= 4 else SOFT))
        tiles.append(('MVP / SVP', f"{data['mvps']} / {data['svps']}", GOLD if data['mvps'] else SOFT))
        count, won = data['streak']
        tiles.append(('Streak', f"{count}{'W' if won else 'L'}", GREEN_SOFT if won else RED))
        tile_w = 118
        tx = x + w - 20 - len(tiles) * (tile_w + 10) + 10
        for label, text, color in tiles:
            b.shape(tx, y + 26, tile_w, 80, 20, (20, 22, 43, 140), None, CHIP_LINE, 1)
            b.text(tx + tile_w / 2, y + 52, label, 12, 'bold', MUTED, anchor='center')
            b.text(tx + tile_w / 2, y + 80, text, 20, color=color, anchor='center', fit=tile_w - 14)
            tx += tile_w + 10
        if data.get('rank_from') and data.get('rank_to'):
            b.text(x + 24, y + 104, f"Rank points {data['rank_from']:,.0f} to {data['rank_to']:,.0f}", 13, 'bold', SOFT)
        y += 132 + 18
        left_w = w * .58 if w > 1000 else w
        right_x = x + left_w + 18 if w > 1000 else x
        # Takeaways
        notes = data['takeaways']
        height = 62 + max(1, len(notes)) * 40 + 10
        b.shape(x, y, left_w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Takeaways', 20)
        ry = y + 58
        if not notes:
            b.text(x + 20, ry + 16, 'A steady night. Nothing stood out from your usual numbers.', 14, 'bold', MUTED)
        for text, tone in notes:
            color = {'good': GREEN_SOFT, 'bad': '#F08A8A'}.get(tone, SOFT)
            b.shape(x + 20, ry + 9, 12, 12, 6, color, None, None)
            b.text(x + 42, ry + 15, text, 14, 'extra', TEXT, fit=left_w - 64)
            ry += 40
        notes_bottom = y + height
        # Today vs usual
        today, base = data['today'], data['base']
        rows = [('Damage', 'damage', True), ('Healing', 'healing', True), ('Blocked', 'blocked', True), ('Kills', 'kills', True),
                ('Deaths', 'deaths', False), ('Assists', 'assists', True), ('KDA', 'kda', True), ('Accuracy', 'accuracy', True)]
        rows = [r for r in rows if today.get(r[1]) is not None and (r[1] != 'healing' or today['healing'] > 5000 or (base.get('healing') or 0) > 5000)]
        cy = y if w > 1000 else notes_bottom + 18
        cw = w - left_w - 18 if w > 1000 else w
        height = 76 + len(rows) * 42 + 12
        b.shape(right_x, cy, cw, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(right_x + 20, cy + 32, 'Per 10 minutes: today vs your season', 18)
        b.text(right_x + cw - 20, cy + 58, 'today   usual', 12, 'bold', MUTED, anchor='e')
        ry = cy + 74
        for label, key, higher_better in rows:
            now_v, usual = today.get(key), base.get(key)
            fmt = (lambda v: f'{v:.1f}') if key in ('kills', 'deaths', 'assists', 'kda') else (lambda v: f'{v:.0f}%') if key == 'accuracy' else short_number
            b.text(right_x + 20, ry + 14, label, 14, 'extra', TEXT)
            better = None if usual in (None, 0) else (now_v >= usual if higher_better else now_v <= usual)
            b.text(right_x + cw - 92, ry + 14, fmt(now_v), 15, 'extra', SOFT if better is None else GREEN_SOFT if better else '#F08A8A', anchor='e')
            b.text(right_x + cw - 20, ry + 14, fmt(usual) if usual is not None else '-', 13, 'bold', MUTED, anchor='e')
            if usual:
                pct = (now_v - usual) / usual * 100
                b.text(right_x + cw - 160, ry + 14, f"{pct:+.0f}%", 12, 'bold', GREEN_SOFT if better else '#F08A8A', anchor='e')
            ry += 42
        compare_bottom = cy + height
        y = max(notes_bottom, compare_bottom) + 18 if w > 1000 else compare_bottom + 18
        # Heroes today
        heroes = data['heroes']
        height = 62 + len(heroes) * 50 + 10
        b.shape(x, y, left_w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Heroes today', 20)
        ry = y + 58
        for hero in heroes:
            tint = tint_for(hero['hero'])
            b.avatar(x + 20, ry + 4, 36, tint[0], tint[1], tint[2], 2, picture=hero_picture(hero['hero']), initials=initials(hero['hero']))
            b.text(x + 66, ry + 22, hero['hero'], 15, fit=left_w * .35)
            rate = hero['wins'] / hero['games'] * 100
            b.text(x + left_w * .5, ry + 22, f"{hero['wins']}W {hero['games'] - hero['wins']}L", 14, 'extra', win_color(f'{rate}%'), anchor='center')
            b.text(x + left_w * .68, ry + 22, f"{hero['kda']:.1f} KDA", 14, 'extra', kda_colors(hero['kda'])[1], anchor='center')
            if hero.get('avg_damage') is not None:
                b.text(x + left_w - 20, ry + 22, f"{short_number(hero['avg_damage'])} dmg", 13, 'bold', SOFT, anchor='e')
            ry += 50
        heroes_bottom = y + height
        # Best and worst game
        gy = y if w > 1000 else heroes_bottom + 18
        for label, game, tone in (('Best game', data['best'], GREEN_DEEP), ('Toughest game', data['worst'], '#B5525F')):
            if game is data['best'] and label == 'Toughest game' and len(games) < 2:
                continue
            gh = 112
            b.shape(right_x, gy, cw, gh, 26, CARD_TOP, CARD_BOTTOM, tone, 1.5, shadow=True)
            b.text(right_x + 20, gy + 30, label, 16, color=GREEN_SOFT if tone == GREEN_DEEP else '#F08A8A')
            tint = tint_for(game['hero'] or '?')
            b.avatar(right_x + 20, gy + 48, 44, tint[0], tint[1], tint[2], 2, picture=hero_picture(game['hero']) if game['hero'] else None,
                     initials=initials(game['hero'] or '?'))
            line = game.get('line') or {}
            b.text(right_x + 76, gy + 62, f"{game['hero'] or 'Unknown hero'}  ·  {'Win' if game['won'] else 'Loss'}", 15, fit=cw - 100)
            bits = [f"{game['kills']}/{game['deaths']}/{game['assists']}"]
            if line.get('damage'):
                bits.append(f"{short_number(line['damage'])} dmg")
            if game.get('placement'):
                bits.append(f"#{game['placement']} in lobby")
            if game['mvp']:
                bits.append('MVP')
            b.text(right_x + 76, gy + 86, '  ·  '.join(bits), 13, 'bold', SOFT, fit=cw - 100)
            self._page_hit(right_x, gy, cw, gh, lambda game=game: self._open_insight_game(game))
            gy += gh + 14
        y = max(heroes_bottom, gy - 14) + 18
        # Every game, oldest first
        height = 62 + 74 + 10
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Every game today', 20)
        b.text(x + w - 20, y + 33, 'number = your place in the lobby (1 is best)', 12, 'bold', MUTED, anchor='e')
        step = min(64, (w - 40) / max(1, len(games)))
        for index, game in enumerate(games):
            gx = x + 20 + index * step
            b.shape(gx, y + 62, step - 8, 60, 14, '#15241D' if game['won'] else '#261519', None, '#25443A' if game['won'] else '#4A2A31', 1)
            b.text(gx + (step - 8) / 2, y + 82, 'W' if game['won'] else 'L', 13, color=GREEN_SOFT if game['won'] else '#F08A8A', anchor='center')
            b.text(gx + (step - 8) / 2, y + 104, f"#{game['placement']}" if game.get('placement') else '-', 12, 'bold', SOFT, anchor='center')
            self._page_hit(gx, y + 62, step - 8, 60, lambda game=game: self._open_insight_game(game))
        y += height + 8
        return y - start

    def _open_insight_game(self, game):
        me = self.me() or {}
        self.open_match({'username': me.get('name') or '', 'uid': me.get('uid')}, game)

    # ---- hero meta -----------------------------------------------------------------------
    def _draw_meta_page(self, value, x, y, w, h, ground):
        from scout.stats.tracker import TIER_RANKS
        b = self.board
        bx = x + b.button(x, y, '‹  Back', self.close_search, 'raised', 38, 14) + 16
        for rank, label in TIER_RANKS.items():
            style = 'gold' if rank == value.get('rank') else 'raised'
            bx += b.button(bx, y, label, lambda rank=rank: self.open_meta(rank), style, 38, 14) + 8
        if value.get('state') != 'ready':
            b.shape(x, y + 52, w, 170, 26, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
            if value.get('state') == 'loading':
                b.text(x + w / 2, y + 137, 'Loading the hero meta…', 24, anchor='center')
            else:
                b.text(x + 28, y + 96, 'Hero meta', 22, color=GOLD)
                b.text(x + 28, y + 128, value.get('error', ''), 15, 'bold', WARN_TEXT, anchor='nw', width=w - 60)
            return
        self._draw_scroll_page(lambda top: self._meta_content(value['data'], x, top, w), x, y, w, h, ground,
                               'PC · this season · from RivalsData')

    def _meta_content(self, data, x, y, w):
        b = self.board
        start = y
        heroes = data['heroes']
        tiers = [('S', 75, (GOLD_TOP, GOLD_BOTTOM)), ('A', 65, ('#B9BAC4', '#8C8D9A')),
                 ('B', 58, ('#6E6F7C', '#555662')), ('C', -1, (RAISED_TOP, RAISED_BOTTOM))]
        left = list(heroes)
        columns = 2 if w > 1100 else 1
        col_w = (w - 18 * (columns - 1)) / columns
        for tier, floor, colors in tiers:
            group = [h for h in left if h['score'] >= floor]
            left = [h for h in left if h['score'] < floor]
            if not group:
                continue
            rows = (len(group) + columns - 1) // columns
            height = 70 + rows * 52 + 12
            b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
            b.shape(x + 20, y + 16, 40, 40, 14, colors[0], colors[1], None, direction='right')
            b.text(x + 40, y + 36, tier, 22, color=DARK if tier != 'C' else TEXT, anchor='center')
            b.text(x + 74, y + 36, f'{len(group)} heroes', 15, 'extra', MUTED)
            b.text(x + w - 24, y + 36, 'win  ·  pick  ·  ban', 12, 'bold', MUTED, anchor='e')
            for index, hero in enumerate(group):
                col, row = index % columns, index // columns
                hx, hy = x + 12 + col * (col_w + 18 if columns > 1 else 0), y + 66 + row * 52
                row_w = col_w - 24 if columns > 1 else w - 24
                b.shape(hx, hy, row_w, 46, 16, ROW_LEFT, ROW_RIGHT, CHIP_LINE, 1, 'right')
                tint = tint_for(hero['hero'])
                b.avatar(hx + 8, hy + 6, 34, tint[0], tint[1], tint[2], 2, picture=hero_picture(hero['hero']), initials=initials(hero['hero']))
                b.text(hx + 52, hy + 23, hero['hero'], 15, fit=row_w * .4)
                cells = [(f"{hero['win']:.1f}%", win_color(f"{hero['win']}%")), (f"{hero['pick']:.1f}%", SOFT),
                         (f"{hero['ban']:.1f}%", RED if hero['ban'] >= 40 else SOFT)]
                cx = hx + row_w - 16
                for text, color in reversed(cells):
                    b.text(cx, hy + 23, text, 14, 'extra', color, anchor='e')
                    cx -= 78
            y += height + 18
        updated = data.get('updated')
        if updated:
            b.text(x + 4, y + 4, f"Updated {ago(time.time() - updated)} · score blends win, pick and ban rates (RivalsData)", 12,
                   'bold', MUTED, anchor='nw')
            y += 30
        return y - start + 8

    # ---- one match ---------------------------------------------------------------------
    def _match_content(self, view, x, y, w):
        """One match: a scoreboard header, team totals, then both teams. Returns the height."""
        b = self.board
        start = y
        profile, match, data = view['profile'], view['match'], view['data']
        players = data['players']
        me = str(profile.get('uid') or '')
        mine = next((p['team'] for p in players if p['uid'] == me), None)
        if mine is None:
            mine = next((p['team'] for p in players if p['won'] == match.get('won')), players[0]['team'])
        teams = [[p for p in players if p['team'] == mine], [p for p in players if p['team'] != mine]]
        found = next((p for p in players if me and p['uid'] == me), None)
        live = bool(match.get('live'))
        won = found['won'] if found else match.get('won')
        yours = self._is_me(profile)
        who = 'You' if yours else short(profile['username'])

        # ---- scoreboard header ----
        height = 150
        accent = GOLD if live else GREEN_DEEP if won else LOSS
        b.shape(x, y, w, height, 22, '#15241D' if (won and not live) else '#261519' if not live else '#1A1813', CARD_BOTTOM,
                accent, 1, 'right', shadow=True)
        hero = (found or {}).get('hero') or match.get('hero') or ''
        b.avatar(x + 26, y + 31, 88, '#2A2B33', '#1E1F26', accent, 2, picture=hero_picture(hero) if hero else None,
                 initials=initials(hero or profile['username']))
        result = 'LIVE MATCH' if live else 'VICTORY' if won else 'DEFEAT'
        b.text(x + 134, y + 48, result, 30, color=GOLD if live else GREEN_SOFT if won else LOSS_SOFT)
        mode = match.get('mode') or ''
        pills = []
        if mode:
            pills.append(('Ranked' if mode == 'Competitive' else mode, GOLD if mode == 'Competitive' else SOFT))
        seconds = match.get('seconds') or data.get('seconds') or 0
        if seconds:
            pills.append((f"{int(seconds // 60)}:{int(seconds % 60):02d}", SOFT))
        if match.get('when'):
            pills.append((ago(time.time() - match['when']), SOFT))
        px = x + 134
        for text, color in pills:
            pw = b.measure(text, 12, 'extra') + 20
            b.shape(px, y + 72, pw, 24, 12, '#1B1C23', None, '#2C2D37', 1)
            b.text(px + 10, y + 84, text, 12, 'extra', color)
            px += pw + 8
        line = f"{who} on {hero}" if hero else who
        tag = ' · MVP' if found and found['uid'] == data.get('mvp') else ' · SVP' if found and found['uid'] == data.get('svp') else ''
        b.text(x + 134, y + 118, line + tag, 15, 'extra', TEXT, fit=w * .4)
        # Points gained or lost, big, on the right.
        rx = x + w - 28
        if match.get('change') is not None:
            change = match['change']
            b.text(rx, y + 58, f"{'+' if change > 0 else ''}{change:.0f}", 40,
                   color=GREEN_SOFT if change > 0 else LOSS_SOFT if change < 0 else SOFT, anchor='e')
            b.text(rx, y + 96, 'rank points' + (f"  ·  now {match['score']:,.0f}" if match.get('score') is not None else ''),
                   12, 'bold', MUTED, anchor='e')
        # Team totals in the middle.
        totals = []
        for team in teams:
            totals.append({'kills': sum(p['kills'] for p in team), 'damage': sum(p.get('damage') or 0 for p in team),
                           'heal': sum(p.get('heal') or 0 for p in team)})
        if len(totals) == 2 and teams[1]:
            cx = x + w * .62
            labels = [('Kills', 'kills', str), ('Damage', 'damage', short_number), ('Healing', 'heal', short_number)]
            b.text(cx - 70, y + 20, ('YOUR TEAM' if yours else 'THEIR TEAM'), 10, 'extra', MUTED, anchor='e')
            b.text(cx + 70, y + 20, 'ENEMY' if yours else 'OTHER TEAM', 10, 'extra', MUTED)
            for i, (label, key, fmt) in enumerate(labels):
                ty = y + 46 + i * 34
                a_val, b_val = totals[0][key], totals[1][key]
                b.text(cx - 70, ty, fmt(a_val), 16, 'extra', TEXT if a_val >= b_val else SOFT, anchor='e')
                b.text(cx, ty, label, 11, 'bold', MUTED, anchor='center')
                b.text(cx + 70, ty, fmt(b_val), 16, 'extra', TEXT if b_val > a_val else SOFT)
                share = a_val / max(1, a_val + b_val)
                b.shape(cx - 70, ty + 13, 140, 4, 2, '#3A2328', None, None)
                b.shape(cx - 70, ty + 13, max(4, 140 * share), 4, 2, GREEN_DEEP if share >= .5 else '#2F6B50', None, None)
        y += height + 18
        show_blocked = any(p.get('blocked') is not None for p in players)
        tops = {f: max((p.get(f) or 0 for p in players), default=1) or 1 for f in ('damage', 'heal', 'blocked', 'taken')}
        from scout.stats.extras import match_grades
        grades = match_grades(players)
        for index, team in enumerate(teams):
            if not team:
                continue
            team_won = any(p['won'] for p in team)
            if index == 0:
                label = 'Your team' if yours else f"{short(profile['username'])}'s team"
            else:
                label = 'Enemy team' if yours else 'Other team'
            y = self._match_team(team, label, team_won, data, show_blocked, x, y, w, neutral=live,
                                 me=me, tops=tops, grades=grades) + 18
        b.text(x + 4, y - 4, 'Grades are Scout\'s own rating: each player next to the best in this lobby at their job '
               '(damage, healing or blocking), plus kills, assists, deaths and the win.', 11, 'bold', MUTED, fit=w - 8)
        y += 18
        return y - start + 8

    def _match_team(self, team, label, won, data, show_blocked, x, y, w, neutral=False, me='', tops=None, grades=None):
        b = self.board
        row_h, head_h = 58, 78
        height = head_h + len(team) * (row_h + 6) + 10
        b.shape(x, y, w, height, 22, CARD_TOP, CARD_BOTTOM, CARD_LINE, 1, shadow=True)
        b.text(x + 22, y + 30, label.upper(), 13, 'extra', SOFT)
        if not neutral:
            pill = 'VICTORY' if won else 'DEFEAT'
            pw = b.measure(pill, 11) + 18
            lx = x + 22 + b.measure(label.upper(), 13, 'extra') + 12
            b.shape(lx, y + 19, pw, 22, 11, '#15241D' if won else '#261519', None, GREEN_DEEP if won else LOSS, 1)
            b.text(lx + pw / 2, y + 30, pill, 11, color=GREEN_SOFT if won else LOSS_SOFT, anchor='center')
        tops, grades = tops or {}, grades or {}
        columns = [('Grade', 64), ('K / D / A', 116), ('KDA', 66), ('Damage', 104), ('Healing', 104)]
        if show_blocked:
            columns.append(('Blocked', 104))
        if any(p.get('taken') is not None for p in team):
            columns.append(('Taken', 96))
        name_w = 270
        room = w - 44 - name_w
        shown, used = [], 0
        for column in columns:
            if used + column[1] <= room:
                shown.append(column)
                used += column[1]
        spare = (room - used) / max(1, len(shown))
        cx = x + 22 + name_w
        spots = []
        for title, width in shown:
            spots.append((title, cx, width + spare))
            b.text(cx + (width + spare) / 2, y + 60, title.upper(), 10, 'extra', MUTED, anchor='center')
            cx += width + spare
        b.text(x + 22, y + 60, 'PLAYER', 10, 'extra', MUTED)
        ry = y + head_h
        for player in sorted(team, key=lambda p: -(p.get('damage') or 0)):
            is_me = bool(me) and player['uid'] == me
            b.shape(x + 12, ry, w - 24, row_h, 12, '#201D15' if is_me else ROW_LEFT, '#17160F' if is_me else ROW_RIGHT,
                    GOLD_BOTTOM if is_me else CHIP_LINE, 1, 'right')
            hero = player.get('hero') or ''
            b.avatar(x + 24, ry + 9, 40, '#2A2B33', '#1E1F26', GOLD_BOTTOM if is_me else '#3A3B46', 1.5,
                     picture=hero_picture(hero) if hero else None, initials=initials(hero or player['name']))
            tag = 'MVP' if player['uid'] and player['uid'] == data.get('mvp') else 'SVP' if player['uid'] and player['uid'] == data.get('svp') else ''
            tag_w = b.measure(tag, 10) + 14 if tag else 0
            name_room = name_w - 80 - (tag_w + 8 if tag else 0)
            b.text(x + 76, ry + 21, player['name'], 15, color=GOLD if is_me else TEXT, fit=name_room)
            if tag:
                tx = x + 76 + min(b.measure(player['name'], 15), name_room) + 8
                b.shape(tx, ry + 12, tag_w, 18, 9, GOLD_TOP if tag == 'MVP' else '#D8D9E0', GOLD_BOTTOM if tag == 'MVP' else '#9C9DA8',
                        None, direction='right')
                b.text(tx + tag_w / 2, ry + 21, tag, 10, color=DARK, anchor='center')
            rating = grades.get(player.get('uid') or player.get('name')) or {}
            medals = rating.get('medals') or []
            mx = x + 76
            for short_name, why in medals[:3]:
                mw = b.measure(short_name, 9) + 12
                b.shape(mx, ry + 33, mw, 15, 7.5, '#2A2416', None, GOLD_BOTTOM, 1)
                b.text(mx + mw / 2, ry + 40.5, short_name, 9, color=GOLD, anchor='center')
                self._page_tip(mx, ry + 33, mw, 15, [(why, GOLD, 12)])
                mx += mw + 5
            others = [h for h in player.get('heroes') or [] if h != hero]
            b.text(mx + (4 if medals else 0), ry + 40, ' · '.join([hero or 'Unknown hero'] + others), 11, 'bold', MUTED,
                   fit=x + 76 + name_w - 80 - mx)
            kda = (player['kills'] + player['assists']) / max(player['deaths'], 1)
            for title, cx, width in spots:
                mid = ry + row_h / 2
                if title == 'K / D / A':
                    parts = [(str(player['kills']), GREEN_SOFT), (' / ', MUTED), (str(player['deaths']), RED), (' / ', MUTED), (str(player['assists']), BLUE)]
                    total = sum(b.measure(t, 15, 'extra') for t, _ in parts)
                    tx = cx + (width - total) / 2
                    for text, color in parts:
                        b.text(tx, mid, text, 15, 'extra', color)
                        tx += b.measure(text, 15, 'extra')
                elif title == 'KDA':
                    t1, t2 = kda_colors(kda)
                    pill = b.measure(f'{kda:.1f}', 13) + 18
                    b.shape(cx + (width - pill) / 2, mid - 11, pill, 22, 11, '#1F2027', None, t1, 1)
                    b.text(cx + width / 2, mid, f'{kda:.1f}', 13, color=t2, anchor='center')
                elif title == 'Grade':
                    grade = rating.get('grade', '')
                    if grade:
                        color = {'SS': GOLD, 'S': GOLD, 'A': GREEN_SOFT, 'B': TEXT, 'C': SOFT, 'F': LOSS_SOFT}[grade]
                        b.shape(cx + (width - 40) / 2, mid - 15, 40, 30, 8, '#2A2416' if grade in ('SS', 'S') else '#1F2027',
                                None, color if grade in ('SS', 'S', 'F') else '#33343E', 1)
                        b.text(cx + width / 2, mid, grade, 15, color=color, anchor='center')
                        self._page_tip(cx + (width - 40) / 2, mid - 15, 40, 30, [('Click to see why', MUTED, 11)])
                        self._page_hit(cx + (width - 40) / 2, mid - 15, 40, 30,
                                       lambda p=player, r=rating: self.show_grade_details(p, r))
                else:
                    # Damage, healing, blocked, taken: the number, with a bar against the best in the lobby.
                    field = {'Damage': 'damage', 'Healing': 'heal', 'Blocked': 'blocked', 'Taken': 'taken'}[title]
                    value = player.get(field) or 0
                    b.text(cx + width / 2, mid - 6, short_number(player.get(field)), 15, 'extra', TEXT, anchor='center')
                    bar = min(76, width - 20)
                    b.shape(cx + (width - bar) / 2, mid + 9, bar, 4, 2, '#24252D', None, None)
                    if value:
                        fill = {'damage': (GOLD_TOP, GOLD_BOTTOM), 'heal': (GREEN_SOFT, GREEN_DEEP),
                                'blocked': ('#B4CCF2', '#6F95D6'), 'taken': ('#B9BAC4', '#6E6F7C')}[field]
                        b.shape(cx + (width - bar) / 2, mid + 9, max(4, bar * value / tops.get(field, value)), 4, 2,
                                fill[0], fill[1], None, direction='right')
            if player['uid'] or player['name'] != 'Unknown':
                self._page_hit(x + 12, ry, w - 24, row_h, lambda p=player: self.open_player(p['name'], p['uid']))
            ry += row_h + 6
        return y + height

    def show_grade_details(self, player, rating):
        """Why this player got their grade, and how Scout's grades work."""
        from scout.ui import popup
        grade = rating.get('grade', '')
        name = player.get('name') or 'This player'
        colors = {'SS': GOLD, 'S': GOLD, 'A': GREEN_SOFT, 'B': TEXT, 'C': SOFT, 'F': LOSS_SOFT}
        rows = [popup.header(f'Why {name} got {grade}')]
        for what, number, share, points in rating.get('parts') or []:
            if share is None:
                detail = 'Their team won'
            else:
                shown = short_number(number) if what.startswith(('Main', 'Second')) else f'{number:g}'
                detail = f"{shown}  ·  {share * 100:.0f}% of the most in this lobby"
            rows.append(popup.stat(what, f"{'+' if points >= 0 else '−'}{abs(points):.2f}",
                                   GREEN_SOFT if points > 0 else LOSS_SOFT if points < 0 else MUTED, detail))
        if rating.get('parts'):
            rows.append(popup.separator())
            rows.append(popup.stat('Impact score', f"{rating['impact']:.2f}", TEXT,
                                   f"Lobby average {rating['average']:.2f}  ·  "
                                   f"#{rating['place']} of {rating['of']} players"))
            rows.append(popup.stat('Compared with the lobby', f"{rating['score']:+.1f}", colors.get(grade, TEXT),
                                   f"{abs(rating['score']):.1f} steps {'above' if rating['score'] >= 0 else 'below'} average"
                                   f"  →  {grade}"))
        rows.append(popup.separator())
        rows.append(popup.header('How grades work'))
        rows.append(popup.note('Everyone gets an impact score. Their main job (damage, healing or blocking, whichever '
                               'they did most of next to the best in the lobby) counts fully and their second job '
                               'counts 30%. Kills add up to 0.5, assists up to 0.3, deaths take off up to 0.4, and a '
                               'win adds 0.15.', lines=4))
        rows.append(popup.note('The grade is how far that score is from the lobby average, in steps of how spread out '
                               'the lobby is: SS 1.5+ above · S 0.9+ · A 0.3+ · B about average · C 0.3–0.9 below · '
                               'F more than 0.9 below.', lines=3))
        rows.append(popup.footer("Scout's own rating, not the game's."))
        self._open_popup(rows, width=380)
