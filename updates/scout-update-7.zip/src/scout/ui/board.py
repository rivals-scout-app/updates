"""A canvas that draws the bubbly pieces: shapes, text, buttons and type boxes.

Everything is placed in "design pixels" (the sizes in the approved mockup)
and multiplied by `scale`, so the window looks the same on any screen.
"""
import itertools
import tkinter as tk
from tkinter import font as tkfont

from PIL import ImageTk

from scout.ui import paint
from scout.ui.theme import (SOFT, DARK, FIELD, GOLD, GOLD_BOTTOM, GOLD_LINE, GOLD_TOP, MUTED, RAISED_BOTTOM,
                            RAISED_LINE, RAISED_TOP, TEXT, CORAL_TOP, CORAL_BOTTOM, CORAL_LINE, CORAL_TEXT,
                            font_family)

BUTTON_STYLES = {
    # fill top, fill bottom, outline, text, hover top, hover bottom
    'gold': (GOLD_TOP, GOLD_BOTTOM, GOLD_LINE, DARK, '#F6DFA8', '#DDB468'),
    'raised': (RAISED_TOP, RAISED_BOTTOM, RAISED_LINE, TEXT, '#2C2D37', '#25262F'),
    'coral': (CORAL_TOP, CORAL_BOTTOM, CORAL_LINE, CORAL_TEXT, '#45232A', '#33191F'),
    'quiet': ('#17181E', '#15161B', '#262730', TEXT, '#1F2027', '#1B1C22'),
    'bare': ((0, 0, 0, 1), None, None, MUTED, '#1F2027', '#1F2027'),
    'bare-close': ((0, 0, 0, 1), None, None, MUTED, '#C42B1C', '#C42B1C'),
}
_ids = itertools.count()


class Board:
    def __init__(self, canvas, scale=1.0):
        self.canvas = canvas
        self.scale = scale
        self.photos = []          # keep images alive while shown
        self.fonts = {}
        self.widgets = {}         # type boxes kept between redraws, by key
        self._used = set()
        self.texts = []           # every piece of text shown, for tests
        self._raster = None
        self.text_sizes = {}

    # ---- basics -----------------------------------------------------------
    def z(self, value):
        return int(round(value * self.scale))

    def begin(self):
        self.canvas.delete('all')
        self.photos = []
        self._used = set()
        self.texts = []
        self.text_sizes = {}

    def finish(self):
        """Forget type boxes that this redraw didn't place."""
        for key in [key for key in self.widgets if key not in self._used]:
            self.widgets.pop(key).destroy()

    def font(self, size, weight='black'):
        """A Tk font, for type boxes and menus (drawn text uses paint.text_image)."""
        key = (size, weight)
        if key not in self.fonts:
            family = font_family(self.canvas, weight)
            self.fonts[key] = tkfont.Font(root=self.canvas, family=family, size=-max(6, self.z(size)),
                                          weight='bold' if family == 'Segoe UI' and weight != 'bold' else 'normal')
        return self.fonts[key]

    def measure(self, text, size, weight='black'):
        return paint.text_width(text, self.z(size), weight) / self.scale

    def fit(self, text, size, width, weight='black'):
        """Shorten text with … so it fits in width."""
        if self.measure(text, size, weight) <= width:
            return text
        while text and self.measure(text + '…', size, weight) > width:
            text = text[:-1]
        return (text + '…') if text else ''

    def _put(self, image, left_px, top_px, tags=()):
        """Show `image` with its top-left at (left_px, top_px) screen pixels."""
        if self._raster is not None:
            if self._raster != 'measure':
                target, (ox, oy) = self._raster
                paste_rgba(target, image, int(left_px) - ox, int(top_px) - oy)
            return None
        return self.canvas.create_image(int(left_px), int(top_px), image=self._keep(image), anchor='nw', tags=tags)

    def raster(self, target, origin):
        """Draw into the picture `target` (screen point `origin` is its top-left) instead of the canvas.
        target 'measure' only works out sizes. Use None to go back to the canvas."""
        self._raster = None if target is None else ('measure' if target == 'measure' else (target, origin))

    def place_image(self, image, x, y, tags=(), anchor='nw'):
        if anchor != 'nw' or self._raster is None:
            photo = ImageTk.PhotoImage(image, master=self.canvas)
            self.photos.append(photo)
            return self.canvas.create_image(self.z(x), self.z(y), image=photo, anchor=anchor, tags=tags)
        return self._put(image, self.z(x), self.z(y), tags)

    # ---- shapes -------------------------------------------------------------
    def shape(self, x, y, w, h, radius, top, bottom=None, line=None, line_width=1.5,
              direction='diagonal', glow=None, glow_size=0, shadow=False, tags=()):
        # Crisp look: pills stay round, everything else gets tighter corners and hairline edges.
        radius = radius if radius >= min(w, h) / 2 - 0.5 else min(radius * 0.5, 12)
        line_width = min(line_width, 1.0)
        image, pad = paint.bubble(self.z(w), self.z(h), self.z(radius), top, bottom, line, line_width * self.scale,
                                  direction, glow, self.z(glow_size), shadow)
        return self._put(image, self.z(x) - pad, self.z(y) - pad, tags)

    def mastery_frame(self, x, y, size, level, tags=()):
        """Lord (20+) or Champion (50+) frame over a round picture drawn at (x, y, size). Nothing below Lord."""
        if not level or level < 20:
            return None
        image, pad = paint.mastery_frame(self.z(size), level >= 50)
        return self._put(image, self.z(x) - pad, self.z(y) - pad, tags)

    def avatar(self, x, y, size, top, bottom, ring, ring_width=3, glow=None, picture=None, initials='', tags=()):
        image, pad = paint.avatar(self.z(size), top, bottom, ring, min(ring_width, 1.5) * self.scale, glow,
                                  str(picture) if picture else None)
        item = self._put(image, self.z(x) - pad, self.z(y) - pad, tags)
        if initials and not picture:
            self.text(x + size / 2, y + size / 2, initials, size * .34, color=SOFT, anchor='center', tags=tags)
        return item

    def dot(self, x, y, size, color, tags=()):
        image, pad = paint.dot(self.z(size), color)
        return self._put(image, self.z(x) - pad, self.z(y) - pad, tags)

    def _keep(self, image):
        photo = ImageTk.PhotoImage(image, master=self.canvas)
        self.photos.append(photo)
        return photo

    # ---- text ------------------------------------------------------------------
    def text(self, x, y, text, size, weight='black', color=TEXT, anchor='w', width=None, tags=(), justify='left', fit=None):
        """Text drawn with the bundled Nunito font. (x, y) is where `anchor` sits, like Tk text.

        fit: the room it has. Text that doesn't fit gets smaller (down to about
        two thirds of its size) so all of it shows; only text that still won't
        fit is shortened with ….
        """
        if fit:
            text = str(text)
            smallest = max(9, size * .66)
            while size > smallest and self.measure(text, size, weight) > fit:
                size = max(smallest, size - .5)
            text = self.fit(text, size, fit, weight)
        lines = self._wrap(str(text), size, weight, width) if width else str(text).split('\n')
        image = paint.text_image('\n'.join(lines), self.z(size), weight, color, justify)
        w, h = image.size[0] / self.scale, image.size[1] / self.scale
        anchor = '' if anchor == 'center' else anchor
        left = x - (w if 'e' in anchor else 0 if 'w' in anchor else w / 2)
        top = y - (h if 's' in anchor else 0 if 'n' in anchor else h / 2)
        self.texts.append(str(text))
        item = self._put(image, self.z(left), self.z(top), tags)
        if item is not None:
            self.text_sizes[item] = h
        return item

    def _wrap(self, text, size, weight, width):
        lines = []
        for paragraph in text.split('\n'):
            line = ''
            for word in paragraph.split(' '):
                trial = (line + ' ' + word).strip()
                if line and self.measure(trial, size, weight) > width:
                    lines.append(line)
                    line = word
                else:
                    line = trial
            lines.append(line)
        return lines

    def text_height(self, item):
        return self.text_sizes.get(item, 0)

    # ---- controls ------------------------------------------------------------
    def button(self, x, y, label, command, style='raised', height=40, size=15, weight='black',
               icon=None, width=None, disabled=False, radius=None, glow=False, tags=()):
        """A pill button. Returns its width in design pixels."""
        top, bottom, line, ink, hover_top, hover_bottom = BUTTON_STYLES[style]
        icon_space = 26 if icon else 0
        width = width or (self.measure(label, size, weight) + icon_space + height * .9)
        radius = height / 2 if radius is None else radius
        tag = f'button{next(_ids)}'
        shine = (GOLD_BOTTOM, 90) if glow and style == 'gold' else None
        normal = self.shape(x, y, width, height, radius, top, bottom, line, 2 if style == 'gold' else 1.5,
                            'down', shine, 9 if shine else 0, tags=(tag, *tags))
        content_x = x + (width - self.measure(label, size, weight) - icon_space) / 2
        if icon:
            icon(self, content_x + 9, y + height / 2, ink, (tag, *tags))
        self.text(content_x + icon_space, y + height / 2, label, size, weight, MUTED if disabled else ink, tags=(tag, *tags))
        if disabled:
            return width
        hover, _ = paint.bubble(self.z(width), self.z(height), self.z(radius), hover_top, hover_bottom, line,
                                (2 if style == 'gold' else 1.5) * self.scale, 'down', shine, self.z(9) if shine else 0)
        hover_photo = self._keep(hover)
        normal_photo = self.canvas.itemcget(normal, 'image')
        self.canvas.tag_bind(tag, '<Enter>', lambda e: (self.canvas.itemconfigure(normal, image=hover_photo),
                                                         self.canvas.configure(cursor='hand2')))
        self.canvas.tag_bind(tag, '<Leave>', lambda e: (self.canvas.itemconfigure(normal, image=normal_photo),
                                                         self.canvas.configure(cursor='')))
        self.canvas.tag_bind(tag, '<ButtonRelease-1>', lambda e: command())
        return width

    def window_button(self, x, y, w, h, icon, command, danger=False, tags=()):
        """A title-bar button (minimize / maximize / close): a soft rounded chip on hover, icon centred."""
        tag = f'button{next(_ids)}'
        radius = 8
        hover_fill = ('#E5484D', '#D63C42') if danger else ('#262731', '#21222B')
        hover, pad = paint.bubble(self.z(w), self.z(h), self.z(radius), hover_fill[0], hover_fill[1],
                                  '#3A3B47' if not danger else None, 1.0 * self.scale, 'down', None, 0)
        hover_photo = self._keep(hover)
        # Nearly clear when idle (still catches the mouse across the whole chip).
        idle, _ = paint.bubble(self.z(w), self.z(h), self.z(radius), (0, 0, 0, 1), (0, 0, 0, 1), None, 0, 'down', None, 0)
        idle_photo = self._keep(idle)
        chip = self.canvas.create_image(self.z(x) - pad, self.z(y) - pad, image=idle_photo, anchor='nw', tags=(tag, *tags))
        icon_tag = f'{tag}-icon'
        icon(self, x + w / 2, y + h / 2, MUTED, (tag, icon_tag, *tags))
        bright = '#FFFFFF' if danger else TEXT

        def paint_icon(color):
            for item in self.canvas.find_withtag(icon_tag):
                kind = self.canvas.type(item)
                if kind == 'rectangle':
                    self.canvas.itemconfigure(item, outline=color)
                else:
                    self.canvas.itemconfigure(item, fill=color)

        def enter(_e):
            self.canvas.itemconfigure(chip, image=hover_photo)
            self.canvas.configure(cursor='hand2')
            paint_icon(bright)

        def leave(_e):
            self.canvas.itemconfigure(chip, image=idle_photo)
            self.canvas.configure(cursor='')
            paint_icon(MUTED)

        self.canvas.tag_bind(tag, '<Enter>', enter)
        self.canvas.tag_bind(tag, '<Leave>', leave)
        self.canvas.tag_bind(tag, '<ButtonRelease-1>', lambda e: command())
        self.canvas.tag_raise(icon_tag, chip)
        return w

    def clickable(self, tag, command):
        self.canvas.tag_bind(tag, '<Enter>', lambda e: self.canvas.configure(cursor='hand2'))
        self.canvas.tag_bind(tag, '<Leave>', lambda e: self.canvas.configure(cursor=''))
        self.canvas.tag_bind(tag, '<ButtonRelease-1>', lambda e: command())

    def entry(self, key, x, y, w, h, value='', on_enter=None, background=FIELD, size=16, placeholder=''):
        """A type box kept across redraws (keeps what's typed and the cursor)."""
        self._used.add(key)
        widget = self.widgets.get(key)
        if widget is None or not widget.winfo_exists():
            variable = tk.StringVar(master=self.canvas, value=value)
            widget = tk.Entry(self.canvas, textvariable=variable, relief='flat', borderwidth=0, highlightthickness=0,
                              bg=background, fg=TEXT, insertbackground=GOLD, disabledbackground=background,
                              font=self.font(size, 'extra'))
            widget.variable = variable
            widget.placeholder = placeholder
            if placeholder:
                _placeholder(widget)
            if on_enter:
                widget.bind('<Return>', lambda e: on_enter())
            self.widgets[key] = widget
        else:
            widget.configure(bg=background, disabledbackground=background, font=self.font(size, 'extra'))
        self.canvas.create_window(self.z(x), self.z(y + h / 2), window=widget, anchor='w',
                                  width=self.z(w), height=self.z(h))
        return widget


def _placeholder(widget):
    """Grey hint text in an empty type box."""
    def show(_event=None):
        if not widget.variable.get():
            widget.configure(fg=MUTED)
            widget.variable.set(widget.placeholder)
            widget.showing_hint = True

    def hide(_event=None):
        if getattr(widget, 'showing_hint', False):
            widget.variable.set('')
            widget.configure(fg=TEXT)
            widget.showing_hint = False
    widget.bind('<FocusIn>', hide, add='+')
    widget.bind('<FocusOut>', show, add='+')
    widget.typed = lambda: '' if getattr(widget, 'showing_hint', False) else widget.variable.get()
    show()


def typed(widget):
    """What the person typed in a Board type box (not its hint text)."""
    getter = getattr(widget, 'typed', None)
    return getter() if getter else widget.get()


# ---- small line icons, drawn in the button's text color ----------------------
def icon_scan(board, x, y, color, tags):
    c, z = board.canvas, board.z
    for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        cx, cy = x + dx * 7, y + dy * 7
        c.create_line(z(cx), z(cy - dy * 4), z(cx), z(cy), z(cx - dx * 4), z(cy), fill=color, width=z(2.4),
                      capstyle='round', joinstyle='round', tags=tags)


def icon_search(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_oval(z(x - 7), z(y - 7), z(x + 4), z(y + 4), outline=color, width=z(2.2), tags=tags)
    c.create_line(z(x + 3), z(y + 3), z(x + 8), z(y + 8), fill=color, width=z(2.2), capstyle='round', tags=tags)


def icon_scope(board, x, y, color, tags, size=1.0):
    c, z = board.canvas, board.z
    r, inner, tick = 7 * size, 2.5 * size, 10 * size
    width = z(2.6 * size)
    c.create_oval(z(x - r), z(y - r), z(x + r), z(y + r), outline=color, width=width, tags=tags)
    c.create_oval(z(x - inner), z(y - inner), z(x + inner), z(y + inner), outline=color, width=width, tags=tags)
    for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
        c.create_line(z(x + dx * (r + 1)), z(y + dy * (r + 1)), z(x + dx * tick), z(y + dy * tick), fill=color,
                      width=width, capstyle='round', tags=tags)


def icon_dots(board, x, y, color, tags):
    c, z = board.canvas, board.z
    for dx in (-7, 0, 7):
        c.create_oval(z(x + dx - 2), z(y - 2), z(x + dx + 2), z(y + 2), fill=color, outline='', tags=tags)


def icon_arrow(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_line(z(x - 7), z(y), z(x + 7), z(y), fill=color, width=z(2.6), capstyle='round', tags=tags)
    c.create_line(z(x + 1), z(y - 6), z(x + 7), z(y), z(x + 1), z(y + 6), fill=color, width=z(2.6),
                  capstyle='round', joinstyle='round', tags=tags)


def icon_win_close(board, x, y, color, tags):
    c, z = board.canvas, board.z
    for a, b in ((-5, 5), (5, -5)):
        c.create_line(z(x - 5), z(y + a), z(x + 5), z(y + b), fill=color, width=z(1.6), capstyle='round', tags=tags)


def icon_win_maximize(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_rectangle(z(x - 5), z(y - 5), z(x + 5), z(y + 5), outline=color, width=z(1.5), tags=tags)


def icon_win_restore(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_rectangle(z(x - 5), z(y - 3), z(x + 3), z(y + 5), outline=color, width=z(1.5), tags=tags)
    c.create_line(z(x - 2), z(y - 3), z(x - 2), z(y - 6), z(x + 6), z(y - 6), z(x + 6), z(y + 2), z(x + 3), z(y + 2),
                  fill=color, width=z(1.5), tags=tags)


def icon_win_minimize(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_line(z(x - 5), z(y), z(x + 5), z(y), fill=color, width=z(1.5), capstyle='round', tags=tags)


def icon_close(board, x, y, color, tags):
    c, z = board.canvas, board.z
    for a, b in ((-5, 5), (5, -5)):
        c.create_line(z(x - 5), z(y + a), z(x + 5), z(y + b), fill=color, width=z(2.6), capstyle='round', tags=tags)


def paste_rgba(target, image, left, top):
    """Blend `image` onto `target` at (left, top), cutting off whatever falls outside."""
    if image.mode != 'RGBA':
        image = image.convert('RGBA')
    x0, y0 = max(0, left), max(0, top)
    x1, y1 = min(target.width, left + image.width), min(target.height, top + image.height)
    if x1 <= x0 or y1 <= y0:
        return
    piece = image.crop((x0 - left, y0 - top, x1 - left, y1 - top))
    target.alpha_composite(piece, (x0, y0))


def icon_person(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_oval(z(x - 4.5), z(y - 9), z(x + 4.5), z(y), outline=color, width=z(2.2), tags=tags)
    c.create_arc(z(x - 9), z(y + 2), z(x + 9), z(y + 20), start=0, extent=180, style='arc', outline=color,
                 width=z(2.2), tags=tags)


def icon_trend(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_line(z(x - 9), z(y + 6), z(x - 3), z(y), z(x + 1), z(y + 3), z(x + 9), z(y - 6), fill=color,
                  width=z(2.2), capstyle='round', joinstyle='round', tags=tags)
    c.create_line(z(x + 3), z(y - 6), z(x + 9), z(y - 6), z(x + 9), z(y), fill=color, width=z(2.2),
                  capstyle='round', joinstyle='round', tags=tags)


def icon_bars(board, x, y, color, tags):
    c, z = board.canvas, board.z
    for row, length in ((-6, 18), (0, 12), (6, 7)):
        c.create_line(z(x - 9), z(y + row), z(x - 9 + length), z(y + row), fill=color, width=z(2.4), capstyle='round',
                      tags=tags)


def icon_star(board, x, y, color, tags):
    import math
    c, z = board.canvas, board.z
    points = []
    for i in range(10):
        r = 9 if i % 2 == 0 else 4
        a = math.pi / 2 + i * math.pi / 5
        points += [z(x + r * math.cos(a)), z(y - r * math.sin(a))]
    c.create_polygon(*points, outline=color, fill='', width=z(2), joinstyle='round', tags=tags)


def icon_sliders(board, x, y, color, tags):
    c, z = board.canvas, board.z
    for row, knob in ((-6, 3), (0, -4), (6, 2)):
        c.create_line(z(x - 9), z(y + row), z(x + 9), z(y + row), fill=color, width=z(2), capstyle='round', tags=tags)
        c.create_oval(z(x + knob - 2.6), z(y + row - 2.6), z(x + knob + 2.6), z(y + row + 2.6), fill=color, outline='',
                      tags=tags)


def icon_minimize(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_line(z(x - 6), z(y), z(x + 6), z(y), fill=color, width=z(1.5), tags=tags)


def icon_maximize(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_rectangle(z(x - 6), z(y - 6), z(x + 6), z(y + 6), outline=color, width=z(1.5), tags=tags)


def icon_restore(board, x, y, color, tags):
    c, z = board.canvas, board.z
    c.create_rectangle(z(x - 6), z(y - 3), z(x + 3), z(y + 6), outline=color, width=z(1.5), tags=tags)
    c.create_line(z(x - 3), z(y - 3), z(x - 3), z(y - 6), z(x + 6), z(y - 6), z(x + 6), z(y + 3), z(x + 3), z(y + 3),
                  fill=color, width=z(1.5), tags=tags)
