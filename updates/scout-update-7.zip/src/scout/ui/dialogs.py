"""The smaller windows: Edit names and Your team."""
import tkinter as tk
from tkinter import ttk

from scout.stats.advisor import role_for
from scout.stats.tracker import HERO_NAMES
from scout.ui.theme import (BG, CARD_LINE, DARK, FIELD, GOLD, GOLD_BOTTOM, MUTED, RAISED_BOTTOM, RAISED_LINE, TEXT,
                            font_family)

PANEL = '#121318'


class Dialogs:
    def _dialog_fonts(self):
        black, extra, bold = (font_family(self.root, weight) for weight in ('black', 'extra', 'bold'))
        s = self.ui_scale
        return {'title': (black, -int(22 * s)), 'label': (bold, -int(13 * s)), 'field': (extra, -int(15 * s)),
                'button': (black, -int(14 * s))}

    def _style_dialogs(self):
        fonts = self._dialog_fonts()
        style = ttk.Style(self.root)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        style.configure('Scout.TCombobox', fieldbackground=FIELD, background=RAISED_BOTTOM, foreground=TEXT,
                        arrowcolor=GOLD, bordercolor=CARD_LINE, lightcolor=CARD_LINE, darkcolor=CARD_LINE, padding=6)
        style.map('Scout.TCombobox', fieldbackground=[('readonly', FIELD)], foreground=[('readonly', TEXT)],
                  selectbackground=[('readonly', FIELD)], selectforeground=[('readonly', TEXT)])
        self.root.option_add('*TCombobox*Listbox.background', PANEL)
        self.root.option_add('*TCombobox*Listbox.foreground', TEXT)
        self.root.option_add('*TCombobox*Listbox.selectBackground', '#262731')
        self.root.option_add('*TCombobox*Listbox.font', fonts['field'])

    def _field(self, parent, **options):
        return tk.Entry(parent, relief='flat', bg=FIELD, fg=TEXT, insertbackground=GOLD, disabledbackground=FIELD,
                        highlightthickness=2, highlightbackground=CARD_LINE, highlightcolor=GOLD,
                        font=self._dialog_fonts()['field'], **options)

    def _pill(self, parent, text, command, gold=False):
        fonts = self._dialog_fonts()
        return tk.Button(parent, text=text, command=command, relief='flat', borderwidth=0, cursor='hand2',
                         bg=GOLD if gold else RAISED_BOTTOM, fg=DARK if gold else TEXT,
                         activebackground=GOLD_BOTTOM if gold else '#24252E', activeforeground=DARK if gold else TEXT,
                         font=fonts['button'], padx=int(18 * self.ui_scale), pady=int(8 * self.ui_scale),
                         highlightthickness=1, highlightbackground=RAISED_LINE)

    def _label(self, parent, text, kind='label', color=MUTED, **options):
        return tk.Label(parent, text=text, bg=parent.cget('bg'), fg=color, font=self._dialog_fonts()[kind], **options)

    # ---- Edit names ------------------------------------------------------------
    def _build_names_window(self):
        """Made once and hidden; its six boxes hold the enemy names the app looks up."""
        window = tk.Toplevel(self.root)
        window.title('Edit names')
        window.configure(bg=PANEL)
        window.withdraw()
        window.protocol('WM_DELETE_WINDOW', window.withdraw)
        window.transient(self.root)
        pad = int(20 * self.ui_scale)
        self._label(window, 'Enemy names', 'title', TEXT).grid(row=0, column=0, columnspan=3, sticky='w', padx=pad, pady=(pad, 4))
        self._label(window, 'Fix a name or type one in. Names you type are looked up exactly as written.').grid(
            row=1, column=0, columnspan=3, sticky='w', padx=pad, pady=(0, pad // 2))
        self.entries = []
        for index in range(6):
            self._label(window, str(index + 1)).grid(row=index + 2, column=0, padx=(pad, 8), pady=3)
            entry = self._field(window, width=30)
            entry.grid(row=index + 2, column=1, columnspan=2, sticky='ew', padx=(0, pad), pady=3, ipady=4)
            entry.bind('<Return>', lambda e: self._look_up_names())
            self.entries.append(entry)
        side = tk.Frame(window, bg=PANEL)
        side.grid(row=8, column=0, columnspan=3, sticky='w', padx=pad, pady=(pad // 2, 0))
        self._label(side, 'Enemy team is on the').pack(side='left')
        for value in ('Right', 'Left'):
            tk.Radiobutton(side, text=value, value=value, variable=self.enemy_side, command=self._swap_scan_sides,
                           bg=PANEL, fg=TEXT, selectcolor=FIELD, activebackground=PANEL, activeforeground=TEXT,
                           font=self._dialog_fonts()['label']).pack(side='left', padx=(8, 0))
        buttons = tk.Frame(window, bg=PANEL)
        buttons.grid(row=9, column=0, columnspan=3, sticky='ew', padx=pad, pady=pad)
        self._pill(buttons, 'Look up these names', self._look_up_names, gold=True).pack(side='left')
        self._pill(buttons, 'Clear', self.clear_names).pack(side='left', padx=(8, 0))
        window.columnconfigure(1, weight=1)
        self.names_window = window

    def show_tools(self, visible=True):
        if not visible:
            self.names_window.withdraw()
            return
        self.names_window.deiconify()
        self.names_window.lift()
        if self.entries:
            self.entries[0].focus_set()

    def _look_up_names(self):
        self.names_window.withdraw()
        self.fetch_stats()

    # ---- Your team ----------------------------------------------------------------
    def edit_team(self):
        dialog = tk.Toplevel(self.root)
        dialog.title('Your team')
        dialog.configure(bg=PANEL)
        dialog.transient(self.root)
        pad = int(20 * self.ui_scale)
        self._label(dialog, 'Your team', 'title', TEXT).grid(row=0, column=0, columnspan=3, sticky='w', padx=pad, pady=(pad, 4))
        self._label(dialog, "Scanned teammates load their favorite heroes by themselves. Planned picks are optional;\n"
                            "picks aren't read from the screen, so add them to keep them out of the bans.",
                    justify='left').grid(row=1, column=0, columnspan=3, sticky='w', padx=pad, pady=(0, pad // 2))
        for column, title in enumerate(['Teammate name or UID', 'Planned hero', 'Role']):
            self._label(dialog, title).grid(row=2, column=column, sticky='w', padx=(pad if column == 0 else 0, 8))
        fields = []
        heroes = [''] + sorted(set(HERO_NAMES.values()))
        for index in range(6):
            saved = self.team_picks[index] if index < len(self.team_picks) else ('', 'Unknown role')
            ally = tk.StringVar(value=self.ally_names[index] if index < len(self.ally_names) else '')
            hero = tk.StringVar(value=saved[0])
            role = tk.StringVar(value=saved[1])
            self._field(dialog, textvariable=ally, width=22).grid(row=index + 3, column=0, padx=(pad, 8), pady=3, ipady=3)
            box = ttk.Combobox(dialog, textvariable=hero, values=heroes, width=22, style='Scout.TCombobox',
                               font=self._dialog_fonts()['field'])
            box.grid(row=index + 3, column=1, padx=(0, 8), pady=3)
            box.bind('<<ComboboxSelected>>', lambda e, h=hero, r=role: r.set(role_for(h.get())))
            ttk.Combobox(dialog, textvariable=role, values=['Unknown role', 'Vanguard', 'Duelist', 'Strategist'],
                         state='readonly', width=14, style='Scout.TCombobox',
                         font=self._dialog_fonts()['field']).grid(row=index + 3, column=2, padx=(0, pad), pady=3)
            fields.append((ally, hero, role))
        self._label(dialog, 'Already banned or unavailable (separate with commas)').grid(
            row=9, column=0, columnspan=3, padx=pad, pady=(pad // 2, 3), sticky='w')
        excluded = tk.StringVar(value=', '.join(self.excluded_bans))
        self._field(dialog, textvariable=excluded).grid(row=10, column=0, columnspan=3, sticky='ew', padx=pad, ipady=3)
        self._label(dialog, 'Enemy role to ban first (optional)').grid(row=11, column=0, columnspan=2, padx=pad, pady=pad // 2, sticky='w')
        priority = tk.StringVar(value=self.ban_priority)
        ttk.Combobox(dialog, textvariable=priority, values=['Any role', 'Vanguard', 'Duelist', 'Strategist'], state='readonly',
                     width=14, style='Scout.TCombobox', font=self._dialog_fonts()['field']).grid(row=11, column=2, padx=(0, pad))

        def apply():
            previous_allies = self.ally_names
            self.ally_names = list(dict.fromkeys(a.get().strip() for a, h, r in fields if a.get().strip()))
            self.team_picks = [(h.get().strip(), r.get()) for a, h, r in fields]
            self.excluded_bans = [name.strip() for name in excluded.get().split(',') if name.strip()]
            self.ban_priority = priority.get()
            if previous_allies != self.ally_names:
                self.ally_results.clear()
            self.update_advice()
            dialog.destroy()
            if previous_allies != self.ally_names and not self.busy and self.enemy_names():
                self.fetch_stats()
        self._pill(dialog, 'Save team', apply, gold=True).grid(row=12, column=0, columnspan=3, padx=pad, pady=pad, sticky='ew')
        return dialog
