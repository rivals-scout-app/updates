"""Colors, fonts and sizes for the Rivals Scout look: dark graphite, one gold accent."""
import ctypes
import sys

from scout import paths

# Ground and cards
BG = '#0B0C10'
GLOW_PURPLE = (24, 24, 36)
GLOW_PINK = (30, 25, 18)
CARD_TOP = '#16171D'
CARD_BOTTOM = '#121318'
CARD_LINE = '#262730'
ROW_LEFT = '#1B1C23'
ROW_RIGHT = '#17181E'
CHIP_FILL = (255, 255, 255, 10)
CHIP_LINE = '#2C2D37'
RAISED_TOP = '#24252E'
RAISED_BOTTOM = '#1E1F27'
RAISED_LINE = '#353642'
FIELD = '#101116'

# Text
TEXT = '#F3F3F6'
SOFT = '#C9CAD3'
MUTED = '#8C8D9A'
DARK = '#14120C'

# Accents
GOLD = '#E6C27A'
GOLD_TOP = '#F1D497'
GOLD_BOTTOM = '#D6AC5C'
GOLD_LINE = '#F6E2B4'
CORAL_TOP = '#3B1D23'
CORAL_BOTTOM = '#2A161B'
CORAL_LINE = '#B5525F'
CORAL_TEXT = '#FFE3E3'
GREEN = '#5ED39C'
GREEN_SOFT = '#86E2B6'
GREEN_DEEP = '#3FB883'
RED = '#F08A8A'
BLUE = '#93B8F0'
WARN_LEFT = '#2C2617'
WARN_RIGHT = '#1C1A16'
WARN_TEXT = '#E3D3A6'
HIDDEN_LEFT = '#17181D'
HIDDEN_RIGHT = '#141519'
LOSS = '#D9606E'
LOSS_SOFT = '#F08A8A'

# Bubble colors for player avatars, picked by name so each player keeps theirs.
AVATAR_TINTS = [
    ('#3A3B47', '#2A2B34', '#4A4B58'),
    ('#2F3A48', '#232B36', '#3E4B5C'),
    ('#2E4038', '#222F2A', '#3C5248'),
    ('#43323A', '#30252B', '#58434D'),
    ('#463D2C', '#332D21', '#5C503A'),
    ('#3F3530', '#2E2723', '#54463F'),
]

FONT_FILES = {'black': 'ScoutInter-Bold.otf', 'extra': 'ScoutInter-SemiBold.otf', 'bold': 'ScoutInter-Medium.otf'}
FONT_FAMILIES = {'black': 'Scout Inter Bold', 'extra': 'Scout Inter SemiBold', 'bold': 'Scout Inter Medium'}
FALLBACK_FONT = 'Segoe UI'


def load_fonts():
    """Make the bundled Inter fonts usable by this process only (nothing is installed)."""
    if not sys.platform.startswith('win'):
        return
    try:
        add = ctypes.windll.gdi32.AddFontResourceExW
    except AttributeError:
        return
    for name in FONT_FILES.values():
        path = paths.asset('fonts', name)
        if path.is_file():
            add(str(path), 0x10, 0)  # FR_PRIVATE


def font_family(root, weight):
    from tkinter import font as tkfont
    try:
        families = set(tkfont.families(root))
    except Exception:
        families = set()
    family = FONT_FAMILIES[weight]
    return family if family in families else FALLBACK_FONT


def tint_for(name):
    return AVATAR_TINTS[sum(map(ord, name or '?')) % len(AVATAR_TINTS)]


def win_color(win_pct):
    try:
        value = float(str(win_pct).rstrip('%'))
    except ValueError:
        return TEXT
    return GREEN if value >= 55 else RED if value < 48 else TEXT


def kda_colors(kda):
    if kda is None:
        return ('#3A3B47', '#3A3B47')
    if kda >= 4:
        return (GREEN_DEEP, GREEN_SOFT)
    if kda >= 2.5:
        return ('#D6AC5C', '#F1D497')
    return ('#C9505F', '#F08A8A')
