"""Your own page (the Me tab): a personal dashboard instead of the generic player page."""
from scout.ui.common import *  # noqa: F401,F403


class MePageViews:
    def _is_me(self, profile):
        me = self.me() if hasattr(self, 'me') else None
        return bool(me) and isinstance(profile, dict) and str(profile.get('uid')) == str(me.get('uid'))

    def _me_content(self, profile, x, y, w):
        """Draw your dashboard from y down; returns its height."""
        bottom = self._me_header(profile, x, y, w)
        bottom = self._me_cards(profile, x, bottom + 18, w)
        left_w = w * .62 if w > 1000 else w
        heroes_bottom = self._page_heroes(profile, x, bottom + 18, left_w)
        if w > 1000:
            if profile.get('maps'):
                heroes_bottom = self._maps_card(profile, x, heroes_bottom + 18, left_w) - 18
            side_bottom = self._page_side(profile, x + left_w + 18, bottom + 18, w - left_w - 18, maps=False)
        else:
            side_bottom = self._page_side(profile, x, heroes_bottom + 18, w)
        return max(heroes_bottom, side_bottom) - y + 8

    # ---- header: who you are, your rank, how far to the next one -------------------------------
    def _me_header(self, profile, x, y, w):
        from scout.stats.extras import score_for_level, rank_goal
        from scout.stats.tracker import RANKS
        b = self.board
        height = 190
        b.shape(x, y, w, height, 28, '#1A1813', CARD_BOTTOM, CARD_LINE, 1.5, shadow=True, glow=(GOLD_BOTTOM, 26), glow_size=12)
        heroes = profile.get('heroes', [])
        name = short(profile['username'])
        lords = [row for row in profile.get('proficiency') or [] if row.get('level', 0) >= 20]
        top_lord = max(lords, key=lambda row: row['level']) if lords else None
        face = top_lord['hero'] if top_lord else (heroes[0]['hero_name'] if heroes else None)
        b.avatar(x + 26, y + 36, 106, '#2A2B33', '#1E1F26', GOLD_BOTTOM, 2, glow=(GOLD_BOTTOM, 60),
                 picture=hero_picture(face) if face else None, initials=initials(name))
        if top_lord:
            b.mastery_frame(x + 26, y + 36, 106, top_lord['level'])
        tx = x + 160
        b.text(tx, y + 40, 'Welcome back,', 14, 'bold', MUTED)
        b.text(tx, y + 70, name, 32, fit=w * .42 - 160)
        ranks = profile.get('ranks') or []
        now = getattr(self, 'my_now', None) or {}
        level = int(now.get('level') or (ranks[0]['level'] if ranks else 0) or 0)
        score = now.get('score') or (ranks[0]['score'] if ranks else 0)
        if level:
            rank = RANKS[max(1, min(len(RANKS), level)) - 1]
            tier = rank.rsplit(' ', 1)[0] if rank.split()[-1] in ('I', 'II', 'III') else rank
            division = {'III': 3, 'II': 2, 'I': 1}.get(rank.split()[-1], 0)
            picture = paint.rank_emblem(tier, division, b.z(44))
            if picture is not None:
                b.place_image(picture, tx - 6, y + 86)
            else:
                b.place_image(paint.rank_icon(tier, 0, b.z(36)), tx, y + 98)
            b.text(tx + 48, y + 108, rank, 18, color=paint.RANK_COLORS.get(tier, (TEXT,))[0])
            b.text(tx + 48 + b.measure(rank, 18) + 10, y + 109, f'{score:,.0f} pts', 14, 'bold', SOFT)
            # Progress through this division.
            start, end = score_for_level(level), score_for_level(level + 1)
            share = max(0.0, min(1.0, (score - start) / max(1, end - start)))
            bar_w = min(360, w * .42 - 170)
            b.shape(tx, y + 136, bar_w, 8, 4, '#24252D', None, None)
            if share > 0:
                b.shape(tx, y + 136, max(8, bar_w * share), 8, 4, GOLD_TOP, GOLD_BOTTOM, None, direction='right')
            nxt = RANKS[level] if level < len(RANKS) else ''
            if nxt:
                b.text(tx, y + 162, f'{max(0, end - score):,.0f} pts to {nxt}', 12, 'bold', MUTED)
            goal_level = self.settings.get('rank_goal')
            goal = rank_goal(score, goal_level, getattr(self, 'my_matches', None)) if goal_level else None
            if goal and goal['to_go'] > 0:
                b.text(tx + bar_w, y + 162, f"Goal {goal['target']}: {goal['to_go']:,.0f} pts", 12, 'bold', GOLD, anchor='e')
        else:
            b.text(tx, y + 110, 'Unranked this season', 15, 'bold', MUTED)
        # Season numbers on the right.
        overview = profile.get('overview') or {}
        games = overview.get('games', 0) or (ranks[0]['games'] if ranks else 0)
        wins = overview.get('wins', 0) or (ranks[0]['wins'] if ranks else 0)
        tiles = []
        if games:
            tiles.append(('Season', f'{wins}W  {games - wins}L', TEXT))
            tiles.append(('Win rate', f'{wins / games * 100:.0f}%', win_color(f'{wins / games * 100}%')))
        if overview.get('games'):
            k, d, a = overview.get('kills', 0), overview.get('deaths', 0), overview.get('assists', 0)
            kda = (k + a) / max(d, 1)
            tiles.append(('KDA', f'{kda:.1f}', kda_colors(kda)[1]))
            tiles.append(('Time played', hours(overview.get('time', 0)), SOFT))
        recent = [m for m in (getattr(self, 'my_matches', None) or profile.get('matches') or [])][:20]
        if recent:
            mvps = sum(1 for m in recent if m.get('mvp') or m.get('svp'))
            tiles.append(('MVP / SVP', f'{mvps} of {len(recent)}', GOLD if mvps else SOFT))
        tile_w, gap = 124, 10
        cols = max(1, min(len(tiles), int((w * .55 - 20) // (tile_w + gap))))
        tiles = tiles[:cols]
        tx2 = x + w - 22 - cols * (tile_w + gap) + gap
        for label, value, color in tiles:
            b.shape(tx2, y + 55, tile_w, 80, 14, '#14151A', None, CHIP_LINE, 1)
            b.text(tx2 + tile_w / 2, y + 80, label, 12, 'bold', MUTED, anchor='center')
            b.text(tx2 + tile_w / 2, y + 108, value, 20 if len(value) < 9 else 15, color=color, anchor='center', fit=tile_w - 14)
            tx2 += tile_w + gap
        return y + height

    # ---- tonight / rank trend / highlights --------------------------------------------------------
    def _me_cards(self, profile, x, y, w):
        gap = 18
        if w > 900:
            cw = (w - gap * 2) / 3
            spots = [(x, y), (x + cw + gap, y), (x + (cw + gap) * 2, y)]
        else:
            cw = w
            spots = [(x, y), (x, y + 218), (x, y + 436)]
        self._me_tonight(x=spots[0][0], y=spots[0][1], w=cw)
        self._me_trend(profile, spots[1][0], spots[1][1], cw)
        self._me_highlights(profile, spots[2][0], spots[2][1], cw)
        return spots[-1][1] + 200

    def _me_card(self, x, y, w, title):
        b = self.board
        b.shape(x, y, w, 200, 22, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 30, title, 18)

    def _me_tonight(self, x, y, w):
        b = self.board
        self._me_card(x, y, w, 'Tonight')
        run = getattr(self, 'my_session', None)
        if not run:
            b.text(x + 20, y + 74, 'No games in the last few hours.', 13, 'bold', MUTED, fit=w - 40)
            b.text(x + 20, y + 98, 'Your night shows up here as you play.', 13, 'bold', MUTED, fit=w - 40)
            return
        losses = run['games'] - run['wins']
        b.text(x + 20, y + 74, f"{run['wins']}W", 28, color=GREEN_SOFT)
        b.text(x + 20 + b.measure(f"{run['wins']}W", 28) + 12, y + 74, f'{losses}L', 28, color=LOSS_SOFT)
        if run['ranked']:
            sign = '+' if run['points'] > 0 else ''
            b.text(x + w - 20, y + 76, f"{sign}{run['points']:.0f} pts", 18,
                   color=GREEN_SOFT if run['points'] > 0 else LOSS_SOFT if run['points'] < 0 else SOFT, anchor='e')
        games = sorted((m for m in self.my_matches if m.get('when') and m['when'] >= run['started']), key=lambda m: m['when'])[-16:]
        bar = max(6, min(20, (w - 40 - 4 * (len(games) - 1)) / max(1, len(games))))
        for i, game in enumerate(games):
            ranked = game.get('change') is not None
            color = (GREEN_DEEP if ranked else '#2F6B50') if game['won'] else (LOSS if ranked else '#6E3540')
            b.shape(x + 20 + i * (bar + 4), y + 104, bar, 12, 3, color, None, None)
        if run.get('best'):
            b.text(x + 20, y + 140, f"Best hero: {run['best']}", 13, 'bold', SOFT, fit=w - 150)
        bx, by, bw = x + w - 20 - 104, y + 152, 104
        b.shape(bx, by, bw, 32, 16, GOLD_TOP, GOLD_BOTTOM, None, direction='down')
        b.text(bx + bw / 2, by + 16, 'Insights', 13, color=DARK, anchor='center')
        self._page_hit(bx, by, bw, 32, self.open_insights)

    def _me_trend(self, profile, x, y, w):
        """Ranked points over your recent ranked games, as a small line chart."""
        from PIL import Image, ImageDraw
        b = self.board
        self._me_card(x, y, w, 'Rank points')
        games = [m for m in (getattr(self, 'my_matches', None) or profile.get('form') or profile.get('matches') or [])
                 if m.get('score') is not None and m.get('when')]
        games = sorted(games, key=lambda m: m['when'])[-20:]
        if len(games) < 2:
            b.text(x + 20, y + 74, 'Play a few ranked games to see your trend.', 13, 'bold', MUTED, fit=w - 40)
            return
        points = [g['score'] for g in games]
        change = points[-1] - points[0]
        b.text(x + w - 20, y + 32, f"{'+' if change > 0 else ''}{change:,.0f} over {len(games)} games", 12, 'bold',
               GREEN_SOFT if change > 0 else LOSS_SOFT if change < 0 else MUTED, anchor='e')
        cw, ch = w - 40, 110
        z = b.z
        image = Image.new('RGBA', (z(cw), z(ch)), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        low, high = min(points), max(points)
        span = max(30, high - low)
        def at(i, v):
            return (z(4 + (cw - 8) * i / (len(points) - 1)), z(8 + (ch - 22) * (1 - (v - low) / span)))
        line = [at(i, v) for i, v in enumerate(points)]
        # Faint dashed line wherever a new division starts, so rank-ups are easy to spot.
        from scout.stats.extras import score_for_level, level_for_score
        boundaries = []
        for level in range(level_for_score(low) + 1, level_for_score(low + span) + 1):
            edge = score_for_level(level)
            if low < edge <= low + span:
                _, ly = at(0, edge)
                for dx in range(0, z(cw), z(8)):
                    draw.line((dx, ly, dx + z(4), ly), fill=(230, 194, 122, 70), width=max(1, z(1)))
                boundaries.append((level, ly / b.scale))
        draw.polygon(line + [(line[-1][0], z(ch)), (line[0][0], z(ch))], fill=(230, 194, 122, 28))
        draw.line(line, fill=(230, 194, 122, 255), width=max(2, z(2.2)), joint='curve')
        moves = self._trend_moves(games, points)
        for i, ((px, py), game) in enumerate(zip(line, games)):
            if moves.get(i):
                ring = z(7)
                draw.ellipse((px - ring, py - ring, px + ring, py + ring),
                             outline=(230, 194, 122, 255) if moves[i][0] == 'up' else (240, 138, 138, 255), width=max(2, z(1.6)))
            r = z(3.5)
            draw.ellipse((px - r, py - r, px + r, py + r), fill=(94, 211, 156, 255) if game['won'] else (240, 138, 138, 255),
                         outline=(20, 21, 26, 255), width=max(1, z(1)))
        b.place_image(image, x + 20, y + 52)
        from scout.stats.tracker import rank_name
        for level, ly in boundaries:
            b.text(x + 22, y + 52 + ly - 7, rank_name(level), 9, 'extra', GOLD, anchor='w')
        for i, move in moves.items():
            px, py = line[i][0] / b.scale, line[i][1] / b.scale
            badge_y = y + 52 + py - 26 if py > 24 else y + 52 + py + 12
            self._rank_move_badge(x + 20 + px, badge_y, move[0])
        b.text(x + 20, y + 182, f'{points[0]:,.0f}', 11, 'bold', MUTED)
        b.text(x + w / 2, y + 182, 'hover the line or a dot', 11, 'bold', MUTED, anchor='center')
        b.text(x + w - 20, y + 182, f'now {points[-1]:,.0f}', 11, 'bold', SOFT, anchor='e')
        self._trend_tips(profile, games, points, x + 20, y + 52, cw, ch, low, span)

    @staticmethod
    def _trend_moves(games, points):
        """{index: ('up'/'down', before, after)} for games where the rank changed division."""
        from scout.stats.extras import rank_change, level_for_score
        from scout.stats.tracker import rank_name
        moves = {}
        for i, game in enumerate(games):
            moved = rank_change(game) if game.get('change') is not None else None
            if moved is None and i and game.get('change') is None:
                before, after = level_for_score(points[i - 1]), level_for_score(points[i])
                if before != after:
                    moved = ('up' if after > before else 'down', rank_name(before), rank_name(after))
            if moved:
                moves[i] = moved
        return moves

    def _trend_tips(self, profile, games, points, left, top, cw, ch, low, span):
        """Hover a dot: how that game went (click opens it). Hover the line between two dots: the rank
        points going up or down across that game."""
        import time
        from scout.stats.tracker import rank_name
        now = time.time()

        def spot(i, v):
            return left + 4 + (cw - 8) * i / (len(points) - 1), top + 8 + (ch - 22) * (1 - (v - low) / span)

        def rank_at(score):
            try:
                return rank_name(max(1, int((score - 3000) // 100) + 1))
            except Exception:
                return ''
        dot = 9
        for i, (game, v) in enumerate(zip(games, points)):
            px, py = spot(i, v)
            game = dict(game)
            if game.get('change') is None and i:
                game['change'] = v - points[i - 1]
            self._page_tip(px - dot, py - dot, dot * 2, dot * 2, self._game_tip_lines(game, now))
            if game.get('id'):
                self._page_hit(px - dot, py - dot, dot * 2, dot * 2, lambda g=game: self.open_match(profile, g))
        for i in range(1, len(points)):
            (x1, _), (x2, _) = spot(i - 1, points[i - 1]), spot(i, points[i])
            before, after = points[i - 1], points[i]
            change = after - before
            colour = GREEN_SOFT if change > 0 else LOSS_SOFT if change < 0 else MUTED
            arrow = '▲' if change > 0 else '▼' if change < 0 else '■'
            lines = [(f"{before:,.0f}  →  {after:,.0f}", TEXT, 13),
                     (f"{arrow} {'+' if change > 0 else ''}{change:,.0f} rank points  ·  game {i + 1} of {len(points)}", colour, 12)]
            old_rank, new_rank = rank_at(before), rank_at(after)
            if old_rank and new_rank and old_rank != new_rank:
                lines.append((f"{old_rank}  →  {new_rank}", GOLD, 12))
            elif new_rank:
                lines.append((new_rank, MUTED, 11))
            self._page_tip(x1, top, x2 - x1, ch, lines)

    def _me_highlights(self, profile, x, y, w):
        b = self.board
        self._me_card(x, y, w, 'Highlights')
        heroes = [h for h in profile.get('heroes', []) if isinstance(h.get('matches_played'), (int, float)) and h['matches_played'] >= 5]

        def rate(hero):
            try:
                return float(str(hero.get('win_pct', '0')).rstrip('%'))
            except ValueError:
                return 0.0
        rows = []
        if heroes:
            most = max(heroes, key=lambda h: h['matches_played'])
            rows.append(('Most played', most['hero_name'], f"{most['matches_played']:g} games", SOFT))
            best = max(heroes, key=rate)
            rows.append(('Best win rate', best['hero_name'], best.get('win_pct', ''), GREEN_SOFT))
            worst = min(heroes, key=rate)
            if worst is not best and rate(worst) < 50:
                rows.append(('Needs work', worst['hero_name'], worst.get('win_pct', ''), LOSS_SOFT))
        lords = sorted((row for row in profile.get('proficiency') or [] if row.get('level', 0) >= 20), key=lambda r: -r['level'])
        if lords:
            from scout.stats.extras import mastery_badge
            rows.append(('Top mastery', lords[0]['hero'], mastery_badge(lords[0]['level']) or f"Level {lords[0]['level']}", GOLD))
        if not rows:
            b.text(x + 20, y + 74, 'Play 5+ games on a hero to see highlights.', 13, 'bold', MUTED, fit=w - 40)
            return
        ry = y + 54
        for label, hero, value, color in rows[:4]:
            b.avatar(x + 20, ry, 30, '#2A2B33', '#1E1F26', '#3A3B46', 1, picture=hero_picture(hero), initials=initials(hero))
            b.text(x + 60, ry + 8, label, 11, 'bold', MUTED)
            b.text(x + 60, ry + 23, hero, 13, 'extra', TEXT, fit=w - 170)
            b.text(x + w - 20, ry + 16, value, 13, 'extra', color, anchor='e')
            ry += 36
