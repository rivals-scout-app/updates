"""Shared imports and small helpers for the Rivals Scout screens."""
import sys
import time
import tkinter as tk
from pathlib import Path

from scout import paths
from scout.stats.advisor import is_one_trick, team_notes
from scout.stats.tracker import HERO_NAMES, season_label, is_hidden_name, is_unreadable_name, rank_name
from PIL import Image, ImageTk

from scout.ui import paint
from scout.ui.board import paste_rgba
from scout.ui.board import (Board, icon_arrow, icon_bars, icon_close, icon_dots, icon_person, icon_scan, icon_scope,
                             icon_search, icon_sliders, icon_star, icon_trend, typed,
                             icon_minimize, icon_maximize, icon_restore)
from scout.ui.theme import *  # noqa: F401,F403

RAIL = 84  # width of the left navigation rail
HISTORY_CHOICES = [21, 'recent2', 'recent3', 'recent6']  # game scans: recent seasons only (fast, and what matters now)


def hero_picture(name):
    hero_id = next((ident for ident, hero in HERO_NAMES.items() if hero.casefold() == str(name).casefold()), None)
    path = paths.asset('heroes', f'{hero_id}.png') if hero_id else None
    return path if path and path.is_file() else None


def initials(name):
    words = [w for w in str(name).replace('&', ' ').split() if w]
    return (words[0][:1] + (words[1][:1] if len(words) > 1 else words[0][1:2])).upper() if words else '?'


def per_game(hero):
    """Kills, deaths and assists per game, and KDA. None where the site has no count."""
    games = hero.get('_games') or 0
    try:
        games = float(games or hero.get('matches_played') or 0)
    except (TypeError, ValueError):
        games = 0
    values = [hero.get(field) for field in ('kills', 'deaths', 'assists')]
    if not games or any(value is None for value in values):
        return None, None
    kills, deaths, assists = (value / games for value in values)
    return (kills, deaths, assists), (kills + assists) / max(deaths, .01)


def short_number(value):
    """12345 -> 12.3k."""
    if value is None:
        return '-'
    return f'{value / 1000:.1f}k' if value >= 1000 else f'{value:.0f}'


def hours(seconds):
    minutes = int(seconds // 60)
    return f'{minutes // 60}h {minutes % 60}m' if minutes >= 60 else f'{minutes}m'


def ago(seconds):
    if seconds < 3600:
        return f'{max(1, int(seconds // 60))}m ago'
    if seconds < 86400:
        return f'{int(seconds // 3600)}h ago'
    return f'{int(seconds // 86400)}d ago'


def short(name):
    return str(name).partition(' · UID ')[0]
