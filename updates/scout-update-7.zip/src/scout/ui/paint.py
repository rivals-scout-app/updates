"""Draws the soft shapes (cards, pills, bubbles, glows) as see-through images.

Tk can't draw gradients or smooth rounded corners itself, so every shape is
painted here with Pillow at double size and shrunk, which smooths the edges.
Shapes are cached by size and colors, so redrawing the window is cheap.
"""
from functools import lru_cache

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from scout import paths

SUPER = 2  # draw at double size, then shrink: smooth edges


def rgb(color):
    if isinstance(color, tuple):
        return color[:3]
    color = color.lstrip('#')
    return tuple(int(color[i:i + 2], 16) for i in (0, 2, 4))


def rgba(color, alpha=255):
    if isinstance(color, tuple) and len(color) == 4:
        return color
    return (*rgb(color), alpha)


def _gradient(width, height, start, end, direction):
    """A width x height RGBA gradient. direction: 'down', 'right' or 'diagonal'."""
    start = np.array(rgba(start), dtype=np.float32)
    end = np.array(rgba(end), dtype=np.float32)
    if direction == 'right':
        t = np.linspace(0, 1, max(width, 1), dtype=np.float32)[None, :].repeat(height, 0)
    elif direction == 'down':
        t = np.linspace(0, 1, max(height, 1), dtype=np.float32)[:, None].repeat(width, 1)
    else:
        x = np.linspace(0, 1, max(width, 1), dtype=np.float32)[None, :]
        y = np.linspace(0, 1, max(height, 1), dtype=np.float32)[:, None]
        t = (x * .45 + y * .55)
    pixels = start + (end - start) * t[..., None]
    return Image.fromarray(pixels.clip(0, 255).astype(np.uint8), 'RGBA')


@lru_cache(maxsize=512)
def bubble(width, height, radius, top, bottom=None, line=None, line_width=1.5,
           direction='diagonal', glow=None, glow_size=0, shadow=False):
    """A rounded box with a gradient fill, an outline and an optional glow.

    The image is bigger than width x height by `pad` on every side (room for
    the glow), so callers place it at (x - pad, y - pad). Returns (image, pad).
    """
    width, height = max(2, int(width)), max(2, int(height))
    pad = int(glow_size * 2 + (10 if shadow else 0))
    s = SUPER
    full = Image.new('RGBA', ((width + pad * 2) * s, (height + pad * 2) * s), (0, 0, 0, 0))
    box = (pad * s, pad * s, (pad + width) * s - 1, (pad + height) * s - 1)
    if shadow:
        shade = Image.new('RGBA', full.size, (0, 0, 0, 0))
        ImageDraw.Draw(shade).rounded_rectangle((box[0], box[1] + 8 * s, box[2], box[3] + 8 * s), radius * s, fill=(0, 0, 0, 70))
        full = Image.alpha_composite(full, shade.filter(ImageFilter.GaussianBlur(9 * s)))
    if glow and glow_size:
        halo = Image.new('RGBA', full.size, (0, 0, 0, 0))
        ImageDraw.Draw(halo).rounded_rectangle(box, radius * s, fill=rgba(glow[0], glow[1]))
        full = Image.alpha_composite(full, halo.filter(ImageFilter.GaussianBlur(glow_size * s)))
    mask = Image.new('L', full.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle(box, radius * s, fill=255)
    fill = _gradient(width * s, height * s, top, bottom or top, direction)
    layer = Image.new('RGBA', full.size, (0, 0, 0, 0))
    layer.paste(fill, (pad * s, pad * s))
    layer.putalpha(Image.fromarray(np.minimum(np.asarray(layer.getchannel('A')), np.asarray(mask))))
    full = Image.alpha_composite(full, layer)
    if line:
        edge = Image.new('RGBA', full.size, (0, 0, 0, 0))
        ImageDraw.Draw(edge).rounded_rectangle(box, radius * s, outline=rgba(line), width=max(1, round(line_width * s)))
        full = Image.alpha_composite(full, edge)
    return full.resize((width + pad * 2, height + pad * 2), Image.Resampling.LANCZOS), pad


@lru_cache(maxsize=8)
def backdrop(width, height, base, glow_a, glow_b):
    """The window ground: dark navy with a purple glow top-left and pink bottom-right."""
    width, height = max(2, int(width)), max(2, int(height))
    y, x = np.mgrid[0:height, 0:width].astype(np.float32)
    image = np.zeros((height, width, 3), np.float32) + np.array(rgb(base), np.float32)
    reach = max(width, height)
    for (cx, cy), color, size in (((width * .12, 0), glow_a, .42), ((width, height), glow_b, .40)):
        distance = np.sqrt((x - cx) ** 2 + (y - cy) ** 2) / (reach * size)
        strength = np.clip(1 - distance, 0, 1) ** 1.6
        image = image + (np.array(color, np.float32) - image) * strength[..., None]
    return Image.fromarray(image.clip(0, 255).astype(np.uint8), 'RGB')


@lru_cache(maxsize=256)
def avatar(size, top, bottom, ring, ring_width=3, glow=None, picture_path=None, initials=''):
    """A round bubble: hero art (or initials) inside a colored ring with a soft glow.

    Returns (image, pad) like bubble(); initials are drawn by the caller as text.
    """
    size = max(8, int(size))
    pad = 10 if glow else 0
    s = SUPER
    total = (size + pad * 2) * s
    out = Image.new('RGBA', (total, total), (0, 0, 0, 0))
    circle = (pad * s, pad * s, (pad + size) * s - 1, (pad + size) * s - 1)
    if glow:
        halo = Image.new('RGBA', out.size, (0, 0, 0, 0))
        ImageDraw.Draw(halo).ellipse(circle, fill=rgba(glow[0], glow[1]))
        out = Image.alpha_composite(out, halo.filter(ImageFilter.GaussianBlur(7 * s)))
    mask = Image.new('L', out.size, 0)
    ImageDraw.Draw(mask).ellipse(circle, fill=255)
    inside = Image.new('RGBA', out.size, (0, 0, 0, 0))
    inside.paste(_gradient(size * s, size * s, top, bottom, 'diagonal'), (pad * s, pad * s))
    if picture_path:
        try:
            with Image.open(picture_path) as art:
                art = art.convert('RGBA')
                side = min(art.size)
                # Hero art is a bust; keep the face (upper middle) in the circle.
                left = (art.width - side) // 2
                art = art.crop((left, 0, left + side, side)).resize((size * s, size * s), Image.Resampling.LANCZOS)
            inside.alpha_composite(art, (pad * s, pad * s))
        except (OSError, ValueError):
            pass
    inside.putalpha(Image.fromarray(np.minimum(np.asarray(inside.getchannel('A')), np.asarray(mask))))
    out = Image.alpha_composite(out, inside)
    edge = Image.new('RGBA', out.size, (0, 0, 0, 0))
    ImageDraw.Draw(edge).ellipse(circle, outline=rgba(ring), width=max(1, round(ring_width * s)))
    out = Image.alpha_composite(out, edge)
    return out.resize((size + pad * 2, size + pad * 2), Image.Resampling.LANCZOS), pad


@lru_cache(maxsize=64)
def dot(size, color, glow=True):
    pad = 6 if glow else 0
    s = SUPER
    total = (size + pad * 2) * s
    out = Image.new('RGBA', (total, total), (0, 0, 0, 0))
    circle = (pad * s, pad * s, (pad + size) * s - 1, (pad + size) * s - 1)
    if glow:
        halo = Image.new('RGBA', out.size, (0, 0, 0, 0))
        ImageDraw.Draw(halo).ellipse(circle, fill=rgba(color, 200))
        out = Image.alpha_composite(out, halo.filter(ImageFilter.GaussianBlur(4 * s)))
    ImageDraw.Draw(out).ellipse(circle, fill=rgba(color))
    return out.resize((size + pad * 2, size + pad * 2), Image.Resampling.LANCZOS), pad


def rounded_picture(path, width, height, radius, line=None):
    """A screenshot or name picture with rounded corners and an outline (cached until the file changes)."""
    import os
    return _rounded_picture(str(path), os.path.getmtime(path), int(width), int(height), int(radius), line)


@lru_cache(maxsize=32)
def _rounded_picture(path, _mtime, width, height, radius, line):
    s = SUPER
    with Image.open(path) as source:
        picture = source.convert('RGBA')
    picture = picture.resize((width * s, height * s), Image.Resampling.LANCZOS)
    mask = Image.new('L', picture.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, width * s - 1, height * s - 1), radius * s, fill=255)
    picture.putalpha(mask)
    if line:
        ImageDraw.Draw(picture).rounded_rectangle((0, 0, width * s - 1, height * s - 1), radius * s, outline=rgba(line), width=2 * s)
    return picture.resize((width, height), Image.Resampling.LANCZOS)


FONT_FILES = {'black': 'ScoutInter-Bold.otf', 'extra': 'ScoutInter-SemiBold.otf', 'bold': 'ScoutInter-Medium.otf'}


@lru_cache(maxsize=64)
def font(size, weight='black'):
    path = paths.asset('fonts', FONT_FILES.get(weight, FONT_FILES['black']))
    try:
        return ImageFont.truetype(str(path), max(6, int(size)))
    except OSError:
        for fallback in ('segoeuib.ttf', 'arialbd.ttf', 'DejaVuSans-Bold.ttf'):
            try:
                return ImageFont.truetype(fallback, max(6, int(size)))
            except OSError:
                continue
        return ImageFont.load_default()


@lru_cache(maxsize=4096)
def text_width(text, size, weight='black'):
    return font(size, weight).getlength(text)


@lru_cache(maxsize=2048)
def text_image(text, size, weight='black', color='#FFFFFF', justify='left'):
    """Text as a see-through image, one line box tall per line."""
    face = font(size, weight)
    ascent, descent = face.getmetrics()
    line_height = ascent + descent
    lines = text.split('\n') or ['']
    width = max(1, int(max(face.getlength(line) for line in lines)) + 2)
    image = Image.new('RGBA', (width, line_height * len(lines)), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    for index, line in enumerate(lines):
        offset = 0
        if justify == 'center':
            offset = (width - face.getlength(line)) / 2
        elif justify == 'right':
            offset = width - face.getlength(line)
        draw.text((offset, index * line_height), line, font=face, fill=rgba(color))
    return image


# Rank emblem colours (our own simple badge, not the game's artwork).
RANK_COLORS = {
    'Bronze': ('#E3A06A', '#9A5A2E'), 'Silver': ('#EEF2F8', '#9AA6B8'), 'Gold': ('#FFE27A', '#E0A42A'),
    'Platinum': ('#9FF2E6', '#2FB3A3'), 'Diamond': ('#BFD8FF', '#4E86F0'), 'Grandmaster': ('#D9C2FF', '#8A5CF0'),
    'Celestial': ('#FFC7DC', '#F0659C'), 'Eternity': ('#FFB0A0', '#E2453B'), 'One Above All': ('#FFF4C2', '#F5B53A'),
}


@lru_cache(maxsize=128)
def rank_icon(tier, division, size):
    """A small shield badge for a rank tier; `division` (1-3, or 0 for none) shows as pips."""
    top, bottom = RANK_COLORS.get(tier, ('#C9CCE8', '#7A7FA8'))
    scale = 4
    big = size * scale
    shape = Image.new('L', (big, big), 0)
    draw = ImageDraw.Draw(shape)
    w = big
    points = [(w * .5, w * .04), (w * .92, w * .2), (w * .86, w * .62), (w * .5, w * .96), (w * .14, w * .62), (w * .08, w * .2)]
    draw.polygon(points, fill=255)
    fill = _gradient(big, big, top, bottom, 'down')
    badge = Image.new('RGBA', (big, big), (0, 0, 0, 0))
    badge.paste(fill, (0, 0), shape)
    # Dark outline and a light inner shine.
    edge = ImageDraw.Draw(badge)
    edge.line(points + [points[0]], fill=(20, 22, 43, 230), width=max(2, big // 14), joint='curve')
    inner = [(x * .62 + w * .19, y * .62 + w * .17) for x, y in points]
    edge.polygon(inner, outline=(255, 255, 255, 120))
    # Division pips: III = three, I = one.
    pips = {3: 1, 2: 2, 1: 3}.get(division, 0)
    r = big * .07
    for index in range(pips):
        cx = w * .5 + (index - (pips - 1) / 2) * r * 2.6
        cy = w * .5
        edge.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(20, 22, 43, 235))
    return badge.resize((size, size), Image.LANCZOS)


RANK_SLUGS = {'Bronze': 'bronze', 'Silver': 'silver', 'Gold': 'gold', 'Platinum': 'platinum', 'Diamond': 'diamond',
              'Grandmaster': 'grandmaster', 'Celestial': 'celestial', 'Eternity': 'eternity', 'One Above All': 'one-above-all'}


def rank_picture_path(tier):
    slug = RANK_SLUGS.get(tier)
    return paths.CACHE / 'ranks' / f'{slug}.webp' if slug else None


@lru_cache(maxsize=64)
def _rank_picture(path, _mtime, size):
    with Image.open(path) as image:
        image = image.convert('RGBA')
        # The downloaded art has a wide empty margin; trim to the emblem so it fills its spot.
        solid = image.getchannel('A').point(lambda a: 255 if a > 60 else 0).getbbox()
        if solid:
            image = image.crop(solid)
        image.thumbnail((size, size), Image.LANCZOS)
        canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        canvas.paste(image, ((size - image.width) // 2, (size - image.height) // 2), image)
        return canvas


def rank_picture(tier, size):
    """The real rank emblem (downloaded once from RivalsData into data/cache/ranks), or None if not there yet."""
    path = rank_picture_path(tier)
    try:
        if path and path.is_file():
            return _rank_picture(str(path), path.stat().st_mtime, size)
    except (OSError, ValueError):
        return None
    return None


@lru_cache(maxsize=8)
def logo(size):
    """The Rivals Scout logo (assets/logo.png) at size x size pixels, or None if it's missing."""
    path = paths.asset('logo.png')
    try:
        return Image.open(path).convert('RGBA').resize((int(size), int(size)), Image.Resampling.LANCZOS)
    except OSError:
        return None


def rank_emblem(tier, division, size):
    """The rank emblem with its division (III, II or I) in a small badge at the bottom right.
    The game uses one emblem per tier, so the number is added here. None if the emblem isn't downloaded yet."""
    path = rank_picture_path(tier)
    try:
        stamp = path.stat().st_mtime if path and path.is_file() else None
    except OSError:
        stamp = None
    return _rank_emblem(tier, division, size, stamp) if stamp else None


@lru_cache(maxsize=128)
def _rank_emblem(tier, division, size, _stamp):
    picture = rank_picture(tier, size)
    if picture is None:
        return None
    if not division:
        return picture
    picture = picture.copy()
    label = {3: 'III', 2: 'II', 1: 'I'}.get(int(division), '')
    if not label:
        return picture
    text_size = max(7, int(size * .2))
    face = font(text_size, 'black')
    width = int(text_size * .62 * len(label) + text_size * .7)
    height = int(text_size * 1.25)
    badge = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(badge)
    draw.rounded_rectangle((0, 0, width - 1, height - 1), radius=height // 2, fill=(12, 13, 17, 235),
                           outline=RANK_COLORS.get(tier, ('#B9BAC4',))[0], width=max(1, size // 32))
    draw.text((width / 2, height / 2), label, font=face, fill=RANK_COLORS.get(tier, ('#F3F3F6',))[0], anchor='mm')
    picture.alpha_composite(badge, (size - width, size - height))
    return picture


@lru_cache(maxsize=32)
def mastery_frame(size, champion=False):
    """A frame drawn over a round player picture when they have Lord (gold ring + crown) or Champion
    (red-to-gold ring, glow, winged crown) on that hero. Scout's own drawing, laid over avatar() output.
    Returns (image, pad): place at (x - pad, y - pad) like avatar()."""
    size = max(16, int(size))
    s = SUPER
    pad = int(size * .32)
    total = (size + pad * 2) * s
    out = Image.new('RGBA', (total, total), (0, 0, 0, 0))
    c = total / 2
    r = size * s / 2
    ring = max(2, int(size * .07)) * s
    if champion:
        glow = Image.new('RGBA', out.size, (0, 0, 0, 0))
        ImageDraw.Draw(glow).ellipse((c - r - ring, c - r - ring, c + r + ring, c + r + ring), outline=(255, 90, 54, 170), width=ring * 2)
        out = Image.alpha_composite(out, glow.filter(ImageFilter.GaussianBlur(5 * s)))
    # The ring itself: a gradient clipped to an annulus.
    colors = ((255, 120, 70), (241, 212, 151)) if champion else ((255, 241, 201), (176, 125, 46))
    grad = _gradient(total, total, colors[0], colors[1], 'down')
    mask = Image.new('L', out.size, 0)
    md = ImageDraw.Draw(mask)
    md.ellipse((c - r - ring / 2, c - r - ring / 2, c + r + ring / 2, c + r + ring / 2), fill=255)
    md.ellipse((c - r + ring / 2, c - r + ring / 2, c + r - ring / 2, c + r - ring / 2), fill=0)
    grad.putalpha(mask)
    out = Image.alpha_composite(out, grad)
    # Crown on top.
    draw = ImageDraw.Draw(out)
    cw = size * s * (.62 if champion else .5)
    ch = cw * .55
    top = c - r - ring / 2 - ch * .72
    left = c - cw / 2
    crown = [(left, top + ch), (left, top + ch * .25), (left + cw * .25, top + ch * .6), (c, top),
             (left + cw * .75, top + ch * .6), (left + cw, top + ch * .25), (left + cw, top + ch)]
    fill = (255, 214, 120) if champion else (241, 212, 151)
    edge = (60, 30, 10)
    draw.polygon(crown, fill=fill, outline=edge)
    gem = (255, 77, 58) if champion else (255, 241, 201)
    gr = cw * .07
    draw.ellipse((c - gr, top + ch * .55 - gr, c + gr, top + ch * .55 + gr), fill=gem)
    if champion:
        # Small wings either side of the crown.
        for side in (-1, 1):
            base = c + side * cw * .46
            wing = [(base, top + ch * .95), (base + side * cw * .34, top + ch * .15), (base + side * cw * .24, top + ch * .6),
                    (base + side * cw * .4, top + ch * .5), (base + side * cw * .16, top + ch * 1.0)]
            draw.polygon(wing, fill=(255, 150, 90), outline=edge)
    return out.resize((size + pad * 2, size + pad * 2), Image.Resampling.LANCZOS), pad
