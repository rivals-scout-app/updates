"""The home screen: first-run setup, "ready when you are", and the Tonight / Rank goal / Favorites cards."""
from scout.ui.common import *  # noqa: F401,F403


class HomeViews:
    # ---- waiting screen -----------------------------------------------------------
    def _draw_waiting(self, x1, y1, x2, y2):
        b = self.board
        w, h = x2 - x1, y2 - y1
        info = self._waiting_info_cards()
        if info and h > 560:
            row_h = 190
            self._draw_info_row(info, x1, y2 - row_h, w, row_h)
            y2 -= row_h + 18
            h = y2 - y1
        b.shape(x1, y1, w, h, 32, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        cx, cy = x1 + w / 2, y1 + h / 2 - 40 + (0 if not info or h > 520 else 30)
        picture = paint.logo(b.z(132))
        if picture is not None:
            b.place_image(picture, cx - 66, cy - 150)
        else:
            b.avatar(cx - 74, cy - 150, 148, '#262730', '#1B1C23', RAISED_LINE, 2, glow=(GOLD, 60))
            b.avatar(cx - 50, cy - 126, 100, GOLD_TOP, GOLD_BOTTOM, '#F6E2B4', 3)
            icon_scope(b, cx, cy - 76, DARK, (), size=2.1)
        b.text(cx, cy + 34, 'Ready when you are', 38, anchor='center')
        b.text(cx, cy + 88, 'Queue up a competitive match and Scout reads the loading screen by itself.\nGot a screenshot instead? Paste it here with Ctrl+V.',
               18, 'bold', MUTED, anchor='center', justify='center')
        labels = [(f'Scan now · {self.hotkey_name}', lambda: self.capture(3000), 'gold'),
                  ('Open a screenshot', self.open_image, 'raised'), ('Type names', self.show_tools, 'raised')]
        widths = [b.measure(text, 17) + 52 + (26 if style == 'gold' else 0) for text, _, style in labels]
        x = cx - (sum(widths) + 12 * (len(widths) - 1)) / 2
        for (text, command, style), width in zip(labels, widths):
            b.button(x, cy + 134, text, command, style, 52, 17, icon=icon_scan if style == 'gold' else None,
                     width=width, disabled=self.busy and style == 'gold', glow=True)
            x += width + 12

    def _draw_setup(self, x1, y1, x2, y2):
        """First run: which account is yours (by UID, or by searching your name)."""
        b = self.board
        w, h = x2 - x1, y2 - y1
        b.shape(x1, y1, w, h, 32, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        cw = min(760, w - 80)
        x = x1 + (w - cw) / 2
        y = y1 + max(30, (h - 560) / 2)
        b.text(x, y + 20, 'Set up your personal tracker', 32)
        b.text(x, y + 62, "Tell Scout which account is yours and it will track your games tonight, your rank goal,\n"
                          "your best picks, and fill in the lobby when you're in a match.", 15, 'bold', SOFT, anchor='nw',
               width=cw)
        # Why it's safe.
        b.shape(x, y + 116, cw, 86, 20, (46, 140, 104, 60), None, GREEN_DEEP, 1)
        b.text(x + 18, y + 130, "Don't worry, this is safe. Your UID is public: anyone can see it on your in-game profile\n"
                                "and on stats sites. Scout only reads your public stats with it. No password, no login, and\n"
                                "nothing on your account can be changed with it.", 13, 'bold', GREEN_SOFT, anchor='nw', width=cw - 36)
        state = self.setup_state or {}
        # 1. UID
        b.text(x, y + 230, 'Your UID', 18)
        b.text(x + 92, y + 231, "(it's in the bottom-left corner of the loading screen, and on your in-game profile)", 12, 'bold',
               MUTED, fit=cw - 92)
        uid_box = b.entry('setup-uid', x, y + 248, cw - 170, 46, on_enter=lambda: self.setup_use_uid(typed(uid_box)),
                          placeholder='e.g. 100000000')
        b.button(x + cw - 155, y + 251, 'Use this UID', lambda: self.setup_use_uid(typed(uid_box)), 'gold', 40, 15, width=155)
        # 2. Name search
        b.text(x, y + 328, "Don't know your UID? Search your username instead", 18)
        name_box = b.entry('setup-name', x, y + 346, cw - 170, 46, on_enter=lambda: self.setup_search(typed(name_box)),
                           placeholder='Your in-game name')
        b.button(x + cw - 155, y + 349, 'Find me', lambda: self.setup_search(typed(name_box)), 'raised', 40, 15, width=155)
        ry = y + 412
        if state.get('state') == 'checking':
            b.text(x, ry + 14, state.get('message', ''), 15, 'bold', MUTED)
        elif state.get('state') == 'error':
            b.text(x, ry + 14, state.get('message', ''), 15, 'bold', WARN_TEXT, fit=cw)
        elif state.get('state') == 'results':
            results = state.get('results') or []
            b.text(x, ry + 10, 'Is this you?' if len(results) == 1 else f'{len(results)} players found. Pick yours:', 15, 'extra', SOFT)
            ry += 28
            for player in results[:4]:
                b.shape(x, ry, cw, 46, 16, ROW_LEFT, ROW_RIGHT, CHIP_LINE, 1, 'right')
                tint = tint_for(player['name'])
                b.avatar(x + 8, ry + 6, 34, tint[0], tint[1], tint[2], 2, initials=initials(player['name']))
                level = f"  ·  level {player['level']}" if player.get('level') else ''
                b.text(x + 52, ry + 23, player['name'], 16, fit=cw * .45)
                b.text(x + 52 + min(cw * .45, b.measure(player['name'], 16)) + 12, ry + 24, f"UID {player['uid']}{level}", 12,
                       'bold', MUTED)
                b.button(x + cw - 128, ry + 5, "That's me", lambda player=player: self.setup_pick(player), 'gold', 36, 14, width=118)
                ry += 52
        b.button(x + cw / 2 - 70, y2 - 64, 'Skip for now', self.setup_skip, 'quiet', 36, 14, width=140)

    def _waiting_info_cards(self):
        cards = []
        if self.me():
            cards += ['session', 'goal']
        if self.settings.get('favorites'):
            cards.append('favorites')
        return cards

    def _draw_info_row(self, cards, x, y, w, h):
        gap = 18
        card_w = (w - gap * (len(cards) - 1)) / len(cards)
        for index, card in enumerate(cards):
            cx = x + index * (card_w + gap)
            {'session': self._card_session, 'goal': self._card_goal, 'favorites': self._card_favorites}[card](cx, y, card_w, h)

    def _card_session(self, x, y, w, h):
        b = self.board
        b.shape(x, y, w, h, 26, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Tonight', 20)
        me = self.me()
        b.text(x + w - 20, y + 33, short(me.get('name') or ''), 12, 'bold', MUTED, anchor='e')
        run = self.my_session
        if not run:
            b.text(x + 20, y + 80, 'No games in the last few hours yet.' if self.my_matches else 'Loading your games…',
                   14, 'bold', MUTED, fit=w - 40)
            return
        rate = run['wins'] / run['games'] * 100
        wins_text = f"{run['wins']}W"
        b.text(x + 20, y + 78, wins_text, 30, color=GREEN_SOFT)
        b.text(x + 20 + b.measure(wins_text, 30) + 14, y + 78, f"{run['games'] - run['wins']}L", 30, color=LOSS_SOFT)
        if run['ranked']:
            sign = '+' if run['points'] > 0 else ''
            b.text(x + w - 20, y + 80, f"{sign}{run['points']:.0f} pts", 22, color=GREEN_SOFT if run['points'] > 0 else RED if run['points'] < 0 else SOFT,
                   anchor='e')
        games = sorted((m for m in self.my_matches if m.get('when') and m['when'] >= run['started']), key=lambda m: m['when'])
        # Tonight as a strip of bars, oldest to newest: green win, red loss; Quick Play games are dimmer.
        games = games[-20:]
        gap = 4
        bar = max(6, min(22, (w - 40 - gap * (len(games) - 1)) / max(1, len(games))))
        for index, game in enumerate(games):
            ranked = game.get('change') is not None
            if game['won']:
                color = GREEN_DEEP if ranked else '#2F6B50'
            else:
                color = LOSS if ranked else '#6E3540'
            b.shape(x + 20 + index * (bar + gap), y + 104, bar, 14, 4, color, None, None)
        from scout.stats.extras import tilt_note
        tilt = tilt_note(self.my_matches)
        if tilt:
            b.text(x + 20, y + 150, tilt, 13, 'bold', GOLD, fit=w - 170)
        elif run['best']:
            b.text(x + 20, y + 150, f"Best hero tonight: {run['best']}", 13, 'bold', SOFT, fit=w - 170)
        b.button(x + w - 150, y + 134, 'See insights', self.open_insights, 'gold', 34, 13, width=130)

    def _card_goal(self, x, y, w, h):
        from scout.stats.extras import rank_goal
        from scout.stats.tracker import RANKS
        b = self.board
        b.shape(x, y, w, h, 26, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Rank goal', 20)
        now = self.my_now or {}
        target = int(self.settings.get('rank_goal') or min(len(RANKS), (now.get('level') or 9) + 3))
        tag = 'goal-pick'
        pill = b.measure(RANKS[target - 1] + '  · change', 13) + 24
        b.shape(x + w - 20 - pill, y + 18, pill, 28, 14, RAISED_TOP, RAISED_BOTTOM, CHIP_LINE, 1, tags=(tag,))
        b.text(x + w - 20 - pill / 2, y + 32, RANKS[target - 1] + '  · change', 13, anchor='center', tags=(tag,))
        b.clickable(tag, self.show_goal_menu)
        if not now.get('score'):
            b.text(x + 20, y + 80, 'Loading your rank…', 14, 'bold', MUTED)
            return
        b.text(x + 20, y + 72, f"Now: {now.get('rank') or '-'} · {now['score']:,.0f} pts", 15, 'extra', SOFT, fit=w - 40)
        goal = rank_goal(now['score'], target, self.my_matches)
        if goal['to_go'] <= 0:
            b.text(x + 20, y + 112, f"You're already there.", 22, color=GREEN_SOFT)
            return
        b.text(x + 20, y + 112, f"{goal['to_go']:,.0f} pts to go", 24, color=GOLD)
        b.text(x + 20, y + 146, f"About {goal['wins']:.0f} more wins than losses at +{goal['per_win']:.0f} a win",
               13, 'bold', MUTED, fit=w - 40)
        start = max(3000, now['score'] - 300)
        span = max(1, (now['score'] + goal['to_go']) - start)
        b.shape(x + 20, y + 168, w - 40, 8, 4, (20, 22, 43, 160), None, None)
        b.shape(x + 20, y + 168, max(8, (w - 40) * (now['score'] - start) / span), 8, 4, GOLD_TOP, GOLD_BOTTOM, None, direction='right')

    def show_goal_menu(self):
        from scout.stats.tracker import RANKS
        from scout.ui import popup
        goal = self.settings.get('rank_goal')
        rows = [popup.header('Rank goal')]
        now = int((getattr(self, 'my_now', None) or {}).get('level') or 0)
        first = max(1, min(now + 1, len(RANKS) - 9))  # the next ten ranks above where you are now
        for level in range(first, min(len(RANKS), first + 9) + 1):
            rows.append(popup.choice(RANKS[level - 1], level == goal, lambda level=level: self.set_rank_goal(level)))
        self._open_popup(rows, width=220)

    def _card_favorites(self, x, y, w, h):
        b = self.board
        b.shape(x, y, w, h, 26, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Favorites', 20)
        now = time.time()
        ry = y + 54
        for fav in (self.settings.get('favorites') or [])[:4]:
            game = self.favorite_games.get(fav.get('uid'))
            b.text(x + 20, ry + 14, short(fav.get('name') or fav.get('uid')), 14, 'extra', TEXT, fit=w * .45)
            if game:
                result = 'W' if game['won'] else 'L'
                text = f"{result} · {game['hero'] or '?'} · {ago(now - game['when'])}" if game.get('when') else result
                b.text(x + w - 20, ry + 14, text, 12, 'bold', GREEN_SOFT if game['won'] else '#F08A8A', anchor='e', fit=w * .5)
            self._click_area(x + 10, ry, w - 20, 28, lambda fav=fav: self.open_player(fav.get('name'), fav.get('uid')))
            ry += 32
