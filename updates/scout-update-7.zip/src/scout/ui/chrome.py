"""The frame around every screen: render(), the top bar, the navigation rail, the status line,
the settings menu, mini bans and the screenshot viewer."""
from scout.ui.common import *  # noqa: F401,F403


class ChromeViews:
    # ---- setup ----------------------------------------------------------------
    def _build(self):
        self.view_canvas = tk.Canvas(self.root, highlightthickness=0, borderwidth=0, bg=BG)
        self.view_canvas.pack(fill='both', expand=True)
        self.board = Board(self.view_canvas, self.ui_scale)
        self._render_job = None
        self.view_canvas.bind('<Configure>', lambda e: self.request_render())
        self.status.trace_add('write', lambda *_: self._draw_status())
        self.root.bind_all('<MouseWheel>', self._scroll_page)
        self.root.bind_all('<Button-4>', self._scroll_page)
        self.root.bind_all('<Button-5>', self._scroll_page)

    def request_render(self):
        """Redraw soon (several changes in a row cause one redraw)."""
        if self._render_job is None and not self.closed.is_set():
            self._render_job = self.root.after(30, self.render)

    def render(self):
        self._render_job = None
        if self.closed.is_set():
            return
        board = self.board
        width, height = self.view_canvas.winfo_width(), self.view_canvas.winfo_height()
        if width < 50 or height < 50:
            # Not on screen yet (or hidden): lay out for the size the window will open at.
            width, height = self.planned_size
        width, height = width / board.scale, height / board.scale
        self._width = width
        board.begin()
        ground = paint.backdrop(board.z(width), board.z(height), BG, GLOW_PURPLE, GLOW_PINK)
        board.place_image(ground, 0, 0)
        body = (RAIL + 24, 88, width - 28, height - 56)
        if getattr(self, 'search_view', None):
            self._draw_player_page(body[0], body[1], body[2] - body[0], body[3] - body[1], ground)
            self._scan_in_bar = False
        elif self._waiting() and self.needs_setup():
            self._draw_setup(*body)
        elif self._waiting():
            self._draw_waiting(*body)
        else:
            left_width = min(410, max(330, (body[2] - body[0]) * .3))
            self._draw_left(body[0], body[1], left_width, body[3] - body[1])
            self._draw_enemies(body[0] + left_width + 20, body[1], body[2] - body[0] - left_width - 20, body[3] - body[1])
        self._draw_rail(height)
        self._draw_top_bar(width)
        self._status_y = height - 30
        self._bar_room = 0
        if getattr(self, '_scan_in_bar', False) and not self._waiting() and self.scan_file and Path(self.scan_file).is_file():
            # No room for the scan card: a small button on the bottom bar opens the screenshot instead.
            hint = self.hotkey_hint.get()
            right = width - 28 - (self.board.measure(hint, 12, 'bold') + 16 if hint else 0)
            label = f'View scan · {self.scan_time}'.strip(' ·')
            button_w = self.board.measure(label, 13) + 30
            self.board.button(right - button_w, height - 46, label, self.open_scan_file, 'raised', 32, 13, width=button_w)
            self._bar_room = button_w + 16
        self._draw_status()
        if getattr(self, 'frameless', False) and not getattr(self, '_restore_geometry', None):
            board.canvas.create_rectangle(0, 0, board.z(width) - 1, board.z(height) - 1, outline='#2A2B34', width=1)
        if getattr(self, 'viewing', None) is not None:
            self._draw_viewer(width, height)
        board.finish()
        self._render_mini()

    def _waiting(self):
        return not self.enemy_names() and not self.results_by_name and not self.errors_by_name

    def enemy_names(self):
        return [entry.get().strip() for entry in self.entries if entry.get().strip()]

    # ---- top bar ----------------------------------------------------------------
    def _draw_top_bar(self, width):
        b = self.board
        title = self._page_title()
        title_x = RAIL + 24
        title_w = b.measure(title, 24)
        b.text(title_x, 46, title, 24, fit=260)
        title_w = min(title_w, 260)
        right = width - 28
        if getattr(self, 'frameless', False):
            right = self._draw_window_buttons(width) - 14
        busy = self.busy
        scan_label = 'Working…' if busy else f'Scan now · {self.hotkey_name}'
        scan_w = b.measure(scan_label, 16) + 26 + 48
        right -= scan_w
        b.button(right, 22, scan_label, lambda: self.capture(3000), 'gold', 48, 16, icon=None if busy else icon_scan,
                 disabled=busy, glow=True)
        auto_label = 'Auto-scan on' if self.auto_scan.get() else 'Auto-scan off'
        auto_w = b.measure(auto_label, 15, 'extra') + 42 + 10 + 28
        right -= 14 + auto_w
        if getattr(self, 'update_info', None):
            label = 'Update ready'
            update_w = b.measure(label, 15) + 26 + 44
            right_update_left = right - 14 - update_w
            green_dot = lambda board, cx, cy, ink, tags: board.dot(cx - 5, cy - 5, 10, GREEN, tags=tags)
            b.button(right_update_left, 22, label, self.install_update, 'quiet', 48, 15, width=update_w, icon=green_dot)
        else:
            right_update_left = None
        tag = 'auto-toggle'
        b.shape(right, 22, auto_w, 48, 24, '#15161B', None, CARD_LINE, tags=(tag,))
        on = self.auto_scan.get()
        b.shape(right + 10, 33, 42, 26, 13, GREEN_DEEP if on else '#2A2B34', GREEN_SOFT if on else '#2A2B34',
                None, direction='right', glow=(GREEN, 110) if on else None, glow_size=6 if on else 0, tags=(tag,))
        knob_x = right + 10 + (19 if on else 3)
        b.avatar(knob_x, 36, 20, '#FFFFFF', '#D8D9E0', '#FFFFFF', 0.5, tags=(tag,))
        b.text(right + 62, 46, auto_label, 15, 'extra', TEXT, tags=(tag,))
        b.clickable(tag, self.toggle_auto_scan)
        # Search one player by name.
        left = title_x + title_w + 28
        search_w = (right_update_left if right_update_left is not None else right) - 14 - left
        if search_w > 220:
            b.shape(left, 22, search_w, 48, 24, '#121318', None, CARD_LINE)
            icon_search(b, left + 24, 46, MUTED, ())
            button_w = b.measure('Search', 14) + 34
            b.button(left + search_w - button_w - 6, 28, 'Search', self.search_player, 'raised', 36, 14, width=button_w)
            self.search_entry = b.entry('search', left + 44, 22, search_w - button_w - 60, 48, on_enter=self.search_player,
                                        background='#121318', size=16, placeholder='Search any player by name')

    # ---- navigation rail ------------------------------------------------------------
    def _section(self):
        """Which rail item the current screen belongs to."""
        view = getattr(self, 'search_view', None)
        if not view:
            return 'scan'
        kind, value = view
        if kind == 'meta':
            return 'meta'
        if kind == 'insights' or (kind == 'match' and (value.get('back') or ('',))[0] == 'insights'):
            return 'tonight'
        me = self.me() if hasattr(self, 'me') else None
        profile = value if kind == 'profile' else value.get('profile') if isinstance(value, dict) else None
        if me and isinstance(profile, dict) and str(profile.get('uid')) == me.get('uid'):
            return 'me'
        return 'players'

    def _page_title(self):
        view = getattr(self, 'search_view', None)
        section = self._section()
        if section == 'scan':
            return 'Match scout' if not self._waiting() else 'Home'
        if section == 'players' and view:
            kind, value = view
            if kind == 'profile':
                return short(value.get('username', 'Player'))
            if kind == 'loading':
                return short(str(value))
            if kind == 'match':
                return 'Match'
            return 'Player'
        return {'me': 'My stats', 'tonight': 'Tonight', 'meta': 'Hero meta'}[section]

    def _draw_rail(self, height):
        b = self.board
        b.shape(0, 0, RAIL, height, 0, '#0E0F13', '#0B0C10', None)
        b.canvas.create_line(b.z(RAIL), 0, b.z(RAIL), b.z(height), fill=CARD_LINE, width=1)
        picture = paint.logo(b.z(48))
        if picture is not None:
            b.place_image(picture, RAIL / 2 - 24, 22)
        else:
            b.avatar(RAIL / 2 - 22, 24, 44, GOLD_TOP, GOLD_BOTTOM, GOLD_LINE, 1, glow=(GOLD_BOTTOM, 70))
            icon_scope(b, RAIL / 2, 46, DARK, ())
        current = self._section()
        items = [('scan', 'Scout', icon_scope, self.nav_scan), ('me', 'Me', icon_person, self.nav_me),
                 ('tonight', 'Tonight', icon_trend, self.nav_tonight), ('meta', 'Meta', icon_bars, self.nav_meta),
                 ('players', 'Players', icon_star, self.nav_players)]
        y = 104
        for key, label, icon, command in items:
            self._rail_item(y, key, label, icon, command, key == current)
            y += 70
        self._rail_item(height - 96, 'settings', 'Settings', icon_sliders, self.show_menu, False)
        from scout import version
        b.text(RAIL / 2, height - 18, version.label(), 10, 'bold', '#55566A', anchor='center')

    def _rail_item(self, y, key, label, icon, command, active):
        b = self.board
        tag = f'rail-{key}'
        if active:
            b.shape(10, y, RAIL - 20, 60, 12, '#1D1E25', '#17181E', CARD_LINE, 1, tags=(tag,))
            b.shape(0, y + 18, 3, 24, 1.5, GOLD, None, None, tags=(tag,))
        else:
            b.shape(10, y, RAIL - 20, 60, 12, (0, 0, 0, 1), None, None, tags=(tag,))
        color = GOLD if active else MUTED
        icon(b, RAIL / 2, y + 22, color, (tag,))
        b.text(RAIL / 2, y + 46, label, 11, 'extra', TEXT if active else MUTED, anchor='center', tags=(tag,))
        b.clickable(tag, command)

    def nav_scan(self):
        if self.search_view is not None:
            self.search_view = None
            self.request_render()

    def nav_me(self):
        me = self.me()
        if me:
            self.open_player(me.get('name') or me['uid'], me['uid'])
        else:
            self.search_view = None
            self.reopen_setup()

    def nav_tonight(self):
        self.open_insights()

    def nav_meta(self):
        self.open_meta()

    def nav_players(self):
        """Favorites and recent lookups, plus a quick way to search anyone."""
        from scout.ui import popup
        rows = []
        favorites = self.settings.get('favorites') or []
        if favorites:
            rows.append(popup.header('Favorites'))
            for friend in favorites[:10]:
                rows.append(popup.item(short(friend.get('name') or friend.get('uid', '')),
                                       lambda f=friend: self.open_player(f.get('name') or f['uid'], f.get('uid')), icon_star))
        recent = [r for r in self.settings.get('recent_players') or [] if r.get('uid') not in {f.get('uid') for f in favorites}]
        if recent:
            rows.append(popup.header('Recently viewed'))
            for person in recent[:6]:
                rows.append(popup.item(short(person.get('name') or person.get('uid', '')),
                                       lambda p=person: self.open_player(p.get('name') or p['uid'], p.get('uid')), icon_person))
        if rows:
            rows.append(popup.separator())
        rows.append(popup.item('Search a player…', self.focus_search, icon_search))
        x = self.root.winfo_rootx() + self.board.z(RAIL + 8)
        if getattr(self, '_popup', None) is not None:
            self._popup.close()
        self._popup = popup.Popup(self, rows, x, self.root.winfo_pointery() - self.board.z(30), 260)

    def focus_search(self):
        entry = self.board.widgets.get('search')
        if entry is not None:
            entry.focus_set()

    # ---- our own title bar (the Windows one is hidden) ------------------------------------
    def _draw_window_buttons(self, width):
        """Minimize, maximize/restore and close at the top right. Returns their left edge."""
        from scout.ui import board as board_mod
        b = self.board
        size, gap, top = 36, 4, 28   # centred on the Scan button row
        x = width - 12 - size
        b.window_button(x, top, size, size, board_mod.icon_win_close, self.close, danger=True)
        x -= size + gap
        maximized = getattr(self, '_restore_geometry', None) is not None
        b.window_button(x, top, size, size, board_mod.icon_win_restore if maximized else board_mod.icon_win_maximize, self.toggle_maximize)
        x -= size + gap
        b.window_button(x, top, size, size, board_mod.icon_win_minimize, self.minimize_window)
        return x

    def minimize_window(self):
        from scout.system import window
        window.minimize(self.root)

    def toggle_maximize(self):
        from scout.system import window
        if getattr(self, '_restore_geometry', None):
            self.root.geometry(self._restore_geometry)
            self._restore_geometry = None
        else:
            self._restore_geometry = self.root.geometry()
            left, top, w, h = window.work_area()
            self.root.geometry(f'{w}x{h}+{left}+{top}')
        self.request_render()

    EDGE = 6  # px from the window edge where dragging resizes

    def _bind_frame(self):
        """Drag the top bar to move, double-click it to maximize, drag the edges to resize."""
        c = self.view_canvas
        c.bind('<Motion>', self._frame_motion, add='+')
        c.bind('<ButtonPress-1>', self._frame_press, add='+')
        c.bind('<B1-Motion>', self._frame_drag, add='+')
        c.bind('<ButtonRelease-1>', lambda e: setattr(self, '_resizing', None), add='+')
        c.bind('<Double-Button-1>', self._frame_double, add='+')

    def _edge_at(self, event):
        if getattr(self, '_restore_geometry', None):
            return ''
        w, h = self.view_canvas.winfo_width(), self.view_canvas.winfo_height()
        edge = ''
        if event.y >= h - self.EDGE:
            edge += 's'
        elif event.y <= 3:
            edge += 'n'
        if event.x >= w - self.EDGE:
            edge += 'e'
        elif event.x <= self.EDGE:
            edge += 'w'
        return edge

    def _on_control(self, event):
        """True if the press landed on a button or other clickable part of the window."""
        c = self.view_canvas
        for item in c.find_overlapping(event.x, event.y, event.x, event.y):
            if any(tag.startswith(('button', 'auto-toggle', 'rail-', 'page', 'top-ban')) for tag in c.gettags(item)):
                return True
        return False

    def _frame_motion(self, event):
        edge = self._edge_at(event)
        cursors = {'e': 'sb_h_double_arrow', 'w': 'sb_h_double_arrow', 'n': 'sb_v_double_arrow', 's': 'sb_v_double_arrow',
                   'se': 'size_nw_se', 'nw': 'size_nw_se', 'ne': 'size_ne_sw', 'sw': 'size_ne_sw'}
        if edge:
            self.view_canvas.configure(cursor=cursors.get(edge, ''))
            self._edge_cursor = True
        elif getattr(self, '_edge_cursor', False):
            self.view_canvas.configure(cursor='')
            self._edge_cursor = False

    def _frame_press(self, event):
        edge = self._edge_at(event)
        if edge:
            self._resizing = (edge, event.x_root, event.y_root, self.root.winfo_x(), self.root.winfo_y(),
                              self.root.winfo_width(), self.root.winfo_height())
            return
        self._resizing = None
        top_band = event.y < 80 * self.board.scale
        if top_band and not self._on_control(event):
            from scout.system import window
            if getattr(self, '_restore_geometry', None):
                self.toggle_maximize()
            window.start_move(self.root)

    def _frame_drag(self, event):
        if not getattr(self, '_resizing', None):
            return
        edge, x0, y0, left, top, w, h = self._resizing
        dx, dy = event.x_root - x0, event.y_root - y0
        min_w, min_h = self.root.minsize()
        if 'e' in edge:
            w = max(min_w, w + dx)
        if 's' in edge:
            h = max(min_h, h + dy)
        if 'w' in edge:
            new_w = max(min_w, w - dx)
            left += w - new_w
            w = new_w
        if 'n' in edge:
            new_h = max(min_h, h - dy)
            top += h - new_h
            h = new_h
        self.root.geometry(f'{int(w)}x{int(h)}+{int(left)}+{int(top)}')

    def _frame_double(self, event):
        if event.y < 80 * self.board.scale and not self._on_control(event):
            self.toggle_maximize()

    def search_text_value(self):
        entry = self.board.widgets.get('search')
        return typed(entry) if entry is not None else ''

    # ---- status line ------------------------------------------------------------
    def _draw_status(self):
        b = getattr(self, 'board', None)
        if b is None or not hasattr(self, '_status_y'):
            return
        b.canvas.delete('status')
        keep = len(b.texts)
        y = self._status_y
        color = GOLD if self.busy else GREEN if self.auto_scan.get() else MUTED
        b.dot(RAIL + 24, y - 5, 10, color, tags=('status',))
        width = getattr(self, '_width', b.canvas.winfo_width() / b.scale)
        hint = self.hotkey_hint.get()
        hint_w = b.measure(hint, 12, 'bold') if hint else 0
        b.text(RAIL + 42, y, self.status.get(), 14, 'bold',
               RED if getattr(self, 'status_is_problem', False) else MUTED, tags=('status',), fit=width - RAIL - 42 - hint_w - 60 - getattr(self, '_bar_room', 0))
        if hint:
            b.text(width - 28, y, hint, 12, 'bold', MUTED, anchor='e', tags=('status',))
        del b.texts[keep:]
        if getattr(self, 'viewing', None) is not None:
            b.canvas.tag_raise('viewer')

    # ---- shared helpers -------------------------------------------------------------
    def _hidden_enemies(self):
        return sum(is_hidden_name(name) for name in self.enemy_names())

    def _ban_reasons(self, row):
        reasons = []
        for evidence in sorted(row['evidence'], key=lambda e: -e['matches']):
            if evidence.get('one_trick') and evidence.get('share'):
                reasons.append((f"{short(evidence['player'])} plays it in {evidence['share'] * 100:.0f}% of games", 'one-trick'))
            else:
                reasons.append((f"{short(evidence['player'])}: {evidence['win']:g}% win rate over {evidence['matches']:g} games", None))
        if row.get('ally_overlap', 0) > .05:
            reasons.append(('Your team plays it too, so it counts a bit lower', None))
        if row.get('confidence') == 'Thin sample':
            reasons.append(('Small sample: under 10 games', None))
        return reasons[:3]

    def show_ban_details(self):
        lines = [team_notes(self.team_picks), '',
                 'Priority is a strength score, not a chance to win or a guess at what they will pick.',
                 'More games, higher win rate, a big share of their games and several enemies on the same hero raise it. '
                 'Heroes your team plays a lot count lower. Planned picks and existing bans are left out.', '']
        for row in self.advice_rows:
            lines.append(f"{row['hero']}: priority {row['priority_pct']}")
            for evidence in row['evidence']:
                kda = f", {evidence['kda']:.1f} KDA" if evidence.get('kda') is not None else ''
                lines.append(f"  {short(evidence['player'])}: {evidence['matches']:g} games, {evidence['win']:g}% wins, "
                             f"{evidence['kd']} K/D{kda} · {season_label(evidence['season'])}")
        lines.append('')
        lines.append("Only each player's top three heroes are compared. Small samples and older seasons can mislead.")
        from tkinter import messagebox
        messagebox.showinfo('Why these bans?', '\n'.join(lines), parent=self.root)

    def show_menu(self):
        """Settings: Scout's own menu, opened beside the Settings button on the rail."""
        from scout import version
        from scout.ui import popup
        rows = []
        me = self.me()
        rows.append(popup.header('Account'))
        rows.append(popup.item('Set up my tracker', self.reopen_setup, icon_person,
                               hint=f"Tracking {short(me.get('name') or me['uid'])}" if me else 'Pick which account is yours'))
        rows.append(popup.header('Scan'))
        rows.append(popup.item('Open a screenshot…', self.open_image, icon_scan))
        rows.append(popup.item('Paste a picture', self.paste_image, icon_scan, hint='Ctrl+V'))
        rows.append(popup.item('Edit names…', self.show_tools, icon_search))
        rows.append(popup.item('Mini bans', self.toggle_mini, icon_bars, hint='A small window that stays on top'))
        rows.append(popup.item('Clear names and results', self.clear_names, icon_close))
        rows.append(popup.header('Stats'))
        rows.append(popup.item('Game scan history', self.show_history_menu, icon_trend, hint=self.season.get() + ' · recent seasons'))
        from scout.stats.tracker import season_label as _label
        rows.append(popup.item('Player page seasons', lambda: self.show_seasons_picker(), icon_person,
                               hint=_label(self._player_scope())))
        rows.append(popup.header('App'))
        rows.append(popup.switch('Open as administrator', self.settings.get('run_as_admin', True), self.toggle_admin,
                                 hint='So F9 works while the game is in front'))
        if sys.platform.startswith('win'):
            rows.append(popup.switch('Windows title bar', bool(self.settings.get('windows_title_bar', False)),
                                     self.toggle_title_bar, hint='Takes effect next time Scout opens'))
        if self.uninstall_script():
            rows.append(popup.separator())
            rows.append(popup.item('Uninstall Rivals Scout…', self.uninstall, danger=True))
        rows.append(popup.separator())
        rows.append(popup.footer(f'Rivals Scout {version.label()}'))
        self._open_popup(rows, beside_rail=True)

    def _open_popup(self, rows, beside_rail=False, width=300):
        from scout.ui import popup
        if getattr(self, '_popup', None) is not None:
            self._popup.close()
        if beside_rail:
            x = self.root.winfo_rootx() + self.board.z(RAIL + 8)
            y = self.root.winfo_pointery() + self.board.z(40)
            self._popup = popup.Popup(self, rows, x, y, width, anchor='sw')
        else:
            self._popup = popup.Popup(self, rows, self.root.winfo_pointerx() - self.board.z(20), self.root.winfo_pointery() + self.board.z(14), width)

    def show_seasons_picker(self, profile=None):
        """Tick any seasons for player pages, or All time. Applies to every player page, yours included."""
        from scout.ui import popup
        from scout.stats.tracker import CAREER_SEASONS, season_short
        scope = self._player_scope()
        chosen = set(CAREER_SEASONS) if scope == 'career' else set(scope) if isinstance(scope, tuple) else {21, 20, 19, 18, 17, 16}
        cells = [{'label': season_short(sid), 'on': sid in chosen, 'id': sid} for sid in CAREER_SEASONS]
        grid = popup.grid(cells, columns=4)
        everything = popup.switch('All time', len(chosen) == len(CAREER_SEASONS), lambda: None, hint='Every season, S0 to now')

        def all_time():
            for cell in cells:
                cell['on'] = everything['on']
        everything['command'] = all_time
        grid['changed'] = lambda: everything.__setitem__('on', all(c['on'] for c in cells))

        def apply():
            picked = [c['id'] for c in cells if c['on']] or [21]
            self.set_player_seasons('career' if len(picked) == len(cells) else picked, profile)
        rows = [popup.header('Player page seasons'), everything, grid, popup.button('Apply', apply),
                popup.footer('Game scans always use recent seasons.')]
        self._open_popup(rows, width=320)

    def show_history_menu(self):
        from scout.ui import popup
        rows = [popup.header('Game scan history')]
        for value in HISTORY_CHOICES:
            label = season_label(value)
            rows.append(popup.choice(label, label == self.season.get(),
                                     lambda label=label: (self.season.set(label), self._history_changed())))
        self._open_popup(rows, width=240)

    # ---- mini bans -----------------------------------------------------------------
    def toggle_mini(self):
        if self.mini is not None and self.mini.winfo_exists():
            self.mini.destroy()
            self.mini = None
            return
        self.mini = tk.Toplevel(self.root)
        self.mini.title('Bans')
        self.mini.configure(bg=BG)
        self.mini.attributes('-topmost', True)
        self.mini.resizable(False, False)
        s = self.ui_scale
        x = self.root.winfo_screenwidth() - int(340 * s)
        self.mini.geometry(f'{int(320 * s)}x{int(420 * s)}+{x}+40')
        self.mini.protocol('WM_DELETE_WINDOW', self.toggle_mini)
        canvas = tk.Canvas(self.mini, highlightthickness=0, borderwidth=0, bg=BG)
        canvas.pack(fill='both', expand=True)
        self.mini_board = Board(canvas, s)
        canvas.bind('<Configure>', lambda e: self._render_mini())
        self._render_mini()

    def _render_mini(self):
        if self.mini is None or not self.mini.winfo_exists() or not hasattr(self, 'mini_board'):
            return
        b = self.mini_board
        width = b.canvas.winfo_width() / b.scale
        height = b.canvas.winfo_height() / b.scale
        if width < 50:
            return
        b.begin()
        b.place_image(paint.backdrop(b.z(width), b.z(height), BG, GLOW_PURPLE, (30, 20, 50)), 0, 0)
        b.text(18, 34, 'Ban these', 18)
        b.button(width - 52, 17, '', self.toggle_mini, 'quiet', 34, width=34, icon=icon_close)
        y = 62
        if not self.advice_rows:
            b.text(18, y + 20, 'Waiting for enemy stats…', 14, 'bold', MUTED)
        for index, row in enumerate(self.advice_rows[:3]):
            if index == 0:
                b.shape(18, y, width - 36, 88, 22, '#221E16', '#16140F', GOLD_BOTTOM, 1, glow=(GOLD_BOTTOM, 30), glow_size=8)
                b.avatar(32, y + 14, 60, '#2A2B33', '#1E1F26', GOLD_BOTTOM, 1.5, picture=hero_picture(row['hero']),
                         initials=initials(row['hero']))
                b.text(106, y + 30, 'TOP BAN', 11, color=GOLD)
                b.text(106, y + 56, row['hero'], 22, color=TEXT, fit=width - 140)
                y += 88 + 12
            else:
                b.shape(18, y, width - 36, 70, 20, '#17181E', '#17181E', CARD_LINE)
                tint = tint_for(row['hero'])
                b.avatar(30, y + 13, 44, tint[0], tint[1], tint[2], 2, picture=hero_picture(row['hero']),
                         initials=initials(row['hero']))
                b.text(86, y + 26, row['hero'], 17, fit=width - 120)
                b.text(86, y + 48, self._ban_line(row), 12, 'bold', MUTED, fit=width - 120)
                y += 70 + 12
        threat = self._threat_line()
        if threat:
            b.text(18, y + 4, threat.replace('  ·  ', '\n'), 12, 'bold', WARN_TEXT, anchor='nw', width=width - 36)
        hidden = self._hidden_enemies()
        run = self.my_session
        note = f'{hidden} hidden enem{"y" if hidden == 1 else "ies"} · no stats for them' if hidden else (
            f"Tonight {run['wins']}W {run['games'] - run['wins']}L" + (f" · {'+' if run['points'] > 0 else ''}{run['points']:.0f} pts" if run['ranked'] else '')
            if run else 'Stays on top of the game')
        b.text(width / 2, height - 22, note, 12, 'bold', WARN_TEXT if hidden else MUTED, anchor='center')
        b.finish()

    # ---- screenshot viewer -------------------------------------------------------------
    def show_screenshot(self, path):
        """Show a scanned screenshot over Scout's own window, like a chat app does (Esc or a click outside closes it)."""
        self.viewing = Path(path)
        self.request_render()

    def close_viewer(self):
        if getattr(self, 'viewing', None) is not None:
            self.viewing = None
            self.request_render()
            return True
        return False

    def open_screenshot_folder(self):
        """Show the screenshot in File Explorer (selected), so it can be shared."""
        path = getattr(self, 'viewing', None)
        if path is None:
            return
        import subprocess
        try:
            subprocess.Popen(['explorer', '/select,', str(path)])
        except OSError:
            self.status.set(f'The screenshot is in {path.parent}')

    def _draw_viewer(self, width, height):
        """The screenshot overlay: dims the app, the picture in the middle, name and buttons along the top."""
        b = self.board
        path = self.viewing
        from PIL import Image
        shade = Image.new('RGBA', (b.z(width), b.z(height)), (5, 6, 8, 222))
        b.place_image(shade, 0, 0, tags=('viewer', 'viewer-bg'))
        b.text(28, 34, path.name, 16, tags=('viewer',), fit=width * .5)
        when = time.strftime('%I:%M %p', time.localtime(path.stat().st_mtime)).lstrip('0') if path.exists() else ''
        b.text(28, 56, f'Scanned screenshot  ·  {when}' if when else 'Scanned screenshot', 12, 'bold', MUTED, tags=('viewer',))
        bx = width - 28 - 44
        b.button(bx, 18, '', self.close_viewer, 'quiet', 44, width=44, icon=icon_close, tags=('viewer',))
        bx -= 10
        label_w = b.measure('Show in folder', 14) + 34
        b.button(bx - label_w, 18, 'Show in folder', self.open_screenshot_folder, 'quiet', 44, 14, width=label_w, tags=('viewer',))
        try:
            with Image.open(path) as source:
                ratio = source.width / max(1, source.height)
            pic_w = min(width - 120, (height - 140) * ratio)
            pic_h = pic_w / ratio
            image = paint.rounded_picture(path, b.z(pic_w), b.z(pic_h), b.z(10), None)
            b.place_image(image, (width - pic_w) / 2, 84 + (height - 120 - pic_h) / 2, tags=('viewer', 'viewer-pic'))
        except (OSError, ValueError):
            b.text(width / 2, height / 2, "This screenshot can't be opened.", 18, color=MUTED, anchor='center', tags=('viewer',))
        b.text(width / 2, height - 22, 'Esc or click outside the picture to close', 12, 'bold', MUTED, anchor='center', tags=('viewer',))
        b.canvas.tag_bind('viewer-bg', '<ButtonRelease-1>', lambda e: self.close_viewer())
        # Type boxes sit on top of the canvas; hide them while the screenshot is open.
        for item in b.canvas.find_all():
            if b.canvas.type(item) == 'window':
                b.canvas.itemconfigure(item, state='hidden')
