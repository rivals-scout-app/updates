"""Scout's own drop-down menu: a dark rounded panel drawn like the rest of the app
(the Windows menu can't be styled). Rows: headers, items with icons, on/off switches,
pick-one choices, and separators."""
import sys
import tkinter as tk

from scout.ui.board import Board
from scout.ui.theme import CARD_LINE, GOLD, MUTED, TEXT, LOSS_SOFT, DARK, SOFT as SOFT_TEXT
from scout.ui.theme import GOLD_TOP as GOLD_TOP_COLOR, GOLD_BOTTOM as GOLD_BOTTOM_COLOR


def header(label):
    return {'kind': 'header', 'label': label}


def item(label, command, icon=None, hint='', danger=False):
    return {'kind': 'item', 'label': label, 'command': command, 'icon': icon, 'hint': hint, 'danger': danger}


def switch(label, on, command, hint=''):
    return {'kind': 'switch', 'label': label, 'on': bool(on), 'command': command, 'hint': hint}


def choice(label, picked, command):
    return {'kind': 'choice', 'label': label, 'picked': bool(picked), 'command': command}


def grid(cells, columns=4):
    """Tick boxes in columns; cells are dicts with 'label' and 'on' (changed in place when clicked)."""
    return {'kind': 'grid', 'cells': cells, 'columns': columns}


def button(label, command):
    return {'kind': 'button', 'label': label, 'command': command}


def separator():
    return {'kind': 'sep'}


def footer(label):
    return {'kind': 'footer', 'label': label}


def stat(label, value='', color=None, detail=''):
    """A plain line: label on the left, value on the right (not clickable)."""
    return {'kind': 'stat', 'label': label, 'value': value, 'color': color, 'detail': detail}


def note(text, lines=2, color=None):
    """Small wrapped text. `lines` is how many lines to leave room for."""
    return {'kind': 'note', 'label': text, 'lines': lines, 'color': color}


HEIGHTS = {'header': 30, 'item': 36, 'switch': 40, 'choice': 34, 'sep': 11, 'footer': 30, 'button': 52}


def row_height(row):
    if row['kind'] == 'stat':
        return 38 if row.get('detail') else 26
    if row['kind'] == 'note':
        return 8 + 16 * row['lines']
    if row['kind'] == 'grid':
        return 32 * -(-len(row['cells']) // row['columns']) + 6
    return HEIGHTS[row['kind']]


class Popup:
    """Open with Popup(app, rows, x, y). Closes on a click outside, Escape, or after a row is used."""

    def __init__(self, app, rows, x, y, width=300, anchor='nw'):
        self.app, self.rows, self.width = app, rows, width
        scale = app.ui_scale
        self.window = window = tk.Toplevel(app.root)
        window.overrideredirect(True)
        window.attributes('-topmost', True)
        ground = '#0B0C10'
        if sys.platform.startswith('win'):
            ground = '#010203'  # made see-through below, so only the rounded panel shows
            try:
                window.attributes('-transparentcolor', ground)
            except tk.TclError:
                ground = '#0B0C10'
        window.configure(bg=ground)
        height = 12 + sum(row_height(row) for row in rows) + 8
        self.height = height
        w, h = int(width * scale), int(height * scale)
        if anchor == 'sw':
            y -= h
        screen_w, screen_h = window.winfo_screenwidth(), window.winfo_screenheight()
        x, y = max(0, min(int(x), screen_w - w - 4)), max(0, min(int(y), screen_h - h - 4))
        window.geometry(f'{w}x{h}+{x}+{y}')
        self.canvas = canvas = tk.Canvas(window, highlightthickness=0, borderwidth=0, bg=ground, width=w, height=h)
        canvas.pack(fill='both', expand=True)
        self.board = Board(canvas, scale)
        self._draw()
        window.bind('<Escape>', lambda e: self.close())
        window.bind('<ButtonPress-1>', self._outside, add='+')
        window.after(10, self._grab)

    def _grab(self):
        try:
            self.window.focus_force()
            self.window.grab_set()
        except tk.TclError:
            pass

    def _outside(self, event):
        x, y = event.x_root - self.window.winfo_rootx(), event.y_root - self.window.winfo_rooty()
        if not (0 <= x < self.window.winfo_width() and 0 <= y < self.window.winfo_height()):
            self.close()

    def close(self):
        try:
            self.window.grab_release()
            self.window.destroy()
        except tk.TclError:
            pass

    def _use(self, row):
        if row['kind'] == 'switch':
            row['on'] = not row['on']
            row['command']()
            self._draw()  # the command may have changed other rows (e.g. "All time" ticks every box)
            return
        self.close()
        row['command']()

    def _toggle_cell(self, row, cell):
        cell['on'] = not cell['on']
        if row.get('changed'):
            row['changed']()
        self._draw()

    def _draw(self):
        b, c = self.board, self.canvas
        c.delete('all')
        b.begin()
        w = self.width
        b.shape(0, 0, w, self.height, 14, '#16171D', '#121318', CARD_LINE, 1)
        y = 12
        for index, row in enumerate(self.rows):
            kind, rh = row['kind'], row_height(row)
            tag = f'row{index}'
            if kind == 'header':
                b.text(18, y + 18, row['label'].upper(), 10, 'extra', MUTED)
            elif kind == 'sep':
                c.create_line(b.z(14), b.z(y + 5), b.z(w - 14), b.z(y + 5), fill=CARD_LINE)
            elif kind == 'footer':
                b.text(18, y + 16, row['label'], 11, 'bold', '#55566A')
            elif kind == 'stat':
                top = y + 13
                b.text(18, top, row['label'], 13, 'extra', TEXT, fit=w - 130)
                if row.get('value'):
                    b.text(w - 18, top, row['value'], 13, 'extra', row.get('color') or SOFT_TEXT, anchor='e')
                if row.get('detail'):
                    b.text(18, top + 15, row['detail'], 10, 'bold', MUTED, fit=w - 36)
            elif kind == 'note':
                b.text(18, y + 4, row['label'], 11, 'bold', row.get('color') or SOFT_TEXT, anchor='nw', width=w - 36)
            elif kind == 'grid':
                cols = row['columns']
                cell_w = (w - 24) / cols
                for i, cell in enumerate(row['cells']):
                    cx, cy = 12 + (i % cols) * cell_w, y + 3 + (i // cols) * 32
                    ctag = f'row{index}cell{i}'
                    b.shape(cx + 2, cy, cell_w - 4, 28, 7, '#22232B' if cell['on'] else (0, 0, 0, 1), None,
                            GOLD if cell['on'] else '#2C2D37', 1, tags=(ctag,))
                    b.text(cx + cell_w / 2, cy + 14, cell['label'], 12, 'extra', GOLD if cell['on'] else SOFT_TEXT,
                           anchor='center', tags=(ctag,))
                    c.tag_bind(ctag, '<Enter>', lambda e: c.configure(cursor='hand2'))
                    c.tag_bind(ctag, '<Leave>', lambda e: c.configure(cursor=''))
                    c.tag_bind(ctag, '<ButtonRelease-1>', lambda e, cell=cell, row=row: self._toggle_cell(row, cell))
            elif kind == 'button':
                btag = f'row{index}'
                b.shape(14, y + 8, w - 28, 38, 10, GOLD_TOP_COLOR, GOLD_BOTTOM_COLOR, None, direction='down', tags=(btag,))
                b.text(w / 2, y + 27, row['label'], 14, color=DARK, anchor='center', tags=(btag,))
                c.tag_bind(btag, '<Enter>', lambda e: c.configure(cursor='hand2'))
                c.tag_bind(btag, '<Leave>', lambda e: c.configure(cursor=''))
                c.tag_bind(btag, '<ButtonRelease-1>', lambda e, r=row: self._use(r))
            else:
                b.shape(8, y + 2, w - 16, rh - 4, 8, (0, 0, 0, 1), None, None, tags=(tag,))  # catches the pointer across the whole row
                glow = b.shape(8, y + 2, w - 16, rh - 4, 8, '#22232B', None, None, tags=(tag,))
                c.itemconfigure(glow, state='hidden')
                color = LOSS_SOFT if row.get('danger') else TEXT
                text_x = 18
                if kind == 'item' and row.get('icon'):
                    row['icon'](b, 28, y + rh / 2, MUTED, (tag,))
                    text_x = 48
                if kind == 'choice':
                    if row['picked']:
                        c.create_line(b.z(20), b.z(y + rh / 2), b.z(24), b.z(y + rh / 2 + 4), b.z(31), b.z(y + rh / 2 - 4),
                                      fill=GOLD, width=b.z(2), capstyle='round', joinstyle='round', tags=(tag,))
                    text_x = 42
                    color = GOLD if row['picked'] else TEXT
                b.text(text_x, y + rh / 2 - (6 if row.get('hint') else 0), row['label'], 13, 'extra', color, tags=(tag,),
                       fit=w - text_x - (70 if kind == 'switch' else 24))
                if row.get('hint'):
                    b.text(text_x, y + rh / 2 + 9, row['hint'], 10, 'bold', MUTED, tags=(tag,),
                           fit=w - text_x - (70 if kind == 'switch' else 24))
                if kind == 'switch':
                    on = row['on']
                    b.shape(w - 18 - 34, y + rh / 2 - 10, 34, 20, 10, GOLD if on else '#2C2D37', None, None, tags=(tag,))
                    b.avatar(w - 18 - (17 if on else 31), y + rh / 2 - 7, 14, DARK if on else MUTED, DARK if on else MUTED,
                             DARK if on else MUTED, 0.1, tags=(tag,))
                c.tag_bind(tag, '<Enter>', lambda e, g=glow: (c.itemconfigure(g, state='normal'), c.configure(cursor='hand2')))
                c.tag_bind(tag, '<Leave>', lambda e, g=glow: (c.itemconfigure(g, state='hidden'), c.configure(cursor='')))
                c.tag_bind(tag, '<ButtonRelease-1>', lambda e, r=row: self._use(r))
            y += rh
