"""Registered Windows capture shortcut with a background key-state fallback."""
import ctypes
from ctypes import wintypes
import threading
import time
import logging
from scout.system.raw_keys import RawKeyboardSink


class PressGate:
    """Deduplicate registered messages and polling; a held key captures once."""
    def __init__(self, held=False):
        self.held = held
        self.last_emit = float('-inf')

    def update(self, down, notified=False, now=None):
        now = time.monotonic() if now is None else now
        candidate = notified or (down and not self.held)
        self.held = down
        if candidate and now - self.last_emit >= .3:
            self.last_emit = now
            return True
        return False


class CaptureHotkey:
    def __init__(self, queue):
        self.queue = queue
        self.closed = threading.Event()
        self.thread_id = None
        self.user = ctypes.WinDLL('user32', use_last_error=True)
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.user.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
        self.user.RegisterHotKey.restype = wintypes.BOOL
        self.user.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
        self.user.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
        self.user.PeekMessageW.restype = wintypes.BOOL
        self.user.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user.GetAsyncKeyState.restype = ctypes.c_short
        self.user.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        self.user.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
        self.user.DispatchMessageW.restype = ctypes.c_ssize_t
        self.kernel.GetCurrentThreadId.restype = wintypes.DWORD

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _key_down(self, modified):
        down = bool(self.user.GetAsyncKeyState(0x78) & 0x8000)
        if modified:
            down = down and bool(self.user.GetAsyncKeyState(0x11) & 0x8000) and bool(self.user.GetAsyncKeyState(0x10) & 0x8000)
        return down

    def _run(self):
        if self.closed.is_set():
            return
        self.thread_id = self.kernel.GetCurrentThreadId()
        message = wintypes.MSG()
        self.user.PeekMessageW(ctypes.byref(message), None, 0, 0, 0)
        registered = self.user.RegisterHotKey(None, 1, 0x4000, 0x78)
        first_error = ctypes.get_last_error() if not registered else 0
        binding = 'F9'
        if not registered:
            registered = self.user.RegisterHotKey(None, 1, 0x4006, 0x78)
            binding = 'Ctrl+Shift+F9'
        if not registered:
            self.queue.put(('hotkey_status', 'Windows could not register F9 or Ctrl+Shift+F9 (errors ' + str(first_error) + ', ' + str(ctypes.get_last_error()) + '). Close other Scout copies or use Capture in 3s.'))
            self.thread_id = None
            return
        raw = None
        try:
            modified = binding != 'F9'
            raw_ready = False
            raw_error = 'initialization failed'
            try:
                raw = RawKeyboardSink(modified)
                raw_ready = raw.start()
                raw_error = str(raw.error)
            except Exception:
                logging.exception('Background keyboard listener failed; retaining registered shortcut')
            gate = PressGate(self._key_down(modified))
            self.queue.put(('hotkey_binding', binding))
            self.queue.put(('hotkey_status', binding + ' is registered. ' + ('Background input listener active.' if raw_ready else 'Background input unavailable (Windows error ' + raw_error + '); shortcut and polling remain active.')))
            while not self.closed.is_set():
                try:
                    self._poll(message, raw, raw_ready, modified, gate)
                except Exception:
                    # Keep listening; one bad message must not stop capture for good.
                    logging.exception('Capture shortcut check failed; still listening')
                    self.closed.wait(.5)
                self.closed.wait(.02)
        finally:
            if raw is not None:
                raw.close()
            self.user.UnregisterHotKey(None, 1)
            self.thread_id = None

    def _poll(self, message, raw, raw_ready, modified, gate):
        notified = False
        while self.user.PeekMessageW(ctypes.byref(message), None, 0, 0, 1):
            if message.message == 0x0012:
                self.closed.set()
                return
            if message.message == 0x0312 and message.wParam == 1:
                notified = True
            if message.hWnd:
                self.user.DispatchMessageW(ctypes.byref(message))
        raw_pressed = raw.state.consume() if raw_ready else False
        down = self._key_down(modified) or (raw_ready and raw.state.down)
        if gate.update(down, notified or raw_pressed):
            logging.info('Capture key detected via %s', 'background input' if raw_pressed else 'Windows shortcut' if notified else 'key-state check')
            self.queue.put(('hotkey', None))

    def close(self):
        self.closed.set()
        if self.thread_id is not None:
            self.user.PostThreadMessageW(self.thread_id, 0x0012, 0, 0)
