"""Windows background keyboard notifications, filtered to the capture shortcut.

Uses RIDEV_INPUTSINK on a message-only window. No hooks, device grabs,
NOLEGACY flags, game process access, or storage of typed keys.
"""
import ctypes as c
from ctypes import wintypes as w

WNDPROC = c.WINFUNCTYPE(c.c_ssize_t, w.HWND, w.UINT, w.WPARAM, w.LPARAM)

class WNDCLASS(c.Structure):
    _fields_ = [('style', w.UINT), ('lpfnWndProc', WNDPROC),
                ('cbClsExtra', c.c_int), ('cbWndExtra', c.c_int),
                ('hInstance', w.HINSTANCE), ('hIcon', w.HICON),
                ('hCursor', w.HANDLE), ('hbrBackground', w.HBRUSH),
                ('lpszMenuName', w.LPCWSTR), ('lpszClassName', w.LPCWSTR)]

class RAWINPUTDEVICE(c.Structure):
    _fields_ = [('usUsagePage', w.USHORT), ('usUsage', w.USHORT),
                ('dwFlags', w.DWORD), ('hwndTarget', w.HWND)]

class RAWINPUTHEADER(c.Structure):
    _fields_ = [('dwType', w.DWORD), ('dwSize', w.DWORD),
                ('hDevice', w.HANDLE), ('wParam', w.WPARAM)]

class RAWKEYBOARD(c.Structure):
    _fields_ = [('MakeCode', w.USHORT), ('Flags', w.USHORT),
                ('Reserved', w.USHORT), ('VKey', w.USHORT),
                ('Message', w.UINT), ('ExtraInformation', w.ULONG)]

class ShortcutState:
    def __init__(self, modified=False):
        self.modified = modified
        self.f9 = False
        self.ctrl = False
        self.shift = False
        self.pending = False

    def feed(self, key, released):
        # All unrelated keys are discarded here and never retained or logged.
        down = not released
        if key in (0x11, 0xa2, 0xa3):
            self.ctrl = down
        elif key in (0x10, 0xa0, 0xa1):
            self.shift = down
        elif key == 0x78:
            if down and not self.f9 and (not self.modified or (self.ctrl and self.shift)):
                self.pending = True
            self.f9 = down

    @property
    def down(self):
        return self.f9 and (not self.modified or (self.ctrl and self.shift))

    def consume(self):
        pending, self.pending = self.pending, False
        return pending

class RawKeyboardSink:
    def __init__(self, modified=False):
        self.state = ShortcutState(modified)
        self.user = c.WinDLL('user32', use_last_error=True)
        self.kernel = c.WinDLL('kernel32', use_last_error=True)
        self.hwnd = None
        self.atom = None
        self.registered = False
        self.error = 0
        self.proc = WNDPROC(self._window_proc)
        specs = [
            ('RegisterClassW', [c.POINTER(WNDCLASS)], w.ATOM),
            ('UnregisterClassW', [w.LPCWSTR, w.HINSTANCE], w.BOOL),
            ('CreateWindowExW', [w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,c.c_int,c.c_int,c.c_int,c.c_int,w.HWND,w.HMENU,w.HINSTANCE,c.c_void_p], w.HWND),
            ('DestroyWindow', [w.HWND], w.BOOL),
            ('DefWindowProcW', [w.HWND,w.UINT,w.WPARAM,w.LPARAM], c.c_ssize_t),
            ('RegisterRawInputDevices', [c.POINTER(RAWINPUTDEVICE),w.UINT,w.UINT], w.BOOL),
            ('GetRawInputData', [w.HANDLE,w.UINT,c.c_void_p,c.POINTER(w.UINT),w.UINT], w.UINT),
        ]
        for name, args, result in specs:
            function = getattr(self.user, name)
            function.argtypes, function.restype = args, result
        self.kernel.GetModuleHandleW.argtypes = [w.LPCWSTR]
        self.kernel.GetModuleHandleW.restype = w.HMODULE
        self.kernel.GetCurrentThreadId.restype = w.DWORD

    def start(self):
        self.instance = self.kernel.GetModuleHandleW(None)
        self.name = 'RivalsScoutCapture-' + str(self.kernel.GetCurrentThreadId())
        wc = WNDCLASS()
        wc.lpfnWndProc, wc.hInstance, wc.lpszClassName = self.proc, self.instance, self.name
        self.atom = self.user.RegisterClassW(c.byref(wc))
        if self.atom:
            self.hwnd = self.user.CreateWindowExW(0,self.name,'',0,0,0,0,0,w.HWND(-3),None,self.instance,None)
        if self.hwnd:
            # Generic desktop / keyboard, explicitly receive background input.
            device = RAWINPUTDEVICE(1,6,0x100,self.hwnd)
            self.registered = bool(self.user.RegisterRawInputDevices(c.byref(device),1,c.sizeof(device)))
        if not self.registered:
            self.error = c.get_last_error()
            self.close()
        return self.registered

    def _window_proc(self, hwnd, message, wp, lp):
        if message == 0x00ff:
            self._read(lp)
        return self.user.DefWindowProcW(hwnd,message,wp,lp)

    def _read(self, handle):
        size = w.UINT()
        header_size = c.sizeof(RAWINPUTHEADER)
        if self.user.GetRawInputData(handle,0x10000003,None,c.byref(size),header_size) == 0xffffffff:
            return
        if not header_size + c.sizeof(RAWKEYBOARD) <= size.value <= 1024:
            return
        buffer = c.create_string_buffer(size.value)
        copied = self.user.GetRawInputData(handle,0x10000003,buffer,c.byref(size),header_size)
        if copied == 0xffffffff or copied < header_size + c.sizeof(RAWKEYBOARD):
            return
        header = RAWINPUTHEADER.from_buffer_copy(buffer)
        if header.dwType != 1:
            return
        keyboard = RAWKEYBOARD.from_buffer_copy(buffer,header_size)
        self.state.feed(keyboard.VKey,bool(keyboard.Flags & 1))

    def close(self):
        if self.registered:
            device = RAWINPUTDEVICE(1,6,1,None)
            self.user.RegisterRawInputDevices(c.byref(device),1,c.sizeof(device))
            self.registered = False
        if self.hwnd:
            self.user.DestroyWindow(self.hwnd)
            self.hwnd = None
        if self.atom:
            self.user.UnregisterClassW(self.name,self.instance)
            self.atom = None
