"""Frameless main window on Windows: Scout draws its own minimize / maximize / close
buttons in its top bar instead of the white Windows title bar.

Everything here is best-effort: if a Windows call fails the app keeps working, and
Settings > "Use the Windows title bar" turns the normal frame back on.
"""
import ctypes
import sys

GWL_EXSTYLE = -20
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080
WM_NCLBUTTONDOWN = 0x00A1
HTCAPTION = 2


def available():
    return sys.platform.startswith('win')


def _hwnd(root):
    return ctypes.windll.user32.GetParent(root.winfo_id())


def _show_in_taskbar(root):
    """overrideredirect windows vanish from the taskbar and Alt-Tab; this puts them back."""
    user32 = ctypes.windll.user32
    hwnd = _hwnd(root)
    style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, (style & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW)
    try:
        corner = ctypes.c_int(2)  # Windows 11: round the corners like a normal window
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 33, ctypes.byref(corner), 4)
    except (AttributeError, OSError):
        pass


def make_frameless(root):
    """Hide the Windows title bar but keep the taskbar button. True if it worked."""
    if not available():
        return False
    try:
        root.overrideredirect(True)
        root.update_idletasks()
        _show_in_taskbar(root)
        root.withdraw()
        root.after(10, lambda: (root.deiconify(), root.focus_force()))
        return True
    except Exception:
        try:
            root.overrideredirect(False)
        except Exception:
            pass
        return False


def start_move(root):
    """Let Windows drag the window from here (like grabbing a title bar).

    The request is posted, not sent: SendMessage would run Windows' whole drag loop inside
    this click handler, and Tk calling back into Python from there freezes or crashes the app.
    Posted, the drag runs from Tk's own event loop like a normal title-bar drag."""
    try:
        ctypes.windll.user32.ReleaseCapture()
        ctypes.windll.user32.PostMessageW(_hwnd(root), WM_NCLBUTTONDOWN, HTCAPTION, 0)
        return True
    except Exception:
        return False


def minimize(root):
    """Frameless Tk windows can't iconify directly: drop the frameless flag, minimize, put it back on restore."""
    root.overrideredirect(False)
    root.iconify()

    def restored(_event=None):
        if root.state() == 'normal':
            root.unbind('<Map>')
            root.overrideredirect(True)
            try:
                _show_in_taskbar(root)
            except Exception:
                pass
            root.focus_force()
    root.bind('<Map>', restored)


def work_area():
    """(left, top, width, height) of the screen minus the taskbar."""
    class RECT(ctypes.Structure):
        _fields_ = [('left', ctypes.c_long), ('top', ctypes.c_long), ('right', ctypes.c_long), ('bottom', ctypes.c_long)]
    rect = RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x30, 0, ctypes.byref(rect), 0)  # SPI_GETWORKAREA
    return rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top
