"""Local, explainable ban estimates from observed hero records."""
import math

# Conservative role catalog. Unknown/new heroes require an explicit role in the editor.
ROLES = {}
for role, names in {
    'Vanguard': 'Hulk|Doctor Strange|Captain America|Groot|Magneto|Peni Parker|Thor|Venom|The Thing|Emma Frost|Angela|Devil Dinosaur|Rogue|The Hood',
    'Strategist': 'Loki|Mantis|Rocket Raccoon|Luna Snow|Adam Warlock|Jeff the Land Shark|Cloak & Dagger|Invisible Woman|Ultron|Gambit|Jubilee|White Fox',
    'Duelist': 'The Punisher|Storm|Human Torch|Hela|Hawkeye|Black Panther|Magik|Moon Knight|Namor|Psylocke|Scarlet Witch|Spider-Man|Squirrel Girl|Star-Lord|Winter Soldier|Iron Man|Iron Fist|Wolverine|Black Widow|Mister Fantastic|Blade|Phoenix|Daredevil|Cyclops|Elsa Bloodstone|Black Cat|Gorr The God Butcher',
}.items():
    ROLES.update({name: role for name in names.split('|')})


def role_for(name):
    if name.endswith('(Vanguard)'):
        return 'Vanguard'
    if name.endswith('(Duelist)'):
        return 'Duelist'
    if name.endswith('(Strategist)'):
        return 'Strategist'
    return next((role for hero, role in ROLES.items() if hero.casefold() == name.casefold()), 'Unknown role')


def number(value):
    try:
        result = float(str(value).rstrip('%'))
        return result if math.isfinite(result) and result >= 0 else None
    except (ValueError, TypeError):
        return None


ONE_TRICK_SHARE = .5
ONE_TRICK_GAMES = 20


def is_one_trick(row):
    share = row.get('share')
    games = number(row.get('matches_played')) or 0
    return isinstance(share, (int, float)) and share >= ONE_TRICK_SHARE and games >= ONE_TRICK_GAMES


def kda_of(row, games):
    """(kills + assists) / deaths from a hero row's totals; None if the site has no counts."""
    values = [row.get(field) for field in ('kills', 'deaths', 'assists')]
    if not games or any(not isinstance(value, (int, float)) for value in values):
        return None
    kills, deaths, assists = values
    return (kills + assists) / max(deaths, 1)


def recommend(results, team=(), excluded=(), priority='Any role', allies=(), meta=None):
    meta = meta or {}
    protected = {name.casefold() for name, role in team if name}
    protected.update(name.casefold() for name in excluded if name)
    allied_comfort = {}
    for ally in allies:
        rows = ally.get('heroes', [])
        total = sum(number(row.get('matches_played')) or 0 for row in rows)
        for row in rows:
            games = number(row.get('matches_played')) or 0
            if games > 0:
                key = row.get('hero_name', '').casefold()
                overlap = (games / (games + 15)) * (games / max(games, total))
                allied_comfort[key] = max(allied_comfort.get(key, 0), overlap)
    grouped = {}
    for result in results:
        rows = result.get('heroes', [])
        total = sum(number(row.get('matches_played')) or 0 for row in rows)
        for row in rows:
            name = row.get('hero_name', '')
            games = number(row.get('matches_played'))
            win = number(row.get('win_pct'))
            if not name or name.casefold() in protected or not games or win is None or win > 100:
                continue
            # Win rate shrinks toward 50% to avoid rewarding one lucky match.
            adjusted = (games * win / 100 + 10) / (games + 20)
            familiarity = games / (games + 15)
            share = games / max(total, games)
            score = 100 * familiarity * (.55 + .35 * adjusted + .10 * share)
            # One-trick: most of the player's games are on this hero.
            one_trick = is_one_trick(row)
            if one_trick:
                score *= 1.12
            role = role_for(name)
            if priority == role:
                score *= 1.15
            # Strong in the current meta (RivalsData tier score 60-100): up to 25% more ban weight.
            strength = meta.get(name.casefold())
            if strength:
                score *= 1 + .25 * max(0, min(1, (strength['score'] - 60) / 40))
            item = grouped.setdefault(name, {'hero': name, 'role': role, 'evidence': [], 'scores': []})
            item['scores'].append(score)
            item['one_trick'] = item.get('one_trick', False) or one_trick
            item['evidence'].append({'player': result['username'], 'matches': games, 'win': win,
                                     'share': row.get('share'), 'one_trick': one_trick,
                                     'kd': row.get('kd', 'N/A'), 'kda': kda_of(row, games),
                                     'limited': bool(result.get('limited_history')),
                                     'season': result.get('season'), 'note': result.get('note', '')})
    ranked = []
    for item in grouped.values():
        values = sorted(item.pop('scores'), reverse=True)
        overlap = allied_comfort.get(item['hero'].casefold(), 0)
        item['ally_overlap'] = overlap
        item['meta'] = meta.get(item['hero'].casefold())
        item['score'] = max(0, min(100, values[0] + .15 * sum(values[1:]) - 30 * overlap))
        item['priority_pct'] = round(item['score'])
        item['confidence'] = 'Thin sample' if max(e['matches'] for e in item['evidence']) < 10 else 'More records'
        ranked.append(item)
    return sorted(ranked, key=lambda item: (-item['score'], item['hero']))[:3]


def team_notes(team):
    selected = [(name, role) for name, role in team if name]
    if not selected:
        return 'Add planned allied picks to protect them from bans and review team roles.'
    counts = {role: sum(r == role for _, r in selected) for role in ('Vanguard', 'Duelist', 'Strategist')}
    text = ' / '.join(f'{count} {role}' for role, count in counts.items())
    if len(selected) < 6:
        text += ' • Partial planned composition'
    if any(role not in counts for _, role in selected):
        text += ' • Assign roles for unknown heroes'
    if len(selected) == 6:
        if counts['Strategist'] == 0:
            text += ' • No Strategist selected: consider healing coverage'
        if counts['Vanguard'] == 0:
            text += ' • No Vanguard selected: consider frontline coverage'
    return text
