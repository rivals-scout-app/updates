import json
import re
import math
import threading
import time
import copy
from pathlib import Path
from urllib.parse import quote
import requests
from scout.stats.public_profile import parse_profile_page

BASE = 'https://api.rivalstracker.com/api'
from scout import paths
HERO_NAMES = json.loads(paths.asset('hero-names.json').read_text(encoding='utf-8'))
CAREER_SEASONS = tuple(range(21, 0, -1))
CAREER_CACHE = {}
CAREER_CACHE_TTL = 600
HISTORY_REQUEST_INTERVAL = 1.0

class StatsError(Exception):
    def __init__(self, message, stop_batch=False):
        super().__init__(message)
        self.stop_batch = stop_batch

class PublicApiUnavailable(StatsError):
    pass

def season_short(value):
    """'S10.5' for season ID 21, 'S0' for 1."""
    value = int(value)
    return 'S0' if value == 1 else f'S{value // 2}' + ('.5' if value % 2 else '')


def season_label(value):
    if isinstance(value, (tuple, list)):
        # A hand-picked set of season IDs (21 = S10.5 ... 1 = S0).
        picked = sorted({int(v) for v in value}, reverse=True)
        if not picked:
            return 'No seasons'
        if set(picked) == set(CAREER_SEASONS):
            return 'All time'
        if len(picked) == 1:
            return season_short(picked[0])
        if picked == list(range(picked[0], picked[-1] - 1, -1)):
            return f'{season_short(picked[-1])}–{season_short(picked[0])}'
        return f'{len(picked)} seasons'
    if value == 'recent6':
        return 'S8–S10.5'
    if value == 'recent2':
        return 'S10 + S10.5'
    if value == 'recent3':
        return 'S9.5–S10.5'
    if value == 'career':
        return 'All time'
    value = int(value)
    if value == 1:
        return 'Season 0'
    if 2 <= value <= 21:
        return f'Season {value // 2}' + ('.5' if value % 2 else '')
    return f'season ID {value}'

def number(value):
    return float(str(value).replace(',', ''))

def hit_rate(row):
    """Accuracy as 0..1, or None if the site has none."""
    try:
        value = number(row['session_hit_rate'])
    except (KeyError, TypeError, ValueError):
        return None
    return value if math.isfinite(value) and 0 <= value <= 1 else None


BLOCKED_FIELDS = ('damage_blocked', 'total_damage_blocked', 'block_damage', 'total_block_damage', 'blocked')


def blocked_count(row):
    """Damage blocked (shields and the like), under whichever name the site uses. None if it has none."""
    if not isinstance(row, dict):
        return None
    for field in BLOCKED_FIELDS:
        if field in row:
            return combat_count(row, field)
    for field in row:
        if 'block' in str(field).lower():
            return combat_count(row, field)
    return None


def combat_count(row, field):
    try:
        value = number(row[field])
    except (KeyError, TypeError, ValueError):
        return None
    return value if math.isfinite(value) and value >= 0 else None

def kd_ratio(kills, deaths):
    if kills is None or deaths is None:
        return 'N/A'
    if deaths == 0:
        return 'no deaths' if kills > 0 else 'N/A'
    return f'{kills / deaths:.2f}'

RETRY_STATUSES = (429, 502, 503, 504)
RETRY_DELAY = 3.0
MEMORY_FILE = paths.MEMORY
_MEMORY = None
_MEMORY_LOCK = threading.Lock()


def send_with_retry(send):
    """Run one request; if the site is busy or briefly down, wait and try once more."""
    for attempt in (1, 2):
        try:
            response = send()
        except requests.RequestException:
            if attempt == 2:
                raise
            time.sleep(RETRY_DELAY)
            continue
        if response.status_code not in RETRY_STATUSES or attempt == 2:
            return response
        try:
            wait = float(response.headers.get('Retry-After', RETRY_DELAY))
        except (TypeError, ValueError, AttributeError):
            wait = RETRY_DELAY
        time.sleep(min(max(wait, 0), 8))
    return response


def _memory():
    global _MEMORY
    if _MEMORY is None:
        try:
            data = json.loads(MEMORY_FILE.read_text(encoding='utf-8'))
            _MEMORY = data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            _MEMORY = {}
        # Older versions also saved close-spelling guesses; keep only safe pairings.
        unsafe = [key for key, entry in _MEMORY.items()
                  if not (isinstance(entry, dict) and is_strict_match(key, str(entry.get('name', ''))))]
        for key in unsafe:
            _MEMORY.pop(key, None)
    return _MEMORY


def remembered(name):
    with _MEMORY_LOCK:
        entry = _memory().get(name.strip().casefold())
    if isinstance(entry, dict) and str(entry.get('uid', '')).isdecimal() and entry.get('name'):
        return entry
    return None


def remember(names, uid, real_name):
    with _MEMORY_LOCK:
        memory = _memory()
        for name in names:
            if name and not name.isdecimal():
                memory[name.strip().casefold()] = {'uid': str(uid), 'name': real_name, 'seen': int(time.time())}
        if len(memory) > 2000:
            for key in sorted(memory, key=lambda k: memory[k].get('seen', 0))[:len(memory) - 2000]:
                memory.pop(key, None)
        _save_memory(memory)


def forget(name):
    with _MEMORY_LOCK:
        memory = _memory()
        uid = (memory.get(name.strip().casefold()) or {}).get('uid')
        for key in [k for k, v in memory.items() if k == name.strip().casefold() or (uid and v.get('uid') == uid)]:
            memory.pop(key, None)
        _save_memory(memory)


def _save_memory(memory):
    try:
        temp = MEMORY_FILE.with_suffix('.tmp')
        temp.write_text(json.dumps(memory, indent=1), encoding='utf-8')
        temp.replace(MEMORY_FILE)
    except OSError:
        pass  # Memory is a speed-up only; lookups still work without it.


def fetch(path, payload=None, params=None):
    try:
        if payload is None:
            response = send_with_retry(lambda: requests.get(BASE + path, params=params, timeout=(5, 15), allow_redirects=False))
        else:
            # This POST only searches names; it does not update a profile.
            response = send_with_retry(lambda: requests.post(BASE + path, json=payload, timeout=(5, 15), allow_redirects=False))
    except requests.RequestException:
        raise StatsError('RivalsTracker could not be reached. Try again later.', True) from None
    if response.status_code in (401, 403):
        raise StatsError('RivalsTracker denied access. Remaining lookups stopped.', True)
    if response.status_code == 429:
        raise StatsError('RivalsTracker rate limit reached. Try later.', True)
    if response.status_code == 404:
        raise StatsError('Player not found. Check the name or use a UID.')
    if response.status_code == 400:
        raise PublicApiUnavailable('RivalsTracker API returned HTTP 400.', True)
    if response.status_code != 200:
        raise StatsError(f'RivalsTracker returned HTTP {response.status_code}.', True)
    try:
        return response.json()
    except ValueError:
        raise StatsError('RivalsTracker returned an unreadable response.', True) from None

from scout.reading.matching import pick_match, search_queries, accent_queries, plain, is_hidden_name, is_unreadable_name, is_strict_match  # noqa: F401  (also used by the app)


class Player:
    def __init__(self, username, typed=False, readings=None):
        # typed: the user entered this name themselves, so only an exact match counts.
        self.typed = typed
        # readings: callable giving other readings of the scanned name image,
        # tried only when the first reading finds nobody.
        self.readings = readings
        self.reread = False
        self.username = username.strip()
        self.uid = None
        self.public_page_only = False
        self.page_data = None
        self.matched_name = None
        self.from_memory = False

    def resolve_uid(self):
        if self.uid is not None:
            return self.uid
        if self.username.isdecimal():
            self.uid = self.username
            return self.uid
        if is_hidden_name(self.username):
            raise StatsError("Hidden name. This player masks their name in game, so there's nothing to look up.")
        if is_unreadable_name(self.username):
            raise StatsError("Couldn't read this name. Type it in Edit names, then press Refresh player stats.")
        saved = remembered(self.username)
        if saved and self.typed and saved['name'].casefold() != self.username.casefold():
            saved = None
        if saved:
            self.uid = saved['uid']
            self.matched_name = saved['name']
            self.from_memory = True
            return self.uid
        # Exact or OCR-equivalent names win right away. Close spellings are only
        # accepted after every search has run, so a near miss from the first
        # search can't beat the real player found by a later one.
        searched = set()
        pool = {}
        row = None
        queries = [self.username] if self.typed else search_queries(self.username)
        for query in queries:
            if query.casefold() in searched:
                continue
            searched.add(query.casefold())
            for found in self._search(query):
                if isinstance(found, dict):
                    pool.setdefault(str(found.get('aid')), found)
            if self.typed:
                row = self._typed_match(pool)
            else:
                row = pick_match(self.username, list(pool.values()), fuzzy=False)
            if row is not None:
                break
        if row is None and not self.typed:
            row = pick_match(self.username, list(pool.values()))
        if row is None and not self.typed and self.readings is not None:
            row = self._match_rereads(searched, pool)
            self.reread = row is not None
        if row is None:
            # The reader can't see accents (TRÚTHNÚKE reads as TRUTHNUKE), and
            # people often type names without them. Try with accents put back.
            for query in accent_queries(self.username, limit=3):
                if query.casefold() in searched:
                    continue
                searched.add(query.casefold())
                for found in self._search(query):
                    if isinstance(found, dict):
                        pool.setdefault(str(found.get('aid')), found)
                row = self._typed_match(pool) if self.typed else pick_match(self.username, list(pool.values()), fuzzy=False)
                if row is not None:
                    break
        if row is not None:
            uid = str(row.get('aid', '')).rsplit('_', 1)[-1]
            if not uid.isdecimal():
                raise StatsError('RivalsTracker returned an invalid player UID.', True)
            self.uid = uid
            self.matched_name = str(row.get('name', '')).strip() or self.username
            # Remember the scanned spelling only when it is safely the same name.
            keys = {self.username, self.matched_name} if is_strict_match(self.username, self.matched_name) else {self.matched_name}
            remember(keys, uid, self.matched_name)
            return uid
        if self.typed:
            raise StatsError('No player with exactly that name. Check the spelling or enter their UID.')
        raise StatsError('No close name match. Correct the detected name or enter the player UID.')

    def _typed_match(self, pool):
        """A typed name: exactly that name, or the one name that differs only by accents."""
        rows = list(pool.values())
        exact = [r for r in rows if str(r.get('name', '')).strip().casefold() == self.username.casefold()]
        if exact:
            return exact[0] if len(exact) == 1 else None
        loose = [r for r in rows if plain(r.get('name', '')) == plain(self.username)]
        return loose[0] if len(loose) == 1 else None

    def _match_rereads(self, searched, pool):
        """Read the name image other ways and look those up too.

        A player counts only when a reading matches their name letter for
        letter (look-alike letters allowed). If readings point at different
        players, the one most readings agree on wins only by a clear margin.
        """
        try:
            readings = [text for text in self.readings() if text.casefold() != self.username.casefold()][:8]
        except Exception:
            return None
        extra = []
        for text in readings:
            for query in search_queries(text)[:3]:
                if query.casefold() not in searched and query.casefold() not in {q.casefold() for q in extra}:
                    extra.append(query)
        for query in extra[:10]:
            searched.add(query.casefold())
            for found in self._search(query):
                if isinstance(found, dict):
                    pool.setdefault(str(found.get('aid')), found)
        votes, rows = {}, {}
        for text in [self.username] + readings:
            row = pick_match(text, list(pool.values()), fuzzy=False)
            if row is not None:
                key = str(row.get('aid'))
                votes[key] = votes.get(key, 0) + 1
                rows[key] = row
        if not votes:
            return None
        ranked = sorted(votes, key=lambda key: -votes[key])
        if len(ranked) > 1 and votes[ranked[0]] < 2 * votes[ranked[1]]:
            return None
        return rows[ranked[0]]

    def _search(self, query):
        if not self.public_page_only:
            try:
                rows = fetch('/find-player', payload={'name': query})
            except PublicApiUnavailable:
                self.public_page_only = True
            except StatsError as error:
                if 'not found' in str(error):
                    return []
                raise
            else:
                if not isinstance(rows, list):
                    raise StatsError('RivalsTracker changed its search response.', True)
                return rows
        try:
            response = send_with_retry(lambda: requests.post('https://api.rivalsdata.com/players/search',
                                                             json={'name': query}, timeout=(5, 15), allow_redirects=False))
        except requests.RequestException:
            raise StatsError('Name search is unavailable. Enter a UID instead.', True) from None
        if response.status_code == 404:
            return []
        if response.status_code != 200:
            raise StatsError(f'Name search is unavailable (HTTP {response.status_code}). Enter a UID instead.', True)
        try:
            rows = response.json()
        except ValueError:
            raise StatsError('Name search is unavailable. Enter a UID instead.', True) from None
        if isinstance(rows, dict):
            rows = rows.get('players', rows.get('results', []))
        if not isinstance(rows, list):
            raise StatsError('Name search changed its response format.', True)
        return rows

    def same_player_name(self, returned):
        """Check a profile name against the name the UID was resolved from."""
        if not returned or self.username.isdecimal():
            return True
        expected = getattr(self, 'matched_name', None) or self.username
        return returned.casefold() == expected.casefold()

    def get_career_stats(self, season=21, ranked=True):
        if self.public_page_only:
            raise PublicApiUnavailable('Direct stats API is unavailable.', True)
        uid = self.resolve_uid()
        data = fetch('/player/' + quote(uid, safe=''), params={'season': int(season)})
        if not isinstance(data, dict):
            raise StatsError('RivalsTracker changed its player response.', True)
        visibility = data.get('visibility', {})
        if isinstance(visibility, dict) and visibility.get('career_stats') is False:
            raise StatsError('RivalsTracker reports that career stats are hidden.')
        player = data.get('player', {})
        if not isinstance(player, dict):
            raise StatsError('RivalsTracker returned an unexpected profile format.', True)
        info = player.get('info', {})
        if not isinstance(info, dict):
            raise StatsError('RivalsTracker returned an unexpected profile identity.', True)
        returned_name = info.get('name')
        if returned_name and not self.same_player_name(returned_name):
            if self.from_memory:
                forget(self.username)
            raise StatsError('The returned profile name changed. Check the name or use its UID.')
        return data

    def get_best_heroes(self, season=21, ranked=True, fallback_previous=True, progress=None, cancelled=None, limit=3):
        try:
            return self._best_heroes(season, ranked, fallback_previous, progress, cancelled, limit)
        except PublicApiUnavailable:
            self.public_page_only = True
            return self._public_page_result(season, ranked, limit)

    def _public_page_result(self, requested, ranked, limit=3):
        uid = self.resolve_uid()
        if self.page_data is None:
            try:
                response = send_with_retry(lambda: requests.get('https://rivalstracker.com/profile/' + quote(uid, safe=''),
                                                                timeout=(5, 20), allow_redirects=False))
                if response.status_code != 200:
                    raise StatsError(f'Public profile page returned HTTP {response.status_code}.', True)
                self.page_data = parse_profile_page(response.text)
            except (requests.RequestException, ValueError, KeyError, TypeError):
                raise StatsError('The public profile page could not supply verified hero stats.', True) from None
        data, displayed = self.page_data
        if data.get('visibility', {}).get('career_stats') is not True:
            raise StatsError('The public profile does not expose career stats.')
        player = data.get('player', {})
        if str(player.get('_id')) != uid:
            raise StatsError('The public page returned a different player.', True)
        name = player.get('info', {}).get('name', '')
        if not self.same_player_name(name):
            if self.from_memory:
                forget(self.username)
            raise StatsError('The public profile name differs. Check the name or use a UID.')
        heroes = self._with_share(self._parse_heroes(self._hero_rows(data, ranked)))
        heroes.sort(key=lambda row: (row['_games'], row['_play_time']), reverse=True)
        note = f'Public website fallback • {season_label(displayed)} only. Direct API unavailable.'
        if requested != displayed:
            note += ' Requested combined/older history could not be retrieved.'
        return {'username': self.username, 'heroes': heroes[:limit], 'season': displayed, 'note': note,
                'source': 'RivalsTracker public profile page', 'limited_history': True}

    def _best_heroes(self, season=21, ranked=True, fallback_previous=True, progress=None, cancelled=None, limit=3):
        if isinstance(season, (tuple, list)) or season in ('career', 'recent2', 'recent3', 'recent6'):
            return self.get_combined_heroes(ranked, progress, cancelled, scope=season, limit=limit)
        requested_season = int(season)
        used_season = requested_season
        rows = self._cached_hero_rows(used_season, ranked)
        heroes = self._parse_heroes(rows)
        note = ''
        if not heroes and fallback_previous and requested_season > 1:
            used_season = requested_season - 1
            heroes = self._parse_heroes(self._cached_hero_rows(used_season, ranked))
            if heroes:
                note = (f'No hero records returned for {season_label(requested_season)}; '
                        f'showing PREVIOUS {season_label(used_season)} instead.')
        if not heroes:
            used_season = requested_season
            note = 'No recorded hero matches returned. Records may be incomplete or not updated yet.'
        self._with_share(heroes)
        heroes.sort(key=lambda row: (row['_games'], row['_play_time']), reverse=True)
        return {'username': self.username, 'heroes': heroes[:limit], 'season': used_season,
                'note': note, 'source': 'RivalsTracker (cached provider records)'}

    def _cached_hero_rows(self, season, ranked):
        key = (self.resolve_uid(), bool(ranked), season)
        cached = CAREER_CACHE.get(key)
        if cached and time.monotonic() - cached[0] < CAREER_CACHE_TTL:
            return copy.deepcopy(cached[1])
        data = self.get_career_stats(season, ranked)
        rows = self._hero_rows(data, ranked)
        self._parse_heroes(rows)
        if len(CAREER_CACHE) >= 512:
            CAREER_CACHE.pop(next(iter(CAREER_CACHE)), None)
        CAREER_CACHE[key] = (time.monotonic(), copy.deepcopy(rows))
        return copy.deepcopy(rows)

    def get_combined_heroes(self, ranked=True, progress=None, cancelled=None, scope='career', limit=3):
        """Sum disjoint season records, then calculate ratios from the totals.

        Provider season catalog: rivalstracker.com/_nuxt/BXIbDRya.js.
        IDs 21 through 1 are S10.5 through S0; no all-time bucket is added.
        """
        uid = self.resolve_uid()
        if isinstance(scope, (tuple, list)):
            seasons = tuple(sorted({int(v) for v in scope if 1 <= int(v) <= 21}, reverse=True)) or (21,)
        else:
            seasons = {'recent6': (21, 20, 19, 18, 17, 16), 'recent2': (21, 20), 'recent3': (21, 20, 19)}.get(scope, CAREER_SEASONS)
        combined = {}
        recorded_seasons = []
        last_request = None
        for index, season in enumerate(seasons):
            if cancelled and cancelled():
                raise StatsError('Career lookup cancelled.')
            if progress:
                progress(f'{self.username}: {season_label(season)} ({index + 1}/{len(seasons)})')
            key = (uid, bool(ranked), season)
            cached = CAREER_CACHE.get(key)
            if cached and time.monotonic() - cached[0] < CAREER_CACHE_TTL:
                rows = copy.deepcopy(cached[1])
            else:
                # Keep historical reads sequential and at least a second apart.
                if last_request is not None:
                    while time.monotonic() - last_request < HISTORY_REQUEST_INTERVAL:
                        if cancelled and cancelled():
                            raise StatsError('Career lookup cancelled.')
                        time.sleep(.05)
                last_request = time.monotonic()
                rows = self._cached_hero_rows(season, ranked)
            has_records = False
            for hero_id, row in rows.items():
                games = number(row['matches'])
                if games <= 0:
                    continue
                has_records = True
                total = combined.setdefault(str(hero_id), dict(matches=0, win=0, play_time=0,
                                                               kills=0, deaths=0, assists=0, final_hits=0,
                                                               damage=0, heal=0, damage_taken=0, blocked=0, mvp=0, svp=0,
                                                               _hits=0, _hit_games=0))
                total['matches'] += games
                total['win'] += number(row['win'])
                total['play_time'] += number(row.get('play_time', 0))
                for field in ('kills', 'deaths', 'assists', 'final_hits', 'damage', 'heal', 'damage_taken', 'mvp', 'svp'):
                    count = combat_count(row, field)
                    total[field] = None if total[field] is None or count is None else total[field] + count
                blocked = blocked_count(row)
                total['blocked'] = None if total['blocked'] is None or blocked is None else total['blocked'] + blocked
                rate = hit_rate(row)
                if rate is not None:
                    total['_hits'] += rate * games
                    total['_hit_games'] += games
                if total['_hit_games']:
                    total['session_hit_rate'] = total['_hits'] / total['_hit_games']
            if has_records:
                recorded_seasons.append(season)
        heroes = self._with_share(self._parse_heroes(combined))
        heroes.sort(key=lambda row: (row['_games'], row['_play_time']), reverse=True)
        for hero in heroes:
            hero['matches_played'] = f"{hero['_games']:g}"
        note = (f'Ranked • {season_label(scope)} combined • {len(recorded_seasons)} seasons with records. '
                'Provider history may be incomplete.')
        if not ranked:
            note = note.replace('Ranked', 'Unranked')
        return {'username': self.username, 'heroes': heroes[:limit], 'season': scope, 'note': note,
                'seasons_checked': list(seasons), 'seasons_with_records': recorded_seasons,
                'source': 'RivalsTracker (cached provider records)'}

    def get_profile(self, scope='recent6', progress=None, cancelled=None):
        """Everything shown on a searched player's page.

        Rank, level and the season overview, recent matches and teammates come
        from this season's record; the hero list covers the history range
        picked in the app (every hero, not just the top three).
        """
        heroes = self.get_best_heroes(season=scope, progress=progress, cancelled=cancelled, limit=None)
        profile = {'username': self.matched_name or self.username, 'uid': self.uid, 'heroes': heroes['heroes'],
                   'season': heroes['season'], 'note': heroes.get('note', ''), 'limited': bool(heroes.get('limited_history'))}
        if progress:
            progress('hero proficiency and newest games…')
        profile['proficiency'] = get_proficiency(self.uid)
        fresh = get_recent_matches(self.uid)
        profile['live_battle'] = get_live_battle(self.uid)
        extras = get_player_extras(self.uid)
        profile['maps'], profile['names'] = extras['maps'], extras['names']
        for hero in profile['heroes']:
            if hero['hero_name'] in extras['blocked']:
                hero['blocked_season'] = extras['blocked'][hero['hero_name']]
        if not self.public_page_only:
            try:
                profile.update(read_profile(self.get_career_stats(21), self.uid))
            except StatsError:
                pass
        if fresh:
            # RivalsData reads match history straight from the game, so it has games RivalsTracker hasn't saved yet.
            profile['matches'] = fresh[:12]
            profile['form'] = fresh
            profile['matches_live'] = True
        return profile

    @staticmethod
    def _hero_rows(data, ranked):
        rows = data.get('heroes_ranked' if ranked else 'heroes_unranked')
        if not isinstance(rows, dict):
            raise StatsError('RivalsTracker changed its hero-stat response.', True)
        return rows

    @staticmethod
    def _with_share(heroes):
        """Add each hero's share of all the player's matches (before the top-3 cut)."""
        total = sum(hero['_games'] for hero in heroes)
        for hero in heroes:
            hero['share'] = hero['_games'] / total if total else 0
        return heroes

    @staticmethod
    def _parse_heroes(rows):
        heroes = []
        try:
            for hero_id, row in rows.items():
                games = number(row['matches'])
                if not math.isfinite(games) or games < 0:
                    raise ValueError('invalid match count')
                if games <= 0:
                    continue
                wins = number(row['win'])
                if not 0 <= wins <= games:
                    raise ValueError('invalid win count')
                play_time = number(row.get('play_time', 0))
                if not math.isfinite(play_time) or play_time < 0:
                    raise ValueError('invalid play time')
                kills = combat_count(row, 'kills')
                deaths = combat_count(row, 'deaths')
                # Never substitute kills or the undocumented last_kill field.
                final_hits = combat_count(row, 'final_hits')
                heroes.append({'hero_name': HERO_NAMES.get(str(hero_id), f'Hero ID {hero_id}'),
                               'win_pct': f'{wins / games * 100:.1f}%', 'matches_played': row['matches'],
                               'kills': kills, 'deaths': deaths, 'assists': combat_count(row, 'assists'),
                               'final_hits': final_hits,
                               'avg_final_hits': f'{final_hits / games:.1f}' if final_hits is not None else 'N/A',
                               'kd': kd_ratio(kills, deaths),
                               'damage': combat_count(row, 'damage'), 'heal': combat_count(row, 'heal'),
                               'damage_taken': combat_count(row, 'damage_taken'),
                               'blocked': blocked_count(row),
                               'mvp': combat_count(row, 'mvp'), 'svp': combat_count(row, 'svp'),
                               'hit_rate': hit_rate(row),
                               '_games': games, '_play_time': play_time})
        except (KeyError, TypeError, ValueError):
            raise StatsError('RivalsTracker returned an unexpected hero-stat format.', True) from None
        return heroes


RANKS = ['Bronze III', 'Bronze II', 'Bronze I', 'Silver III', 'Silver II', 'Silver I', 'Gold III', 'Gold II', 'Gold I',
         'Platinum III', 'Platinum II', 'Platinum I', 'Diamond III', 'Diamond II', 'Diamond I',
         'Grandmaster III', 'Grandmaster II', 'Grandmaster I', 'Celestial III', 'Celestial II', 'Celestial I',
         'Eternity', 'One Above All']


def rank_name(level):
    try:
        level = int(level)
    except (TypeError, ValueError):
        return ''
    return RANKS[level - 1] if 1 <= level <= len(RANKS) else f'Rank {level}'


def _json(value):
    if isinstance(value, str):
        try:
            return json.loads(value)
        except ValueError:
            return {}
    return value if isinstance(value, dict) else {}


def _num(value, default=0.0):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return default
    return value if math.isfinite(value) else default


def read_profile(data, uid=None):
    """Pull the page details out of one season's player record. Missing parts stay empty."""
    player = data.get('player') if isinstance(data.get('player'), dict) else {}
    info = player.get('info') if isinstance(player.get('info'), dict) else {}
    details = data.get('details') if isinstance(data.get('details'), dict) else {}
    server = details.get('config_server') if isinstance(details.get('config_server'), dict) else {}
    uid = str(uid or player.get('_id') or info.get('aid') or '')
    profile = {'username': info.get('name') or '', 'uid': uid, 'level': info.get('level') or '',
               'region': details.get('region') or server.get('region') or '',
               'platform': (server.get('login_channel') or '').title()}
    seasons = []
    for key, value in _json(info.get('rank_game_season')).items():
        value = _json(value)
        try:
            season = int(key) - 1001000
        except ValueError:
            continue
        if not value or not 1 <= season <= 99:
            continue
        seasons.append({'season': season, 'level': int(_num(value.get('level'))), 'score': _num(value.get('rank_score')),
                        'peak_level': int(_num(value.get('season_max_level') or value.get('max_level'))),
                        'peak_score': _num(value.get('max_rank_score')), 'wins': int(_num(value.get('win_count'))),
                        'games': int(_num(value.get('battle_count')))})
    seasons.sort(key=lambda row: -row['season'])
    profile['ranks'] = seasons
    stats = data.get('stats') if isinstance(data.get('stats'), dict) else {}
    ranked = stats.get('ranked') if isinstance(stats.get('ranked'), dict) else {}
    profile['overview'] = {'games': int(_num(stats.get('ranked_matches'))), 'wins': int(_num(stats.get('ranked_matches_wins'))),
                           'kills': _num(ranked.get('total_kills')), 'deaths': _num(ranked.get('total_deaths')),
                           'assists': _num(ranked.get('total_assists')), 'time': _num(ranked.get('total_time_played'))}
    matches = []
    for match in data.get('match_history') or []:
        if not isinstance(match, dict):
            continue
        me = match.get('match_player') if isinstance(match.get('match_player'), dict) else {}
        hero = me.get('player_hero') if isinstance(me.get('player_hero'), dict) else {}
        extra = me.get('dynamic_fields') if isinstance(me.get('dynamic_fields'), dict) else {}
        matches.append({'id': str(match.get('match_uid') or ''), 'hero': HERO_NAMES.get(str(hero.get('hero_id')), ''), 'kills': int(_num(me.get('k'))),
                        'deaths': int(_num(me.get('d'))), 'assists': int(_num(me.get('a'))),
                        'won': bool(_num(me.get('is_win'))), 'left': bool(me.get('has_escaped')),
                        'seconds': _num(match.get('match_play_duration')), 'when': _num(match.get('match_time_stamp')),
                        'score': _num(extra.get('new_score'), None), 'change': _num(extra.get('add_score'), None),
                        'mvp': str(match.get('mvp_uid')) == uid, 'svp': str(match.get('svp_uid')) == uid,
                        'season': str(match.get('match_season') or '')})
    matches.sort(key=lambda row: -row['when'])
    profile['matches'] = matches[:12]
    mates = []
    for mate in data.get('teammates') or []:
        if not isinstance(mate, dict):
            continue
        mate_info = mate.get('info') if isinstance(mate.get('info'), dict) else {}
        name = mate_info.get('nick_name')
        if name:
            mates.append({'name': name, 'games': int(_num(mate.get('matches'))), 'wins': int(_num(mate.get('win')))})
    mates.sort(key=lambda row: (-row['games'], row['name'].casefold()))
    profile['teammates'] = mates[:8]
    return profile


RIVALSDATA = 'https://api.rivalsdata.com'


def rivalsdata_post(path, payload):
    """One read-only request to RivalsData's public API (the same site Scout's name search uses)."""
    try:
        response = send_with_retry(lambda: requests.post(RIVALSDATA + path, json=payload, timeout=(5, 15),
                                                         allow_redirects=False))
    except requests.RequestException:
        raise StatsError('RivalsData could not be reached. Try again later.') from None
    if response.status_code == 404:
        raise StatsError('RivalsData has no record of that.')
    if response.status_code == 429:
        raise StatsError('RivalsData is busy right now. Try again in a minute.')
    if response.status_code != 200:
        raise StatsError(f'RivalsData could not load that (HTTP {response.status_code}).')
    try:
        return response.json()
    except ValueError:
        raise StatsError('RivalsData sent something unexpected.') from None


def rivalsdata_get(path, params=None):
    """One read-only GET from RivalsData's public API."""
    try:
        response = send_with_retry(lambda: requests.get(RIVALSDATA + path, params=params, timeout=(5, 15),
                                                        allow_redirects=False))
    except requests.RequestException:
        raise StatsError('RivalsData could not be reached. Try again later.') from None
    if response.status_code != 200:
        raise StatsError(f'RivalsData could not load that (HTTP {response.status_code}).')
    try:
        return response.json()
    except ValueError:
        raise StatsError('RivalsData sent something unexpected.') from None


def hero_name_for(value):
    """Hero name for an ID; skin/form variants like 10571 fall back to their hero (1057)."""
    key = str(int(_num(value))) if value is not None else ''
    return HERO_NAMES.get(key) or HERO_NAMES.get(key[:4], '')


def get_player_extras(uid):
    """Map win rates, past names and damage blocked per hero, from RivalsData. Missing parts are left out."""
    extras = {'maps': [], 'names': [], 'blocked': {}}
    if not str(uid).isdecimal():
        return extras
    payload = {'uid': int(uid)}
    try:
        for row in rivalsdata_post('/player/stats/maps', payload) or []:
            comp = row.get('competitive') if isinstance(row, dict) else None
            if isinstance(comp, dict) and _num(comp.get('games')) > 0:
                extras['maps'].append({'map': str(row.get('map') or 'Unknown map'), 'games': int(_num(comp.get('games'))),
                                       'wins': int(_num(comp.get('wins')))})
    except (StatsError, AttributeError, TypeError):
        pass
    extras['maps'].sort(key=lambda r: (-r['games'], -r['wins'], r['map']))
    try:
        names = [r for r in rivalsdata_post('/player/name-history', payload) or [] if isinstance(r, dict) and r.get('name')]
        names.sort(key=lambda r: -_num(r.get('first_seen')))
        extras['names'] = [str(r['name']) for r in names]
    except (StatsError, AttributeError, TypeError):
        pass
    try:
        for row in rivalsdata_post('/player/stats/heroes', payload) or []:
            comp = row.get('competitive') if isinstance(row, dict) else None
            per_game = comp.get('per_game') if isinstance(comp, dict) else None
            name = hero_name_for(row.get('hero_id')) if isinstance(row, dict) else ''
            if name and isinstance(per_game, dict) and per_game.get('damage_blocked') is not None:
                extras['blocked'][name] = _num(per_game.get('damage_blocked'))
    except (StatsError, AttributeError, TypeError):
        pass
    return extras


TIER_RANKS = {'diamond_plus': 'Diamond+', 'grandmaster_plus': 'Grandmaster+', 'celestial_plus': 'Celestial+',
              'eternity_plus': 'Eternity+'}


def get_tierlist(rank='diamond_plus', platform=1):
    """This season's hero meta for a rank range: win, pick and ban rates, best first."""
    if rank not in TIER_RANKS:
        rank = 'diamond_plus'
    data = rivalsdata_get('/stats/tierlist', {'platform': 1 if platform != 2 else 2, 'rank': rank})
    rows = []
    for row in (data.get('heroes') if isinstance(data, dict) else None) or []:
        name = hero_name_for(row.get('hero_id')) if isinstance(row, dict) else ''
        if not name:
            continue
        rows.append({'hero': name, 'win': _num(row.get('winrate')), 'pick': _num(row.get('pick_rate')),
                     'ban': _num(row.get('ban_rate')), 'score': _num(row.get('score')), 'games': int(_num(row.get('total_games')))})
    merged = {}
    for row in rows:  # variants of one hero: keep the best-scoring line
        if row['hero'] not in merged or row['score'] > merged[row['hero']]['score']:
            merged[row['hero']] = row
    result = sorted(merged.values(), key=lambda r: -r['score'])
    return {'rank': rank, 'heroes': result, 'updated': _num(data.get('last_update')) if isinstance(data, dict) else 0}


def get_match(match_id, api_key=None):
    """Everyone in one match and how they did: RivalsData first, then RivalsTracker."""
    match_id = str(match_id or '')
    if not re.fullmatch(r'[0-9A-Za-z_-]{1,64}', match_id):
        raise StatsError('This match has no ID, so its details can\'t be loaded.')
    for load in (lambda: rivalsdata_post('/match', {'match_id': match_id}),
                 lambda: fetch('/matches/' + quote(match_id, safe=''))):
        try:
            result = read_match(load())
        except StatsError:
            continue
        if result['players']:
            return result
    raise StatsError("Neither RivalsData nor RivalsTracker has the full lobby for this match yet.")


MODES = {1: 'Quick Play', 2: 'Competitive'}


def get_recent_matches(uid):
    """This player's newest games from RivalsData, which reads them live from the game. [] if unavailable."""
    if not str(uid).isdecimal():
        return []
    try:
        data = rivalsdata_post('/player/matches', {'uid': int(uid)})
    except StatsError:
        return []
    matches = []
    for row in (data.get('matches') if isinstance(data, dict) else None) or []:
        if not isinstance(row, dict) or not row.get('match_uid'):
            continue
        hero = HERO_NAMES.get(str(int(_num(row.get('hero_id')))), '')
        mode = MODES.get(int(_num(row.get('game_mode_id'))), '')
        ranked = mode == 'Competitive'
        matches.append({'id': str(row['match_uid']), 'hero': hero, 'kills': int(_num(row.get('kills'))),
                        'deaths': int(_num(row.get('deaths'))), 'assists': int(_num(row.get('assists'))),
                        'won': bool(row.get('is_win')), 'left': bool(row.get('escaped')),
                        'seconds': _num(row.get('duration_seconds')), 'when': _num(row.get('timestamp')),
                        'score': _num(row.get('rank_score'), None) if ranked else None,
                        'change': _num(row.get('score_change'), None) if ranked else None,
                        'mvp': bool(row.get('is_mvp')), 'svp': bool(row.get('is_svp')),
                        'season': str(row.get('season') or ''), 'mode': mode,
                        'placement': int(_num(row.get('placement'))) or None, 'hero_id': str(int(_num(row.get('hero_id')))) })
    matches.sort(key=lambda m: -m['when'])
    return matches


def get_live_battle(uid):
    """The ID of the match this player is in right now, or None."""
    if not str(uid).isdecimal():
        return None
    try:
        data = rivalsdata_post('/player', {'uid': int(uid)})
    except StatsError:
        return None
    status = data.get('status') if isinstance(data, dict) else None
    battle = status.get('battle_id') if isinstance(status, dict) else None
    return str(battle) if battle else None


def get_live_match(battle_id, uid):
    """Everyone in the match a player is in right now."""
    battle_id = str(battle_id or '')
    if not re.fullmatch(r'[0-9A-Za-z_-]{1,64}', battle_id) or not str(uid).isdecimal():
        raise StatsError('That live match has no usable ID.')
    result = read_match(rivalsdata_post('/live', {'match_id': battle_id, 'uid': int(uid)}))
    if not result['players']:
        raise StatsError("The match has ended or RivalsData can't see it yet.")
    return result


def _first(row, *fields):
    for field in fields:
        if row.get(field) is not None:
            return row[field]
    return None


def read_match(data):
    """Match details (RivalsData teams, or the game's match_players list) -> {'players': [...], 'mvp', 'svp'}."""
    if not isinstance(data, dict):
        return {'players': []}
    details = data.get('match_details') if isinstance(data.get('match_details'), dict) else data
    rows = []
    teams = details.get('teams')
    for team in (teams.values() if isinstance(teams, dict) else teams or []):
        if isinstance(team, dict):
            members = team.get('players')
            for row in (members.values() if isinstance(members, dict) else members or []):
                if isinstance(row, dict):
                    extra = {'camp': row.get('camp', team.get('camp'))}
                    if row.get('is_win') is None and team.get('is_win') is not None:
                        extra['is_win'] = team.get('is_win')
                    rows.append(dict(row, **extra))
    if not rows:
        rows = [row for row in details.get('match_players') or details.get('players') or [] if isinstance(row, dict)]
    mvp, svp = str(details.get('mvp_uid') or ''), str(details.get('svp_uid') or '')
    players = []
    for row in rows:
        heroes = row.get('player_heroes') or row.get('heroes') or []
        heroes = [h for h in (heroes.values() if isinstance(heroes, dict) else heroes) if isinstance(h, dict)]
        heroes.sort(key=lambda h: -_num(h.get('play_time')))
        hero_id = _first(row, 'cur_hero_id', 'hero_id', 'top_hero_id') or (heroes[0].get('hero_id') if heroes else None)
        hero_name = lambda value: HERO_NAMES.get(str(int(_num(value))) if value is not None else '', '')
        info = row.get('player_info') if isinstance(row.get('player_info'), dict) else {}
        uid = str(_first(row, 'player_uid', 'uid') or info.get('player_uid') or '')
        if uid.endswith('.0'):
            uid = uid[:-2]
        played = [hero_name(h.get('hero_id')) for h in heroes]
        players.append({
            'uid': uid,
            'name': str(_first(row, 'nick_name', 'name', 'player_name') or info.get('nick_name') or 'Unknown'),
            'team': str(_first(row, 'camp', 'team_id', 'side', 'team') if _first(row, 'camp', 'team_id', 'side', 'team') is not None else ''),
            'won': bool(_num(row.get('is_win'))),
            'hero': hero_name(hero_id),
            'heroes': [h for h in dict.fromkeys(played) if h],
            'kills': int(_num(_first(row, 'kills', 'k'))), 'deaths': int(_num(_first(row, 'deaths', 'd'))),
            'assists': int(_num(_first(row, 'assists', 'a'))),
            'damage': combat_count(row, 'total_hero_damage') if 'total_hero_damage' in row else combat_count(row, 'damage'),
            'heal': combat_count(row, 'total_hero_heal') if 'total_hero_heal' in row else combat_count(row, 'healing'),
            'taken': combat_count(row, 'total_damage_taken') if 'total_damage_taken' in row else combat_count(row, 'damage_taken'),
            'blocked': blocked_count(row),
        })
        if row.get('is_mvp') is True:
            mvp = uid
        if row.get('is_svp') is True:
            svp = uid
    return {'players': players, 'mvp': mvp, 'svp': svp,
            'seconds': _num(_first(details, 'duration_seconds', 'match_play_duration'))}


def get_proficiency(uid):
    """Hero proficiency (the level that ends at Lord) for each hero, most points first. [] if unavailable."""
    if not str(uid).isdecimal():
        return []
    try:
        data = rivalsdata_post('/player/proficiency', {'uid': int(uid)})
    except StatsError:
        return []
    return read_proficiency(data)


def read_proficiency(data):
    infos = {}
    if isinstance(data, dict):
        if isinstance(data.get('hero_proficiency_infos'), dict):
            infos = data['hero_proficiency_infos']
        else:
            for account in data.values():
                if isinstance(account, dict) and isinstance(account.get('hero_proficiency_infos'), dict):
                    infos = account['hero_proficiency_infos']
                    break
    rows = []
    for hero_id, row in infos.items():
        if not isinstance(row, dict):
            continue
        name = HERO_NAMES.get(str(hero_id).split('.')[0])
        level, points = int(_num(row.get('proficiency_level'))), int(_num(row.get('proficiency_point')))
        if name and (level > 1 or points > 0):
            rows.append({'hero': name, 'level': level, 'points': points})
    rows.sort(key=lambda r: (-r['level'], -r['points']))
    return rows
