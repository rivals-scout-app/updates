"""Read the structured stats already rendered on a public profile page."""
import json
import re
from html.parser import HTMLParser


class ProfileHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_payload = False
        self.payload = ''
        self.option = None
        self.seasons = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script' and attrs.get('id') == '__NUXT_DATA__':
            self.in_payload = True
        if tag == 'option':
            self.option = [attrs.get('value'), 'selected' in attrs, '']

    def handle_data(self, text):
        if self.in_payload:
            self.payload += text
        if self.option is not None:
            self.option[2] += text

    def handle_endtag(self, tag):
        if tag == 'script':
            self.in_payload = False
        if tag == 'option' and self.option is not None:
            value, selected, text = self.option
            if selected and re.fullmatch(r'S:\d+(?:\.5)?', text.strip()):
                self.seasons.append((int(value), text.strip()[2:]))
            self.option = None


def parse_profile_page(html):
    if len(html) > 5_000_000:
        raise ValueError('Profile page is too large')
    parser = ProfileHTML()
    parser.feed(html)
    if len(parser.seasons) != 1:
        raise ValueError('The website did not identify the displayed season')
    season, label = parser.seasons[0]
    expected = '0' if season == 1 else str(season // 2) + ('.5' if season % 2 else '')
    if not 1 <= season <= 21 or label != expected:
        raise ValueError('The website season label changed')
    nodes = json.loads(parser.payload)
    if not isinstance(nodes, list) or len(nodes) > 100_000:
        raise ValueError('Invalid website payload')
    candidates = [i for i, node in enumerate(nodes) if isinstance(node, dict)
                  and {'heroes_ranked', 'player', 'visibility'}.issubset(node)]
    if len(candidates) != 1:
        raise ValueError('Public hero stats were not present on this page')
    def decode(index, depth=0):
        if type(index) is not int or depth > 40 or not 0 <= index < len(nodes):
            raise ValueError('Invalid payload reference')
        node = nodes[index]
        if isinstance(node, dict):
            return {key: decode(value, depth + 1) for key, value in node.items()}
        if isinstance(node, list):
            if len(node) == 2 and node[0] in ('Reactive', 'ShallowReactive', 'Ref', 'ShallowRef'):
                return decode(node[1], depth + 1)
            return [decode(value, depth + 1) for value in node]
        return node
    raw = nodes[candidates[0]]
    # Read only fields used by Scout; unrelated history can contain special references.
    data = {key: decode(raw[key]) for key in ('player', 'visibility', 'heroes_ranked', 'heroes_unranked') if key in raw}
    return data, season
