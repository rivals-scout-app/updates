"""The search popup and a player's page (heroes, form, maps, recent matches)."""
from scout.ui.common import *  # noqa: F401,F403


class PlayerPageViews:
    # ---- search popup -----------------------------------------------------------------
    def _on_search_result(self, profile):
        self.status.set(f"Found {short(profile['username'])}.")
        self._remember_recent(profile)
        self.search_view = ('profile', profile)
        self.page_scroll = 0
        self.request_render()

    def _remember_recent(self, profile):
        uid = str(profile.get('uid') or '')
        if not uid.isdecimal():
            return
        recent = [r for r in self.settings.get('recent_players') or [] if r.get('uid') != uid]
        self.settings['recent_players'] = [{'uid': uid, 'name': profile.get('username', '')}] + recent[:9]
        self._save_settings()

    def _on_search_error(self, value):
        name, error = value
        self.status.set(f'{name}: {error}')
        self.search_view = ('error', value)
        self.request_render()

    def close_search(self):
        if self.close_viewer():
            return
        if self.search_view is not None and self.search_view[0] == 'match':
            self.back_to_profile()
            return
        if self.search_view is not None and self.search_view[0] in ('compare', 'hero'):
            self._back_from(*self.search_view)
            return
        if self.search_view is not None:
            self.search_view = None
            self.request_render()

    def _scroll_page(self, event):
        if getattr(self, 'viewing', None) is not None:
            return
        if not self.search_view or self.search_view[0] not in ('profile', 'match', 'meta', 'compare', 'hero', 'insights') or not getattr(self, '_page', None):
            return
        step = -event.delta / 120 * 80 if event.delta else (-80 if getattr(event, 'num', 0) == 4 else 80)
        before = getattr(self, 'page_scroll', 0)
        self.page_scroll = max(0, min(getattr(self, 'page_max_scroll', 0), before + step))
        if self.page_scroll != before:
            self._show_page_slice()

    def _show_page_slice(self):
        """Put the part of the flat page picture that's in view on screen (one picture, so scrolling is quick)."""
        page = self._page
        b = self.board
        top = int(round(self.page_scroll * b.scale))
        view = page['ground'].copy()
        paste_rgba(view, page['picture'], 0, -top)
        page['photo'].paste(view)

    # ---- player page -----------------------------------------------------------------
    def _draw_player_page(self, x, y, w, h, ground):
        """A searched player's page: rank, season numbers, every hero, recent matches, teammates."""
        b = self.board
        kind, value = self.search_view
        self._page = None
        if kind == 'meta':
            self._draw_meta_page(value, x, y, w, h, ground)
            return
        if kind == 'insights':
            b.button(x, y, '‹  Back', self.close_search, 'raised', 38, 14)
            if value['state'] != 'ready':
                b.shape(x, y + 52, w, 170, 26, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
                text = "Working out today's insights…" if value['state'] == 'loading' else value.get('error', '')
                b.text(x + w / 2, y + 137, text, 22 if value['state'] == 'loading' else 16, color=TEXT if value['state'] == 'loading' else WARN_TEXT,
                       anchor='center')
                return
            self._draw_scroll_page(lambda top: self._insights_content(value, x, top, w), x, y, w, h, ground,
                                   'Click a game to see the lobby  ·  Esc goes back')
            return
        if kind in ('compare', 'hero'):
            back_to = value.get('other') if kind == 'compare' else value.get('profile')
            b.button(x, y, '‹  Back to ' + short(back_to.get('username', '')), lambda: self._back_from(kind, value), 'raised', 38, 14)
            if value['state'] != 'ready':
                b.shape(x, y + 52, w, 170, 26, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
                if value['state'] == 'loading':
                    b.text(x + w / 2, y + 137, 'Loading…', 24, anchor='center')
                else:
                    b.text(x + 28, y + 128, value.get('error', ''), 15, 'bold', WARN_TEXT, anchor='nw', width=w - 60)
                return
            draw = self._compare_content if kind == 'compare' else self._hero_content
            self._draw_scroll_page(lambda top: draw(value, x, top, w), x, y, w, h, ground, 'Esc goes back')
            return
        if kind == 'match':
            back_label = "today's insights" if (value.get('back') or ('',))[0] == 'insights' else short(value['profile']['username'])
            b.button(x, y, '‹  Back to ' + back_label, self.back_to_profile, 'raised', 38, 14)
            if value['state'] != 'ready':
                b.shape(x, y + 52, w, 170, 26, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
                if value['state'] == 'loading':
                    b.text(x + w / 2, y + 137, 'Loading everyone in that match…', 24, anchor='center')
                else:
                    b.text(x + 28, y + 96, 'Match details', 22, color=GOLD)
                    b.text(x + 28, y + 128, value['error'], 15, 'bold', WARN_TEXT, anchor='nw', width=w - 60)
                return
            self._draw_scroll_page(lambda top: self._match_content(value, x, top, w), x, y, w, h, ground,
                                   'Click a player to see their stats  ·  Esc goes back')
            return
        if kind == 'profile' and self._is_me(value):
            # Your own page: a dashboard, with only the buttons that make sense for you.
            bx = x + b.button(x, y, 'Reload', lambda: self.reload_player(value), 'raised', 38, 14) + 10
            bx += b.button(bx, y, 'tracker.gg', lambda: self.open_tracker_gg(value), 'raised', 38, 14) + 10
            bx += b.button(bx, y, 'Change account', self.reopen_setup, 'raised', 38, 14) + 10
            from scout.stats.tracker import season_label
            b.button(bx, y, 'Seasons: ' + season_label(self._player_scope()), lambda: self.show_seasons_picker(value), 'quiet', 38, 14)
            self._draw_scroll_page(lambda top: self._me_content(value, x, top, w), x, y, w, h, ground,
                                   'Click a hero or match for more')
            return
        back = 'Back to match' if (self.enemy_names() or self.results_by_name) else 'Back'
        back_w = b.button(x, y, '‹  ' + back, self.close_search, 'raised', 38, 14)
        if kind == 'profile':
            reload_w = b.button(x + back_w + 10, y, 'Reload', lambda: self.reload_player(value), 'raised', 38, 14)
            bx = x + back_w + reload_w + 20
            bx += b.button(bx, y, 'tracker.gg', lambda: self.open_tracker_gg(value), 'raised', 38, 14) + 10
            favorite = any(f.get('uid') == str(value.get('uid')) for f in self.settings.get('favorites') or [])
            bx += b.button(bx, y, 'Favorited' if favorite else 'Add favorite', lambda: self.toggle_favorite(value),
                           'gold' if favorite else 'raised', 38, 14) + 10
            me = self.me()
            if me and me['uid'] == str(value.get('uid')):
                bx += b.button(bx, y, 'This is you', lambda: self.set_me(value), 'gold', 38, 14) + 10
            else:
                bx += b.button(bx, y, 'This is me', lambda: self.set_me(value), 'raised', 38, 14) + 10
                if me:
                    bx += b.button(bx, y, 'Compare with me', lambda: self.open_compare(value), 'raised', 38, 14) + 10
            from scout.stats.tracker import season_label
            bx += b.button(bx, y, 'Seasons: ' + season_label(self._player_scope()), lambda: self.show_seasons_picker(value), 'quiet', 38, 14) + 10
            if value.get('live_battle'):
                b.button(bx, y, 'In a match now · see lobby', lambda: self.open_live_match(value), 'gold', 38, 14, glow=True)
        if kind == 'loading':
            b.shape(x, y + 52, w, h - 52, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
            b.text(x + w / 2, y + h / 2, f'Looking up {value}…', 26, anchor='center')
            b.text(x + w / 2, y + h / 2 + 36, self.status.get(), 14, 'bold', MUTED, anchor='center', fit=w - 80)
            return
        if kind == 'error':
            name, error = value
            b.shape(x, y + 52, w, 150, 26, WARN_LEFT, WARN_RIGHT, GOLD, 2, 'right', glow=(GOLD, 60), glow_size=8)
            b.text(x + 28, y + 96, name, 24, color=GOLD, fit=w - 60)
            b.text(x + 28, y + 128, error, 15, 'bold', WARN_TEXT, anchor='nw', width=w - 60)
            return
        profile = value
        self._draw_scroll_page(lambda top: self._page_content(profile, x, top, w), x, y, w, h, ground,
                               'Click a hero or match for more  ·  Esc goes back')

    def _draw_scroll_page(self, draw, x, y, w, h, ground, hint):
        """Draw a long page as one flat picture that scrolls quickly. draw(top) returns the page height."""
        b = self.board
        b.text(x + w, y + 19, hint, 12, 'bold', MUTED, anchor='e')
        view_top = y + 50
        view_h = h - 50 + 10
        # Pass 1 works out how tall the page is; pass 2 draws it into one flat picture.
        self._page_hits = []
        self._page_tips = []
        b.raster('measure', None)
        content = draw(0)
        pad = 14  # room for shadows and glows at the edges
        left_px, top_px = b.z(x - pad), b.z(view_top)
        picture = Image.new('RGBA', (b.z(w + pad * 2), b.z(content + pad)), (0, 0, 0, 0))
        self._page_hits = []
        self._page_tips = []
        b.raster(picture, (left_px, top_px - b.z(4)))
        draw(view_top + 4)
        b.raster(None, None)
        width_px, height_px = picture.width, b.z(view_h)
        ground_slice = ground.convert('RGBA').crop((left_px, top_px, left_px + width_px, top_px + height_px))
        self.page_max_scroll = max(0, (picture.height - height_px) / b.scale + 6)
        self.page_scroll = min(getattr(self, 'page_scroll', 0), self.page_max_scroll)
        photo = ImageTk.PhotoImage(ground_slice, master=b.canvas)
        b.photos.append(photo)
        b.canvas.create_image(left_px, top_px, image=photo, anchor='nw', tags=('page',))
        self._page = {'picture': picture, 'ground': ground_slice, 'photo': photo, 'left': left_px, 'top': top_px}
        b.canvas.tag_bind('page', '<ButtonRelease-1>', self._page_click)
        b.canvas.tag_bind('page', '<Motion>', self._page_motion)
        b.canvas.tag_bind('page', '<Leave>', lambda e: (b.canvas.configure(cursor=''), self._hide_tip()))
        self._show_page_slice()

    def _page_hit(self, x, y, w, h, command):
        """Make a part of the flat page picture clickable (design units, while drawing pass 2)."""
        raster = self.board._raster
        if not isinstance(raster, tuple):
            return
        (ox, oy), z = raster[1], self.board.z
        self._page_hits.append((z(x) - ox, z(y) - oy, z(x + w) - ox, z(y + h) - oy, command))

    def _page_spot(self, event):
        page = getattr(self, '_page', None)
        if not page:
            return None
        col = self.board.canvas.canvasx(event.x) - page['left']
        row = self.board.canvas.canvasy(event.y) - page['top'] + int(round(self.page_scroll * self.board.scale))
        for x1, y1, x2, y2, command in getattr(self, '_page_hits', []):
            if x1 <= col <= x2 and y1 <= row <= y2:
                return command
        return None

    def _page_click(self, event):
        command = self._page_spot(event)
        if command is not None:
            command()

    def _page_motion(self, event):
        self.board.canvas.configure(cursor='hand2' if self._page_spot(event) else '')
        self._page_tip_at(event)

    def _page_tip(self, x, y, w, h, lines):
        """Show `lines` (list of (text, colour)) in a small box while the pointer is over this part of the page."""
        raster = self.board._raster
        if not isinstance(raster, tuple):
            return
        (ox, oy), z = raster[1], self.board.z
        self._page_tips.append((z(x) - ox, z(y) - oy, z(x + w) - ox, z(y + h) - oy, lines))

    def _page_tip_at(self, event):
        page = getattr(self, '_page', None)
        if not page:
            return
        col = self.board.canvas.canvasx(event.x) - page['left']
        row = self.board.canvas.canvasy(event.y) - page['top'] + int(round(self.page_scroll * self.board.scale))
        for x1, y1, x2, y2, lines in getattr(self, '_page_tips', []):
            if x1 <= col <= x2 and y1 <= row <= y2:
                if getattr(self, '_tip_shown', None) is not lines:
                    self._show_tip(event, lines)
                return
        self._hide_tip()

    def _show_tip(self, event, lines):
        b = self.board
        self._hide_tip()
        self._tip_shown = lines
        scale = b.scale
        width = max(b.measure(text, size, 'extra') for text, color, size in lines) + 28
        height = sum(size + 8 for _, _, size in lines) + 16
        canvas_w, canvas_h = b.canvas.winfo_width() / scale, b.canvas.winfo_height() / scale
        x = min(event.x / scale + 14, canvas_w - width - 8)
        y = event.y / scale + 18
        if y + height > canvas_h - 8:
            y = event.y / scale - height - 12
        keep = len(b.texts)
        b.shape(x, y, width, height, 10, '#1D1E25', '#17181E', '#33343E', 1, tags=('tooltip',))
        ty = y + 10
        for text, color, size in lines:
            b.text(x + 14, ty + size / 2 + 2, text, size, 'extra', color, tags=('tooltip',))
            ty += size + 8
        del b.texts[keep:]
        b.canvas.tag_raise('tooltip')

    def _hide_tip(self):
        if getattr(self, '_tip_shown', None) is not None:
            self.board.canvas.delete('tooltip')
            self._tip_shown = None

    def _page_content(self, profile, x, y, w):
        """Draw the page from y down; returns its height."""
        bottom = self._page_header(profile, x, y, w)
        left_w = w * .62 if w > 1000 else w
        heroes_bottom = self._page_heroes(profile, x, bottom + 18, left_w)
        if w > 1000:
            # Wide window: maps sit under the hero table so both columns fill.
            if profile.get('maps'):
                heroes_bottom = self._maps_card(profile, x, heroes_bottom + 18, left_w) - 18
            side_bottom = self._page_side(profile, x + left_w + 18, bottom + 18, w - left_w - 18, maps=False)
        else:
            side_bottom = self._page_side(profile, x, heroes_bottom + 18, w)
        return max(heroes_bottom, side_bottom) - y + 8

    def _page_header(self, profile, x, y, w):
        b = self.board
        height = 140
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, 1.5, shadow=True, glow=(GLOW_PURPLE, 110), glow_size=10)
        name = short(profile['username'])
        heroes = profile.get('heroes', [])
        tint = tint_for(name)
        lords = [row for row in profile.get('proficiency') or [] if row.get('level', 0) >= 20]
        top_lord = max(lords, key=lambda row: row['level']) if lords else None
        face = top_lord['hero'] if top_lord else (heroes[0]['hero_name'] if heroes else None)
        b.avatar(x + 24, y + 26, 88, tint[0], tint[1], tint[2], 3, glow=(tint[1], 120),
                 picture=hero_picture(face) if face else None, initials=initials(name))
        if top_lord:
            b.mastery_frame(x + 24, y + 26, 88, top_lord['level'])
        b.text(x + 132, y + 50, name, 30, fit=320)
        facts = [f"Level {profile['level']}" if profile.get('level') else '', profile.get('region', ''),
                 profile.get('platform', ''), f"UID {profile['uid']}" if profile.get('uid') else '']
        b.text(x + 132, y + 84, '  ·  '.join(f for f in facts if f), 14, 'bold', MUTED, fit=330)
        old_names = [n for n in profile.get('names') or [] if n.casefold() != profile['username'].casefold()]
        if old_names:
            b.text(x + 132 + min(330, b.measure(name, 30)) + 14, y + 52, 'also ' + ', '.join(old_names[:3]), 13, 'bold', SOFT,
                   fit=w * .45 - min(330, b.measure(name, 30)) - 30)
        ranks = profile.get('ranks') or []
        if ranks:
            current = ranks[0]
            label = rank_name(current['level']) or 'Unranked'
            pill_w = b.measure(label, 15) + 30
            b.shape(x + 132, y + 100, pill_w, 28, 14, GOLD_TOP, GOLD_BOTTOM, GOLD_LINE, 1.5, 'right')
            b.text(x + 147, y + 114, label, 15, color=DARK)
            peak = f"{current['score']:,.0f} pts  ·  peak {rank_name(current['peak_level']) or '-'} {current['peak_score']:,.0f}"
            b.text(x + 132 + pill_w + 10, y + 114, peak, 13, 'bold', SOFT, fit=w * .45 - pill_w - 150)
        # Season numbers on the right.
        overview = profile.get('overview') or {}
        tiles = []
        games = overview.get('games', 0)
        if games:
            wins = overview.get('wins', 0)
            kills, deaths, assists = overview.get('kills', 0), overview.get('deaths', 0), overview.get('assists', 0)
            tiles = [('Season 10.5', f'{wins}W  {games - wins}L', MUTED),
                     ('Win rate', f'{wins / games * 100:.0f}%', win_color(f'{wins / games * 100}%')),
                     ('KDA', f'{(kills + assists) / max(deaths, 1):.1f}', kda_colors((kills + assists) / max(deaths, 1))[1]),
                     ('K/D/A per game', f'{kills / games:.1f} / {deaths / games:.1f} / {assists / games:.1f}', SOFT),
                     ('Time played', hours(overview.get('time', 0)), SOFT)]
        elif ranks and ranks[0]['games']:
            current = ranks[0]
            tiles = [('Season 10.5', f"{current['wins']}W  {current['games'] - current['wins']}L", MUTED),
                     ('Win rate', f"{current['wins'] / current['games'] * 100:.0f}%", TEXT)]
        tile_w = 128
        tx = x + w - 20 - len(tiles) * (tile_w + 10) + 10
        min_x = x + w * .45
        while tiles and tx < min_x:
            tiles.pop()
            tx = x + w - 20 - len(tiles) * (tile_w + 10) + 10
        for label, value_text, color in tiles:
            b.shape(tx, y + 30, tile_w, 80, 20, (20, 22, 43, 140), None, CHIP_LINE, 1)
            b.text(tx + tile_w / 2, y + 56, label, 12, 'bold', MUTED, anchor='center')
            b.text(tx + tile_w / 2, y + 84, value_text, 20 if len(value_text) < 9 else 15, color=color if color != MUTED else TEXT,
                   anchor='center', fit=tile_w - 16)
            tx += tile_w + 10
        return y + height

    def _page_heroes(self, profile, x, y, w):
        b = self.board
        heroes = profile.get('heroes', [])
        row_h, head_h = 58, 84
        height = head_h + max(1, len(heroes)) * (row_h + 6) + 14
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Heroes', 20)
        b.text(x + 20 + b.measure('Heroes', 20) + 12, y + 33,
               f"{season_label(profile['season'])} · ranked · {len(heroes)} heroes · averages per game (blocked: this season)",
               13, 'bold', MUTED, fit=w - 40 - b.measure('Heroes', 20) - 12)
        if profile.get('limited'):
            b.text(x + w - 20, y + 33, 'This season only (the site limited the history)', 12, 'bold', WARN_TEXT, anchor='e')
        # Columns that fit the width, most useful first.
        columns = [('Games', 64, self._col_games), ('Win %', 62, self._col_win), ('K / D / A', 118, self._col_kda_line),
                   ('KDA', 70, self._col_kda), ('Dmg / game', 84, self._col_damage), ('Heal / game', 84, self._col_heal),
                   ('MVP / SVP', 84, self._col_mvp), ('Taken / game', 88, self._col_taken), ('Accuracy', 76, self._col_accuracy)]
        if any(hero.get('blocked') is not None or hero.get('blocked_season') is not None for hero in heroes):
            columns.insert(6, ('Blocked', 76, self._col_blocked))
        name_w = 210
        room = w - 40 - name_w
        shown, used = [], 0
        for column in columns:
            if used + column[1] <= room:
                shown.append(column)
                used += column[1]
        spare = (room - used) / max(1, len(shown))
        cx = x + 20 + name_w
        positions = []
        for label, width, draw in shown:
            positions.append((cx, width + spare, draw))
            b.text(cx + (width + spare) / 2, y + 66, label, 12, 'extra', MUTED, anchor='center')
            cx += width + spare
        b.text(x + 20, y + 66, 'Hero', 12, 'extra', MUTED)
        ry = y + head_h
        if not heroes:
            b.text(x + 20, ry + 24, 'No ranked matches recorded for this range.', 15, 'bold', MUTED)
        for hero in heroes:
            trick = is_one_trick(hero)
            b.shape(x + 12, ry, w - 24, row_h, 18, ROW_LEFT, ROW_RIGHT, '#6E3540' if trick else CHIP_LINE, 1, 'right')
            tint = tint_for(hero['hero_name'])
            b.avatar(x + 22, ry + 9, 40, tint[0], tint[1], tint[2], 2, picture=hero_picture(hero['hero_name']),
                     initials=initials(hero['hero_name']))
            b.text(x + 72, ry + 21, hero['hero_name'], 15, fit=name_w - 60)
            share = hero.get('share') or 0
            bar_w = name_w - 120
            b.shape(x + 72, ry + 36, bar_w, 7, 3.5, (20, 22, 43, 160), None, None)
            if share:
                b.shape(x + 72, ry + 36, max(7, bar_w * share), 7, 3.5, LOSS if trick else GREEN_DEEP,
                        LOSS_SOFT if trick else GREEN_SOFT, None, direction='right')
            b.text(x + 72 + bar_w + 8, ry + 40, f'{share * 100:.0f}% of games', 11, 'bold', MUTED)
            for cx, width, draw in positions:
                draw(hero, cx, ry + row_h / 2, width)
            if profile.get('uid'):
                self._page_hit(x + 12, ry, w - 24, row_h, lambda hero=hero: self.open_hero(profile, hero['hero_name']))
            ry += row_h + 6
        return y + height

    # One function per hero column: (hero, left x, middle y, width).
    def _col_games(self, hero, x, y, w):
        self.board.text(x + w / 2, y, f"{hero.get('_games', 0):g}", 15, 'extra', TEXT, anchor='center')

    def _col_win(self, hero, x, y, w):
        win = hero.get('win_pct', '')
        self.board.text(x + w / 2, y, win, 15, color=win_color(win), anchor='center')

    def _col_kda_line(self, hero, x, y, w):
        counts, _ = per_game(hero)
        if not counts:
            self.board.text(x + w / 2, y, '-', 14, 'bold', MUTED, anchor='center')
            return
        parts = [(f'{counts[0]:.1f}', GREEN_SOFT), (' / ', SOFT), (f'{counts[1]:.1f}', RED), (' / ', SOFT), (f'{counts[2]:.1f}', BLUE)]
        total = sum(self.board.measure(text, 13, 'extra') for text, _ in parts)
        tx = x + (w - total) / 2
        for text, color in parts:
            self.board.text(tx, y, text, 13, 'extra', color)
            tx += self.board.measure(text, 13, 'extra')

    def _col_kda(self, hero, x, y, w):
        _, kda = per_game(hero)
        if kda is None:
            self.board.text(x + w / 2, y, '-', 14, 'bold', MUTED, anchor='center')
            return
        label = f'{kda:.1f}'
        pill = self.board.measure(label, 13) + 18
        top, bottom = kda_colors(kda)
        self.board.shape(x + (w - pill) / 2, y - 11, pill, 22, 11, '#1F2027', None, top, 1)
        self.board.text(x + w / 2, y, label, 13, color=bottom, anchor='center')

    def _per_game_value(self, hero, field):
        value, games = hero.get(field), hero.get('_games') or 0
        return None if value is None or not games else value / games

    def _col_damage(self, hero, x, y, w):
        self.board.text(x + w / 2, y, short_number(self._per_game_value(hero, 'damage')), 14, 'extra', SOFT, anchor='center')

    def _col_heal(self, hero, x, y, w):
        self.board.text(x + w / 2, y, short_number(self._per_game_value(hero, 'heal')), 14, 'extra', SOFT, anchor='center')

    def _col_taken(self, hero, x, y, w):
        self.board.text(x + w / 2, y, short_number(self._per_game_value(hero, 'damage_taken')), 14, 'extra', SOFT, anchor='center')

    def _col_blocked(self, hero, x, y, w):
        value = hero.get('blocked_season')
        if value is None:
            value = self._per_game_value(hero, 'blocked')
        self.board.text(x + w / 2, y, short_number(value), 14, 'extra', SOFT, anchor='center')

    def _col_mvp(self, hero, x, y, w):
        mvp, svp = hero.get('mvp'), hero.get('svp')
        text = '-' if mvp is None and svp is None else f'{(mvp or 0):g} / {(svp or 0):g}'
        self.board.text(x + w / 2, y, text, 14, 'extra', GOLD if (mvp or 0) else SOFT, anchor='center')

    def _col_accuracy(self, hero, x, y, w):
        rate = hero.get('hit_rate')
        self.board.text(x + w / 2, y, '-' if rate is None else f'{rate * 100:.0f}%', 14, 'extra', SOFT, anchor='center')

    def _page_side(self, profile, x, y, w, maps=True):
        b = self.board
        y = self._form_card(profile, x, y, w)
        # Recent matches
        matches = profile.get('matches') or []
        newest = max((m['when'] for m in matches if m.get('when')), default=0)
        # RivalsTracker only saves new games when someone presses Update on their site.
        stale = bool(newest) and time.time() - newest > 2 * 3600 and not profile.get('matches_live')
        note_h = 40 if stale else 0
        height = 62 + note_h + max(1, len(matches)) * 54 + 12
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Recent matches', 20)
        if any(m.get('id') for m in matches):
            b.text(x + w - 20, y + 33, 'click one for details', 12, 'bold', MUTED, anchor='e')
        if stale:
            b.text(x + 20, y + 52, f'Newest saved game: {ago(time.time() - newest)}. Missing some? Press Update on '
                   'their RivalsTracker page, then Reload here.', 12, 'bold', WARN_TEXT, anchor='nw', width=w - 40)
        ry = y + 58 + note_h
        if not matches:
            b.text(x + 20, ry + 20, 'No recent matches shown on their profile.', 14, 'bold', MUTED, fit=w - 40)
        now = time.time()
        for match in matches:
            won = match['won']
            b.shape(x + 12, ry, w - 24, 48, 16, '#15241D' if won else '#261519', '#15161B', '#25443A' if won else '#4A2A31', 1, 'right')
            b.shape(x + 22, ry + 13, 30, 22, 11, '#1F2027', None, GREEN_DEEP if won else LOSS, 1)
            b.text(x + 37, ry + 24, 'W' if won else 'L', 12, color=GREEN_SOFT if won else LOSS_SOFT, anchor='center')
            if match['hero']:
                tint = tint_for(match['hero'])
                b.avatar(x + 60, ry + 8, 32, tint[0], tint[1], tint[2], 2, picture=hero_picture(match['hero']), initials=initials(match['hero']))
            b.text(x + 100, ry + 16, match['hero'] or 'Unknown hero', 13, fit=w * .42 - 90)
            kda = f"{match['kills']} / {match['deaths']} / {match['assists']}"
            tags = '  MVP' if match['mvp'] else '  SVP' if match['svp'] else ''
            label_w = b.measure('K/D/A ', 10, 'bold')
            b.text(x + 100, ry + 34, 'K/D/A ', 10, 'bold', MUTED)
            b.text(x + 100 + label_w, ry + 34, kda + tags + ('  left early' if match['left'] else ''), 12, 'extra', SOFT,
                   fit=w * .42 - 90 - label_w)
            minutes = int(match['seconds'] // 60)
            parts = [{'Competitive': 'Comp', 'Quick Play': 'QP'}.get(match.get('mode', ''), '')]
            if match['seconds']:
                parts.append(f"{minutes}:{int(match['seconds'] % 60):02d}")
            if match['when']:
                parts.append(ago(now - match['when']))
            right = '  ·  '.join(p for p in parts if p)
            b.text(x + w - 22, ry + 16, right, 12, 'bold', MUTED, anchor='e')
            if match['change'] is not None and match['score'] is not None:
                change = match['change']
                sign = '+' if change > 0 else ''
                b.text(x + w - 22, ry + 34, f"{match['score']:,.0f} pts ({sign}{change:.0f})", 12, 'extra',
                       GREEN_SOFT if change > 0 else RED if change < 0 else SOFT, anchor='e')
            if match.get('id'):
                self._page_hit(x + 12, ry, w - 24, 48, lambda match=match: self.open_match(profile, match))
            ry += 54
        y += height + 18
        # Rank by season
        ranks = profile.get('ranks') or []
        if ranks:
            height = 62 + len(ranks) * 34 + 10
            b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
            b.text(x + 20, y + 32, 'Rank by season', 20)
            ry = y + 62
            for row in ranks:
                b.text(x + 20, ry + 12, season_label(row['season']), 13, 'extra', SOFT)
                b.text(x + w * .36, ry + 12, rank_name(row['level']) or '-', 13, color=GOLD)
                peak = rank_name(row['peak_level'])
                detail = f"peak {peak}" if peak and peak != rank_name(row['level']) else ''
                if row['games']:
                    detail = (detail + '  ·  ' if detail else '') + f"{row['wins']}W {row['games'] - row['wins']}L"
                b.text(x + w - 20, ry + 12, detail, 12, 'bold', MUTED, anchor='e', fit=w * .4)
                ry += 34
            y += height + 18
        # Hero proficiency: Lord from level 20, Champion from 50
        from scout.stats.extras import mastery_badge
        mastery = (profile.get('proficiency') or [])[:8]
        if mastery:
            height = 62 + len(mastery) * 40 + 10
            b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
            b.text(x + 20, y + 32, 'Hero proficiency', 20)
            b.text(x + w - 20, y + 33, 'from RivalsData', 12, 'bold', MUTED, anchor='e')
            ry = y + 58
            for row in mastery:
                tint = tint_for(row['hero'])
                b.avatar(x + 20, ry + 4, 30, tint[0], tint[1], tint[2], 2, picture=hero_picture(row['hero']), initials=initials(row['hero']))
                b.text(x + 60, ry + 19, row['hero'], 14, 'extra', TEXT, fit=w * .5)
                label = mastery_badge(row['level']) or f"Level {row['level']}"
                pill = b.measure(label, 12) + 18
                best = row['level'] >= 20
                b.shape(x + w - 20 - pill, ry + 8, pill, 22, 11, GOLD_TOP if best else RAISED_TOP, GOLD_BOTTOM if best else RAISED_BOTTOM,
                        None if best else CHIP_LINE, 1, 'right')
                b.text(x + w - 20 - pill / 2, ry + 19, label, 12, color=DARK if best else TEXT, anchor='center')
                b.text(x + w - 30 - pill, ry + 19, f"{row['points']:,} pts", 12, 'bold', MUTED, anchor='e')
                ry += 40
            y += height + 18
        if maps:
            y = self._maps_card(profile, x, y, w)
        # Teammates
        mates = profile.get('teammates') or []
        if mates:
            height = 62 + len(mates) * 34 + 10
            b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
            b.text(x + 20, y + 32, 'Plays with', 20)
            ry = y + 62
            for mate in mates:
                b.text(x + 20, ry + 12, mate['name'], 14, 'extra', TEXT, fit=w * .55)
                rate = f"  ·  {mate['wins'] / mate['games'] * 100:.0f}% wins" if mate['games'] else ''
                b.text(x + w - 20, ry + 12, f"{mate['games']} games{rate}", 12, 'bold', MUTED, anchor='e')
                ry += 34
            y += height + 18
        if profile.get('note'):
            b.text(x + 4, y + 4, profile['note'], 12, 'bold', MUTED, anchor='nw', width=w - 8)
            y += 40
        return y

    @staticmethod
    def _game_tip_lines(game, now):
        """Hover text for one game: result, mode, hero, K/D/A, placement and rank points."""
        win = game.get('won')
        is_ranked = game.get('change') is not None
        mode = 'Ranked' if is_ranked else (game.get('mode') or 'Quick Play')
        first = f"{'Win' if win else 'Loss'}  ·  {mode}  ·  {game.get('hero') or 'Unknown hero'}"
        details = [f"{game.get('kills', 0)} / {game.get('deaths', 0)} / {game.get('assists', 0)} K/D/A"]
        if game.get('placement'):
            details.append(f"#{game['placement']} in lobby")
        if game.get('mvp') or game.get('svp'):
            details.append('MVP' if game.get('mvp') else 'SVP')
        lines = [(first, GREEN_SOFT if win else LOSS_SOFT, 13), ('  ·  '.join(details), TEXT, 12)]
        if is_ranked:
            change = game['change']
            lines.append((f"{'+' if change > 0 else ''}{change:.0f} rank points" +
                          (f"  ·  {game['score']:,.0f} after" if game.get('score') is not None else ''),
                          GREEN_SOFT if change > 0 else LOSS_SOFT if change < 0 else SOFT, 12))
        lines.append((ago(now - game['when']), MUTED, 11))
        return lines

    def _form_card(self, profile, x, y, w):
        """Last games, oldest to newest: one tile each. Ranked tiles are solid, Quick Play ones outlined.
        Points won or lost sit under ranked tiles; hover any tile for the full story, click it for the match."""
        b = self.board
        games = [g for g in profile.get('form') or [] if g.get('when')]
        if len(games) < 3:
            return y
        games = list(reversed(games[:20]))  # oldest first, left to right
        wins = sum(1 for g in games if g['won'])
        ranked = [g for g in games if g.get('change') is not None]
        height = 160
        b.shape(x, y, w, height, 22, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 30, f'Last {len(games)} games', 18)
        b.text(x + w - 20, y + 31, f'{wins}W {len(games) - wins}L  ·  {wins / len(games) * 100:.0f}%', 13, 'extra',
               win_color(f'{wins / len(games) * 100}%'), anchor='e')
        step = (w - 40) / len(games)
        tile_w = max(8, min(30, step - 4))
        now = time.time()
        for index, game in enumerate(games):
            tx = x + 20 + step * index + (step - tile_w) / 2
            is_ranked = game.get('change') is not None
            win = game['won']
            if is_ranked:
                b.shape(tx, y + 56, tile_w, 34, 6, GREEN_DEEP if win else LOSS, GREEN_SOFT if win else LOSS_SOFT, None, direction='down')
                b.text(tx + tile_w / 2, y + 73, 'W' if win else 'L', 12 if tile_w >= 14 else 9, color=DARK, anchor='center')
                if step >= 22:
                    change = game['change']
                    b.text(tx + tile_w / 2, y + 104, f"{'+' if change > 0 else ''}{change:.0f}", 10, 'extra',
                           GREEN_SOFT if change > 0 else LOSS_SOFT if change < 0 else MUTED, anchor='center')
            else:
                b.shape(tx, y + 56, tile_w, 34, 6, '#18241E' if win else '#251719', None, '#2F6B50' if win else '#6E3540', 1)
                b.text(tx + tile_w / 2, y + 73, 'W' if win else 'L', 12 if tile_w >= 14 else 9,
                       color=GREEN_SOFT if win else LOSS_SOFT, anchor='center')
                if step >= 22:
                    b.text(tx + tile_w / 2, y + 104, 'QP', 10, 'extra', MUTED, anchor='center')
            # Hover: how that game went. Click: open it.
            lines = self._game_tip_lines(game, now)
            self._page_tip(tx - 2, y + 54, tile_w + 4, 60, lines)
            if game.get('id'):
                self._page_hit(tx - 2, y + 54, tile_w + 4, 60, lambda g=game: self.open_match(profile, g))
        total = sum(g['change'] for g in ranked)
        legend = 'Solid = ranked  ·  outlined = Quick Play  ·  hover a game for details'
        if ranked:
            b.text(x + 20, y + 136, f"Ranked: {'+' if total > 0 else ''}{total:.0f} pts over {len(ranked)} games", 12, 'extra',
                   GREEN_SOFT if total > 0 else LOSS_SOFT if total < 0 else SOFT)
            b.text(x + w - 20, y + 136, 'hover for details', 11, 'bold', MUTED, anchor='e')
        else:
            b.text(x + 20, y + 136, legend, 11, 'bold', MUTED, fit=w - 40)
        return y + height + 18

    def _maps_card(self, profile, x, y, w):
        """Competitive win rate on each map this season."""
        b = self.board
        maps = (profile.get('maps') or [])[:8]
        if not maps:
            return y
        height = 62 + len(maps) * 34 + 10
        b.shape(x, y, w, height, 28, CARD_TOP, CARD_BOTTOM, CARD_LINE, shadow=True)
        b.text(x + 20, y + 32, 'Maps', 20)
        b.text(x + w - 20, y + 33, 'competitive, this season', 12, 'bold', MUTED, anchor='e')
        ry = y + 62
        bar_x, bar_w = x + w * .48, w * .22
        for row in maps:
            rate = row['wins'] / row['games'] * 100
            b.text(x + 20, ry + 12, row['map'], 14, 'extra', TEXT, fit=w * .44)
            b.shape(bar_x, ry + 8, bar_w, 8, 4, (20, 22, 43, 160), None, None)
            if rate:
                b.shape(bar_x, ry + 8, max(8, bar_w * rate / 100), 8, 4, GREEN_DEEP if rate >= 50 else LOSS,
                        GREEN_SOFT if rate >= 50 else LOSS_SOFT, None, direction='right')
            b.text(x + w - 20, ry + 12, f"{row['wins']}W {row['games'] - row['wins']}L", 12, 'bold', MUTED, anchor='e')
            ry += 34
        return y + height + 18

    def _back_from(self, kind, value):
        profile = value.get('other') if kind == 'compare' else value.get('profile')
        self.search_view = ('profile', profile)
        self.page_scroll = value.get('scroll', 0)
        self.request_render()
